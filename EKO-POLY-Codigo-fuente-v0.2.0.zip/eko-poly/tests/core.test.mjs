import test from 'node:test';import assert from 'node:assert/strict';
import {hashPassword,verifyPassword,signToken,verifyToken} from '../packages/eko-core/auth.ts';
import {isTronAddress,formatUnits} from '../packages/eko-core/web3/tron.ts';
import {bettingStatus,assertBettingAllowed} from '../packages/eko-core/betting/gate.ts';
test('reused scrypt and HMAC authenticate and reject tampering',()=>{const hash=hashPassword('cacao-12345');assert.ok(verifyPassword('cacao-12345',hash));assert.ok(!verifyPassword('wrong',hash));const t=signToken({sub:'1',name:'Ana',role:'guest'},'test-secret');assert.equal(verifyToken(t,'test-secret').sub,'1');assert.equal(verifyToken(t+'a','test-secret'),null);});
test('TRON checksum and 18 decimal integer formatting',()=>{assert.ok(isTronAddress('TMNKYEbXGJGFPaZXs8tBER6gMiRvjKtUiU'));assert.ok(!isTronAddress('TMNKYEbXGJGFPaZXs8tBER6gMiRvjKtUiV'));assert.equal(formatUnits(1234567890123456789n,18),'1.234567890123456789');});
test('economic module fails closed',()=>{const cfg={complianceFile:'missing-approvals.json',bettingEnabled:true,tronNetwork:'mainnet'};assert.equal(bettingStatus(cfg).enabled,false);assert.throws(()=>assertBettingAllowed(cfg));});
