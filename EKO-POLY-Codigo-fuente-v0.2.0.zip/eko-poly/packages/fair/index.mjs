import {createHash,createHmac,randomBytes} from 'node:crypto';
export const commitment=seed=>createHash('sha256').update(Buffer.from(seed,'hex')).digest('hex');
export const newSeed=()=>randomBytes(32).toString('hex');
export function stream(seed,matchId,clientSeeds,label){
 if(!/^[0-9a-f]{64}$/i.test(seed))throw Error('Semilla inválida.');
 let block=Buffer.alloc(0),cursor=0,counter=0;
 return limit=>{
  if(!Number.isInteger(limit)||limit<1||limit>256)throw Error('Límite inválido.');
  const threshold=Math.floor(256/limit)*limit;
  for(;;){if(cursor>=block.length){block=createHmac('sha256',Buffer.from(seed,'hex')).update(JSON.stringify([matchId,clientSeeds,label,counter++])).digest();cursor=0;}const byte=block[cursor++];if(byte<threshold)return byte%limit;}
 };
}
export function roll(seed,matchId,clientSeeds,nonce){const next=stream(seed,matchId,clientSeeds,`dice:${nonce}`);return [next(6)+1,next(6)+1];}
export function shuffle(values,seed,matchId,clientSeeds,label){const out=structuredClone(values),next=stream(seed,matchId,clientSeeds,label);for(let i=out.length-1;i>0;i--){const j=next(i+1);[out[i],out[j]]=[out[j],out[i]];}return out;}
export function verify(proof){return commitment(proof.seed)===proof.commitment&&proof.rolls.every((r,n)=>JSON.stringify(r)===JSON.stringify(roll(proof.seed,proof.matchId,proof.clientSeeds,n)));}
