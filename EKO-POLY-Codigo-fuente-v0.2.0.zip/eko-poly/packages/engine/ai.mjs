import {legalActions,board,worth} from './index.mjs';
export function chooseAction(state,id,dice,level=2){
 const actions=legalActions(state,id),p=state.players.find(p=>p.id===id),pick=type=>actions.find(a=>a.type===type);
 if(!actions.length)return null;
 const send=a=>({...a,player:id});
 if(pick('pay_debt'))return send(pick('pay_debt'));
 if(state.phase==='debt')return send(pick('sell')||pick('sell_hotel')||pick('mortgage')||pick('bankrupt'));
 if(state.phase==='auction'){
  const bid=pick('bid'),tile=board[state.auction.property],limit=Math.min(p.cash-100,Math.floor(tile.price*(.55+level*.17)));
  return send(bid&&bid.minimum<=limit?{type:'bid',amount:Math.min(limit,bid.minimum+9)}:{type:'pass'});
 }
 if(pick('buy'))return send(p.cash-board[p.position].price>100||level>=3?pick('buy'):pick('decline'));
 if(pick('decline'))return send(pick('decline'));
 if(pick('tax'))return send(actions.filter(a=>a.type==='tax').find(a=>a.choice===(worth(state,id,false)*.1<200?'percent':'fixed')));
 if(pick('release'))return send(pick('release'));
 if(pick('pay_jail')&&p.cash>350)return send(pick('pay_jail'));
 const build=actions.find(a=>a.type==='build'&&p.cash-board[a.property].build>150);
 if(build&&level>0)return send(build);
 const unmortgage=actions.find(a=>a.type==='unmortgage'&&p.cash>450);if(unmortgage)return send(unmortgage);
 if(pick('roll'))return send({...pick('roll'),dice});
 if(pick('end'))return send(pick('end'));
 const reject=actions.find(a=>a.type==='trade_reply');return reject?send({...reject,accept:false}):null;
}
