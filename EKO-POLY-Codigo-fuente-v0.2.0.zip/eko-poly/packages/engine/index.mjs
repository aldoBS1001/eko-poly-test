import board from '../../config/board.json' with {type:'json'};
import rules from '../../config/rules.json' with {type:'json'};
import cards from '../../config/cards.json' with {type:'json'};
export {board,rules,cards};
const assert=(condition,message)=>{if(!condition)throw Error(message);};
const active=s=>s.players.filter(p=>!p.bankrupt);
const me=(s,id)=>s.players.find(p=>p.id===id);
const owner=(s,i)=>me(s,s.assets[i]?.owner);
const groupOf=i=>board.filter(t=>t.group&&t.group===board[i].group);
const ownsGroup=(s,p,i)=>groupOf(i).every(t=>s.assets[t.id].owner===p.id);
const clearGroup=(s,i)=>groupOf(i).every(t=>s.assets[t.id].level===0);
const maxHouses=s=>s.mode==='classic'?rules.maxHouses:rules.shortHouses;
export function worth(s,id,final=true){
 const p=me(s,id);return p.cash+board.reduce((sum,t)=>{const a=s.assets[t.id];
  if(a?.owner!==id)return sum;
  return sum+(a.mortgaged&&final?t.mortgage:t.price)+(a.level?(a.level===5?maxHouses(s)+1:a.level)*t.build:0);
 },0);
}
export function createGame({players,mode='short',order,propertyOrder,decks,matchId='practice',configHash='',deadline=null}){
 assert(players.length>=rules.minPlayers&&players.length<=rules.maxPlayers,'Se necesitan de 2 a 6 jugadores.');
 assert(new Set(players.map(p=>p.id)).size===players.length,'Jugadores duplicados.');
 assert(['classic','short','timed'].includes(mode),'Modo inválido.');
 const ids=order||players.map(p=>p.id);
 assert(ids.length===players.length&&new Set(ids).size===players.length&&ids.every(id=>players.some(p=>p.id===id)),'Orden inválido.');
 const s={version:1,matchId,configHash,mode,deadline,players:ids.map(id=>({...players.find(p=>p.id===id),cash:rules.startingCash,position:0,jail:0,bankrupt:false,cards:[]})),assets:{},turn:0,round:1,phase:'roll',doubles:0,dice:[1,1],bank:-rules.startingCash*players.length,houses:rules.houses,hotels:rules.hotels,auction:null,auctionQueue:[],debt:null,offers:[],decks:structuredClone(decks||cards),log:[],revision:0,winners:[]};
 board.filter(t=>t.price).forEach(t=>s.assets[t.id]={owner:null,level:0,mortgaged:false});
 if(mode!=='classic'){
  const properties=propertyOrder||board.filter(t=>t.type==='property').map(t=>t.id);
  assert(properties.length>=players.length*rules.startingProperties&&new Set(properties).size===properties.length&&properties.every(i=>board[i]?.type==='property'),'Reparto inválido.');
  s.players.forEach((p,n)=>properties.slice(n*rules.startingProperties,(n+1)*rules.startingProperties).forEach(i=>{s.assets[i].owner=p.id;p.cash-=board[i].price;s.bank+=board[i].price;}));
 }
 assertState(s);return s;
}
function money(s,from,to,amount){
 assert(Number.isSafeInteger(amount)&&amount>=0,'Monto inválido.');
 if(from)me(s,from).cash-=amount;else s.bank-=amount;
 if(to)me(s,to).cash+=amount;else s.bank+=amount;
}
function record(s,type,text,data={}){s.log.push({type,text,...data});}
function pay(s,p,to,amount,reason){
 if(amount===0||p.id===to)return;
 if(p.cash>=amount){money(s,p.id,to,amount);record(s,'payment',`${p.name}: ${reason}, ${amount} Cacao.`,{from:p.id,to,amount});}
 else{s.debt={player:p.id,to,amount,reason,resume:s.phase};s.phase='debt';record(s,'debt',`${p.name} necesita reunir ${amount} Cacao para ${reason}.`);}
}
function finish(s){
 s.phase='over';s.offers=[];
 const ranking=active(s).map(p=>({id:p.id,worth:worth(s,p.id),cash:p.cash,properties:Object.values(s.assets).filter(a=>a.owner===p.id).length})).sort((a,b)=>b.worth-a.worth||b.cash-a.cash||b.properties-a.properties);
 s.ranking=ranking;
 s.winners=ranking.filter(p=>p.worth===ranking[0]?.worth&&p.cash===ranking[0]?.cash&&p.properties===ranking[0]?.properties).map(p=>p.id);
 record(s,'finish',`Victoria: ${s.winners.map(id=>me(s,id).name).join(' y ')}.`);
}
function nextTurn(s){
 if(active(s).length<=1||(s.mode==='short'&&s.players.filter(p=>p.bankrupt).length>=rules.shortBankruptcies)){finish(s);return;}
 do{s.turn=(s.turn+1)%s.players.length;if(s.turn===0)s.round++;}while(s.players[s.turn].bankrupt);
 s.doubles=0;s.phase='roll';s.offers=[];
}
function jail(s,p){p.position=rules.jailPosition;p.jail=1;s.doubles=0;s.phase='end';record(s,'jail',`${p.name}: wallet congelada.`);}
function move(s,p,target,salary=true){if(salary&&target<=p.position){money(s,null,p.id,rules.salary);record(s,'salary',`${p.name} recibe ${rules.salary} Cacao del Amanecer.`);}p.position=target;}
export function rent(s,i,dice=s.dice){
 const t=board[i],a=s.assets[i],p=owner(s,i);if(!p||a.mortgaged)return 0;
 if(t.type==='port')return rules.portRent[board.filter(t=>t.type==='port'&&s.assets[t.id].owner===p.id).length-1];
 if(t.type==='service')return dice.reduce((a,b)=>a+b,0)*rules.serviceMultipliers[board.filter(t=>t.type==='service'&&s.assets[t.id].owner===p.id).length-1];
 return t.rents[a.level]*(a.level===0&&ownsGroup(s,p,i)?2:1);
}
function land(s,p,depth=0){
 assert(depth<12,'Cadena de cartas demasiado larga.');
 const t=board[p.position];record(s,'land',`${p.name} llega a ${t.name}.`,{player:p.id,position:t.id});
 if(t.price){const a=s.assets[t.id];if(!a.owner)s.phase='buy';else if(a.owner!==p.id)pay(s,p,a.owner,rent(s,t.id),'renta');return;}
 if(t.type==='gojail'){jail(s,p);return;}
 if(t.type==='tax'){if(rules.tax.mode==='choice')s.phase='tax';else pay(s,p,null,rules.tax.fixed,'comisión de red');return;}
 if(t.type==='tax2'){pay(s,p,null,rules.tax.secondary,'cuota verde');return;}
 if(t.type==='oracle'||t.type==='community'){
  const deck=s.decks[t.type],card=deck.shift();if(!card)return;
  record(s,'card',card.text,{card:card.id});
  if(card.type==='release'){p.cards.push({...card,deck:t.type});return;}
  deck.push(card);
  if(card.type==='cash'){if(card.amount>0)money(s,null,p.id,card.amount);else pay(s,p,null,-card.amount,'aportación comunitaria');}
  if(card.type==='jail')jail(s,p);
  if(card.type==='repairs'){const mine=Object.values(s.assets).filter(a=>a.owner===p.id);pay(s,p,null,mine.reduce((n,a)=>n+(a.level===5?card.hotel:a.level*card.house),0),'mantenimiento');}
  if(card.type==='move'){move(s,p,card.target);land(s,p,depth+1);}
  if(card.type==='back'){p.position=(p.position-card.steps+board.length)%board.length;land(s,p,depth+1);}
 }
}
function auction(s,property,resume='end'){s.phase='auction';s.auction={property,bid:0,bidder:null,passed:[],resume};s.offers=[];record(s,'auction',`Subasta: ${board[property].name}.`);}
function closeAuction(s){
 const a=s.auction;if(a.bidder){money(s,a.bidder,null,a.bid);s.assets[a.property].owner=a.bidder;record(s,'purchase',`${me(s,a.bidder).name} gana ${board[a.property].name} por ${a.bid} Cacao.`);}
 s.auction=null;s.phase=a.resume;
 if(s.auctionQueue.length)auction(s,s.auctionQueue.shift(),a.resume);
 else if(s.players[s.turn].bankrupt)nextTurn(s);
}
function canBuild(s,p,i){const t=board[i],a=s.assets[i],g=groupOf(i);return t?.type==='property'&&a.owner===p.id&&ownsGroup(s,p,i)&&g.every(t=>!s.assets[t.id].mortgaged)&&a.level<5&&p.cash>=t.build&&g.every(t=>s.assets[t.id].level>=a.level)&&(a.level===maxHouses(s)?s.hotels>0:s.houses>0);}
function canSell(s,p,i){const a=s.assets[i];return a?.owner===p.id&&a.level>0&&groupOf(i).every(t=>s.assets[t.id].level<=a.level)&&(a.level!==5||s.houses>=maxHouses(s));}
function sell(s,p,i,whole=false){
 const t=board[i],a=s.assets[i];
 if(a.level===5){s.hotels++;if(whole){money(s,null,p.id,Math.floor(t.build*(maxHouses(s)+1)*rules.sellRate));a.level=0;return;}s.houses-=maxHouses(s);a.level=maxHouses(s);}
 else{a.level--;s.houses++;}
 money(s,null,p.id,Math.floor(t.build*rules.sellRate));
}
export function liquidationValue(s,id){return me(s,id).cash+board.reduce((n,t)=>{const a=s.assets[t.id];return a?.owner===id?n+(!a.mortgaged?t.mortgage:0)+(a.level===5?maxHouses(s)+1:a.level)*Math.floor((t.build||0)*rules.sellRate):n;},0);}
export function legalActions(s,id){
 const p=me(s,id);if(!p||p.bankrupt||s.phase==='over')return [];
 const own=s.players[s.turn].id===id,actions=[];
 if(s.phase==='auction'){
  if(!s.auction.passed.includes(id)&&s.auction.bidder!==id){if(p.cash>=s.auction.bid+rules.minimumBid)actions.push({type:'bid',minimum:s.auction.bid+rules.minimumBid});actions.push({type:'pass'});}return actions;
 }
 if(s.phase==='debt'&&s.debt.player!==id)return [];
 const managing=(own&&['roll','end'].includes(s.phase))||(s.phase==='debt'&&s.debt.player===id);
 if(managing)board.forEach(t=>{const a=s.assets[t.id];if(a?.owner!==id)return;
  if(own&&s.phase!=='debt'&&canBuild(s,p,t.id))actions.push({type:'build',property:t.id});
  if(canSell(s,p,t.id))actions.push({type:'sell',property:t.id});
  if(a.level===5&&groupOf(t.id).every(t=>s.assets[t.id].level===5))actions.push({type:'sell_hotel',property:t.id});
  if(!a.mortgaged&&clearGroup(s,t.id))actions.push({type:'mortgage',property:t.id});
  if(s.phase!=='debt'&&a.mortgaged&&p.cash>=Math.ceil(t.mortgage*(1+rules.mortgageInterest)))actions.push({type:'unmortgage',property:t.id});
 });
 if(s.phase==='debt'){
  if(p.cash>=s.debt.amount)actions.push({type:'pay_debt'});
  if(liquidationValue(s,id)<s.debt.amount)actions.push({type:'bankrupt'});
  return actions;
 }
 if(own){
  if(s.phase==='roll'){actions.push({type:'roll'});if(p.jail){if(p.cash>=rules.jailFee)actions.push({type:'pay_jail'});if(p.cards.length)actions.push({type:'release'});}}
  if(s.phase==='buy'){if(p.cash>=board[p.position].price)actions.push({type:'buy'});actions.push({type:'decline'});}
  if(s.phase==='tax')actions.push({type:'tax',choice:'fixed'},{type:'tax',choice:'percent'});
  if(s.phase==='end')actions.push({type:'end'});
 }
 if(['roll','end','buy','tax'].includes(s.phase)){
  actions.push({type:'trade_offer'});
  s.offers.filter(o=>o.to===id).forEach(o=>actions.push({type:'trade_reply',offer:o.id,accept:false},{type:'trade_reply',offer:o.id,accept:true}));
 }
 return actions;
}
function validBundle(s,p,b){
 assert(b&&Number.isSafeInteger(b.cash)&&b.cash>=0&&b.cash<=p.cash&&Array.isArray(b.properties)&&Array.isArray(b.cards),'Oferta inválida.');
 assert(new Set(b.properties).size===b.properties.length&&new Set(b.cards).size===b.cards.length,'Activos repetidos.');
 assert(b.properties.every(i=>s.assets[i]?.owner===p.id&&clearGroup(s,i)),'No se puede ceder un grupo con edificios.');
 assert(b.cards.every(id=>p.cards.some(c=>c.id===id)),'Tarjeta no disponible.');
}
export function apply(input,action){
 const s=structuredClone(input),offset=s.log.length;
 assert(action&&typeof action.type==='string','Acción inválida.');
 const id=action.player,p=me(s,id);
 if(action.type==='timeout'){
  assert(s.phase!=='over','Partida terminada.');
  if(s.phase==='auction')closeAuction(s);
  else if(s.phase==='buy')auction(s,s.players[s.turn].position);
  else if(s.phase==='tax'){s.phase='end';pay(s,s.players[s.turn],null,rules.tax.fixed,'comisión de red');}
  else if(s.phase==='end'){if(s.doubles&&!s.players[s.turn].jail)s.phase='roll';else nextTurn(s);}
  else throw Error('El servidor debe elegir una acción legal para este temporizador.');
 }else if(action.type==='time_limit'){
  assert(s.mode==='timed'&&s.phase!=='over','Límite de tiempo no permitido.');finish(s);
 }else{
  const allowed=legalActions(s,id).some(a=>a.type===action.type&&(a.property===undefined||a.property===action.property)&&(a.choice===undefined||a.choice===action.choice)&&(a.offer===undefined||a.offer===action.offer));
  assert(allowed,'Acción no permitida en este momento.');
  const t=board[action.property],a=s.assets[action.property];
  switch(action.type){
   case 'roll':{
    const dice=action.dice;assert(Array.isArray(dice)&&dice.length===2&&dice.every(d=>Number.isInteger(d)&&d>=1&&d<=rules.diceSides),'Dados inválidos.');
    s.dice=[...dice];s.phase='end';const doubles=dice[0]===dice[1];record(s,'roll',`${p.name} tira ${dice.join(' + ')}.`,{player:id,dice});
    if(p.jail){
     if(doubles){p.jail=0;s.doubles=0;}
     else if(p.jail<rules.jailTurns){p.jail++;break;}
     else{p.jail=0;s.doubles=0;pay(s,p,null,rules.jailFee,'descongelar wallet');if(s.debt){s.debt.moveAfter=dice[0]+dice[1];break;}}
    }else{s.doubles=doubles?s.doubles+1:0;if(s.doubles>=rules.maxDoubles){jail(s,p);break;}}
    move(s,p,(p.position+dice[0]+dice[1])%board.length);land(s,p);break;
   }
   case 'buy':{const tile=board[p.position];money(s,id,null,tile.price);s.assets[tile.id].owner=id;s.phase='end';record(s,'purchase',`${p.name} adquiere ${tile.name}.`);break;}
   case 'decline':auction(s,p.position);break;
   case 'bid':assert(Number.isSafeInteger(action.amount)&&action.amount>=s.auction.bid+rules.minimumBid&&action.amount<=p.cash,'Puja inválida.');s.auction.bid=action.amount;s.auction.bidder=id;s.auction.passed=[];record(s,'bid',`${p.name} ofrece ${action.amount} Cacao.`);break;
   case 'pass':s.auction.passed.push(id);if(active(s).every(p=>p.id===s.auction.bidder||s.auction.passed.includes(p.id)))closeAuction(s);break;
   case 'end':if(s.doubles&&!p.jail)s.phase='roll';else nextTurn(s);break;
   case 'tax':s.phase='end';pay(s,p,null,action.choice==='fixed'?rules.tax.fixed:Math.floor(worth(s,id,false)*rules.tax.percent),'comisión de red');break;
   case 'build':money(s,id,null,t.build);if(a.level===maxHouses(s)){a.level=5;s.hotels--;s.houses+=maxHouses(s);}else{a.level++;s.houses--;}record(s,'build',`${p.name} construye en ${t.name}.`);break;
   case 'sell':sell(s,p,t.id);record(s,'sell',`${p.name} vende un edificio de ${t.name}.`);break;
   case 'sell_hotel':sell(s,p,t.id,true);break;
   case 'mortgage':a.mortgaged=true;money(s,null,id,t.mortgage);record(s,'mortgage',`${p.name} hipoteca ${t.name}.`);break;
   case 'unmortgage':money(s,id,null,Math.ceil(t.mortgage*(1+rules.mortgageInterest)));a.mortgaged=false;break;
   case 'pay_jail':money(s,id,null,rules.jailFee);p.jail=0;break;
   case 'release':{const card=p.cards.shift();s.decks[card.deck].push(card);p.jail=0;break;}
   case 'pay_debt':{const d=s.debt;money(s,id,d.to,d.amount);s.phase=d.resume;s.debt=null;if(d.moveAfter){move(s,p,(p.position+d.moveAfter)%board.length);land(s,p);}break;}
   case 'bankrupt':{
    const d=s.debt;board.forEach(t=>{const a=s.assets[t.id];if(a?.owner!==id)return;if(a.level){const levels=a.level===5?maxHouses(s)+1:a.level;money(s,null,id,levels*Math.floor(t.build*rules.sellRate));if(a.level===5)s.hotels++;else s.houses+=a.level;a.level=0;}});
    money(s,id,d.to,p.cash);const creditor=me(s,d.to);
    board.forEach(t=>{const a=s.assets[t.id];if(a?.owner!==id)return;a.owner=creditor?.id||null;if(!creditor){a.mortgaged=false;s.auctionQueue.push(t.id);}});
    if(creditor)creditor.cards.push(...p.cards);else p.cards.forEach(c=>s.decks[c.deck].push(c));
    p.cards=[];p.bankrupt=true;s.debt=null;s.doubles=0;s.phase='end';s.offers=[];record(s,'bankrupt',`${p.name} sale de la partida.`);
    if(active(s).length<=1||(s.mode==='short'&&s.players.filter(p=>p.bankrupt).length>=rules.shortBankruptcies)){finish(s);break;}
    if(creditor){const interest=board.reduce((n,t)=>n+(s.assets[t.id]?.owner===creditor.id&&input.assets[t.id]?.owner===id&&s.assets[t.id].mortgaged?Math.ceil(t.mortgage*rules.mortgageInterest):0),0);pay(s,creditor,null,interest,'interés de hipotecas recibidas');}
    if(s.auctionQueue.length)auction(s,s.auctionQueue.shift());else if(!s.debt)nextTurn(s);break;
   }
   case 'trade_offer':{
    const target=me(s,action.to);assert(target&&!target.bankrupt&&target.id!==id,'Destinatario inválido.');validBundle(s,p,action.give);validBundle(s,target,action.receive);
    assert(s.offers.length<12,'Demasiadas ofertas pendientes.');
    const offer={id:`${s.revision+1}:${id}`,from:id,to:target.id,give:action.give,receive:action.receive};s.offers.push(offer);record(s,'trade_offer',`${p.name} propone un intercambio a ${target.name}.`);break;
   }
   case 'trade_reply':{
    assert(typeof action.accept==='boolean','La respuesta debe aceptar o rechazar.');
    const o=s.offers.find(o=>o.id===action.offer&&o.to===id);assert(o,'Oferta no disponible.');
    if(action.accept){const from=me(s,o.from);validBundle(s,from,o.give);validBundle(s,p,o.receive);
     const fee=b=>b.properties.reduce((n,i)=>n+(s.assets[i].mortgaged?Math.ceil(board[i].mortgage*rules.mortgageInterest):0),0);
     assert(from.cash-o.give.cash+o.receive.cash>=fee(o.receive)&&p.cash-o.receive.cash+o.give.cash>=fee(o.give),'Falta Cacao para el interés hipotecario.');
     money(s,from.id,id,o.give.cash);money(s,id,from.id,o.receive.cash);money(s,from.id,null,fee(o.receive));money(s,id,null,fee(o.give));
     for(const [source,target,b] of [[from,p,o.give],[p,from,o.receive]]){b.properties.forEach(i=>s.assets[i].owner=target.id);for(const cid of b.cards){target.cards.push(source.cards.find(c=>c.id===cid));source.cards=source.cards.filter(c=>c.id!==cid);}}
     s.offers=[];record(s,'trade',`${from.name} y ${p.name} completaron su intercambio.`);
    }else s.offers=s.offers.filter(x=>x!==o);break;
   }
  }
 }
 // A debt paid by a creditor outside the active turn resumes the next active player.
 if(!s.debt&&s.phase==='end'&&s.players[s.turn].bankrupt&&!s.auction)nextTurn(s);
 s.revision++;assertState(s);return {state:s,events:s.log.slice(offset)};
}
export function assertState(s){
 assert(s.players.every(p=>Number.isSafeInteger(p.cash)&&p.cash>=0),'Saldo inválido.');
 assert(Number.isSafeInteger(s.bank)&&s.players.reduce((n,p)=>n+p.cash,s.bank)===0,'El Cacao no cuadra.');
 assert(s.houses>=0&&s.hotels>=0,'Inventario negativo.');
 assert(s.houses+Object.values(s.assets).reduce((n,a)=>n+(a.level===5?0:a.level),0)===rules.houses,'Inventario de casas inválido.');
 assert(s.hotels+Object.values(s.assets).filter(a=>a.level===5).length===rules.hotels,'Inventario de hoteles inválido.');
 for(const a of Object.values(s.assets)){assert(!a.owner||s.players.some(p=>p.id===a.owner&&!p.bankrupt),'Propietario inválido.');assert(!a.mortgaged||a.level===0,'Hipoteca con edificios.');}
 return true;
}
