using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;

class Launcher : Form {
    TcpListener server;
    string url;
    bool running = true;
    byte[] page;
    [STAThread] static void Main(string[] args) { Application.EnableVisualStyles(); var app=new Launcher(); if(Array.IndexOf(args,"--self-test")>=0) { Thread.Sleep(30000); app.running=false; app.server.Stop(); return; } Application.Run(app); }
    Launcher() {
        Text = "EKO POLY"; ClientSize = new Size(430,220); BackColor = Color.FromArgb(18,63,46); ForeColor = Color.White;
        StartPosition = FormStartPosition.CenterScreen; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
        using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("game.html")) using(var m = new MemoryStream()) { s.CopyTo(m); page=m.ToArray(); }
        var title = new Label { Text="EKO POLY", Font=new Font("Georgia",27), Location=new Point(25,25), AutoSize=true, ForeColor=Color.FromArgb(217,233,156) };
        var help = new Label { Text="Tu mesa está lista.\nConserva esta ventana abierta mientras juegas.", Font=new Font("Segoe UI",11), Location=new Point(27,88), AutoSize=true };
        var open = new Button { Text="Abrir juego", Location=new Point(27,155), Size=new Size(175,38), BackColor=Color.FromArgb(217,233,156), ForeColor=Color.FromArgb(18,63,46), FlatStyle=FlatStyle.Flat };
        var stop = new Button { Text="Cerrar EKO POLY", Location=new Point(220,155), Size=new Size(175,38), BackColor=Color.FromArgb(235,239,222), ForeColor=Color.FromArgb(18,63,46), FlatStyle=FlatStyle.Flat };
        Controls.AddRange(new Control[]{title,help,open,stop}); open.Click+=(s,e)=>Open(); stop.Click+=(s,e)=>Close();
        try { server=new TcpListener(IPAddress.Loopback,4180); server.Start(); }
        catch(SocketException) { MessageBox.Show("El puerto local 4180 está ocupado. Cierra la otra ventana de EKO POLY y vuelve a abrir el juego.","EKO POLY"); Environment.Exit(1); }
        url="http://127.0.0.1:4180/";
        new Thread(Serve) {IsBackground=true}.Start(); Shown+=(s,e)=>Open();
        FormClosing+=(s,e)=>{ running=false;server.Stop(); };
    }
    void Open() {
        string edge=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Microsoft","Edge","Application","msedge.exe");
        try { if(File.Exists(edge)) Process.Start(new ProcessStartInfo(edge,"--app="+url) {UseShellExecute=true}); else Process.Start(new ProcessStartInfo(url) {UseShellExecute=true}); }
        catch { MessageBox.Show("Abre esta dirección en tu navegador: "+url); }
    }
    void Serve() { while(running) { try { var client=server.AcceptTcpClient();ThreadPool.QueueUserWorkItem(x=>Reply(client)); } catch {if(!running)return;} } }
    void Reply(TcpClient client) {
        using(client) { try {
            client.ReceiveTimeout=3000;client.SendTimeout=5000;
            using(var stream=client.GetStream()) {
                var buffer=new byte[8192];int n=stream.Read(buffer,0,buffer.Length);string request=Encoding.ASCII.GetString(buffer,0,n);string path=request.Split(' ').Length>1?request.Split(' ')[1]:"";
                bool ok=request.StartsWith("GET ")&&(path=="/"||path=="/index.html"||path=="/health-eko-poly");
                byte[] body=path=="/health-eko-poly"?Encoding.UTF8.GetBytes("eko-poly-0.1.0"):ok?page:Encoding.UTF8.GetBytes("Not found");
                var headers=Encoding.ASCII.GetBytes("HTTP/1.1 "+(ok?"200 OK":"404 Not Found")+"\r\nContent-Type: "+(path=="/health-eko-poly"?"text/plain":"text/html; charset=utf-8")+"\r\nContent-Length: "+body.Length+"\r\nX-Content-Type-Options: nosniff\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n");
                stream.Write(headers,0,headers.Length);stream.Write(body,0,body.Length);
            }
        } catch { } }
    }
}
