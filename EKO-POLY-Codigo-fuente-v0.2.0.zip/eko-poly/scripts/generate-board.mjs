import {writeFileSync} from 'node:fs';
// Ocho grupos de color en orden de valor. Tintas vivas y distintas entre sí, como un tablero impreso.
const groups=[
 ['Semilla','#76b82a','•',['Sendero del Cacao','Milpa del Alba'],80,40],
 ['Raíz','#8b5a2b','│',['Jardín de Copal','Bosque de Niebla','Valle del Venado'],120,55],
 ['Brisa','#19a7b4','∿',['Duna Serena','Costa del Colibrí','Estero de Luna'],160,70],
 ['Savia','#7b3fa0','✦',['Selva del Jaguar','Cenote del Sol','Reserva del Quetzal'],200,85],
 ['Aurora','#e5007e','╱',['Loma del Ámbar','Cumbre del Viento','Sierra del Cielo'],240,100],
 ['Marea','#1f5ead','≈',['Arrecife de Jade','Bahía del Amanecer','Isla de la Tortuga'],280,115],
 ['Lumbre','#e4462c','◆',['Mirador K’iin','Terraza del Eclipse','Valle de los Astros'],320,130],
 ['Horizonte','#eaa800','⊙',['Santuario del Sol','Ciudad de la Ceiba'],360,145]
];
const slots=[[1,3],[6,8,9],[11,13,14],[16,18,19],[21,23,24],[26,27,29],[31,32,34],[37,39]];
// Curva de rentas de forma clásica: renta base baja y un salto fuerte con la tercera casa.
// Fracciones del precio; los grupos caros pagan proporcionalmente un poco más.
const step=(x,n)=>Math.max(n,Math.round(x/n)*n);
const rents=(price,g)=>[
 step(price*(.06+.008*g),2),
 step(price*(.30+.028*g),5),
 step(price*(.90+.085*g),10),
 step(price*(2.75+.04*g),10),
 step(price*(3.65+.03*g),25),
 step(price*(4.45+.05*g),25)
];
const board=Array.from({length:40},(_,id)=>({id,type:'rest',name:'La Ceiba'}));
groups.forEach(([group,color,pattern,names,base,build],g)=>names.forEach((name,n)=>{
 const id=slots[g][n],price=base+n*12;
 board[id]={id,type:'property',name,group,color,pattern,price,build,mortgage:Math.floor(price/2),rents:rents(price,g)};
}));
[[5,'Veracruz'],[15,'Progreso'],[25,'Manzanillo'],[35,'Lázaro Cárdenas']].forEach(([id,name])=>board[id]={id,type:'port',name:`Puerto de ${name}`,price:210,mortgage:105,color:'#24435c',pattern:'⚓'});
[[12,'Energía EKO K’iin'],[28,'Red de Agua']].forEach(([id,name])=>board[id]={id,type:'service',name,price:160,mortgage:80,color:'#4f6b2a',pattern:'⌁'});
[[0,'start','Amanecer K’iin'],[10,'jail','Wallet congelada'],[20,'rest','La Ceiba'],[30,'gojail','¡Congela tu wallet!'],[4,'tax','Comisión de red'],[38,'tax2','Cuota verde']].forEach(([id,type,name])=>board[id]={id,type,name});
[7,22,36].forEach(id=>board[id]={id,type:'oracle',name:'Oráculo K’iin'});
[2,17,33].forEach(id=>board[id]={id,type:'community',name:'Tequio'});
writeFileSync(new URL('../config/board.json',import.meta.url),JSON.stringify(board,null,2)+'\n');
