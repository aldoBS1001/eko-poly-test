import {createGame,apply,assertState,board,cards} from '../packages/engine/index.mjs';import {chooseAction} from '../packages/engine/ai.mjs';import {writeFileSync,mkdirSync} from 'node:fs';
const count=Number(process.argv[2]||1000),maxActions=Number(process.argv[3]||250);let rng=0x482719ab;
const next=n=>{rng^=rng<<13;rng^=rng>>>17;rng^=rng<<5;return (rng>>>0)%n;};
const shuffle=v=>{const out=structuredClone(v);for(let i=out.length-1;i>0;i--){const j=next(i+1);[out[i],out[j]]=[out[j],out[i]];}return out;};
const result={games:count,seed:'482719ab',maxActions,mode:'timed',actions:0,naturalFinishes:0,syntheticTimeouts:0,illegalStates:0,firstSeatWins:0,description:'Prueba determinista de invariantes. El reloj se adelanta al alcanzar el límite de acciones; no mide duración ni demuestra balance.'};
for(let n=0;n<count;n++){
 const players=Array.from({length:2+n%5},(_,i)=>({id:String(i),name:`IA ${i}`}));
 let s=createGame({players,mode:'timed',order:shuffle(players.map(p=>p.id)),propertyOrder:shuffle(board.filter(t=>t.type==='property').map(t=>t.id)),decks:{oracle:shuffle(cards.oracle),community:shuffle(cards.community)}}),first=s.players[0].id;
 for(let i=0;i<maxActions&&s.phase!=='over';i++){
  const actor=s.phase==='debt'?s.debt.player:s.phase==='auction'?s.players.find(p=>!p.bankrupt&&p.id!==s.auction.bidder&&!s.auction.passed.includes(p.id))?.id:s.players[s.turn].id;
  if(!actor)throw Error('No actor');const action=chooseAction(s,actor,[next(6)+1,next(6)+1],n%4);if(!action)throw Error('No action');s=apply(s,action).state;assertState(s);s.log=[];result.actions++;
 }
 if(s.phase!=='over'){s=apply(s,{type:'time_limit'}).state;result.syntheticTimeouts++;}else result.naturalFinishes++;
 assertState(s);if(s.winners.includes(first))result.firstSeatWins++;
 if((n+1)%1000===0)console.log(`Validated ${n+1} games / ${result.actions} actions`);
}
mkdirSync('build',{recursive:true});writeFileSync('build/simulation-results.json',JSON.stringify(result,null,2));console.log(result);
