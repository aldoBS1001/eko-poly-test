import {WebSocket} from 'ws';import assert from 'node:assert/strict';import {writeFile} from 'node:fs/promises';
const base='http://127.0.0.1:4178',clients=[];
async function client(i){const r=await fetch(base+'/api/guest',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify({name:'Prueba'+i})});assert.equal(r.status,200);const session=await r.json();const ws=new WebSocket(base.replace('http','ws'),{origin:base}),messages=[];ws.on('message',raw=>messages.push(JSON.parse(raw)));await new Promise(resolve=>ws.once('open',resolve));const c={ws,messages,id:session.id,send:m=>ws.send(JSON.stringify(m)),wait:async pred=>{for(let n=0;n<100;n++){const idx=messages.findIndex(pred);if(idx>=0)return messages.splice(idx,1)[0];await new Promise(r=>setTimeout(r,50));}throw Error('Timed out waiting for message');}};c.send({type:'auth',token:session.token});await c.wait(m=>m.type==='auth');clients.push(c);return c;}
try{
 for(let i=0;i<4;i++)await client(i);
 const host=clients[0];host.send({type:'create',clientSeed:'aa'.repeat(32)});const {room}=await host.wait(m=>m.type==='room');
 for(let i=1;i<4;i++){clients[i].send({type:'join',code:room.code,clientSeed:String(i).repeat(64)});await clients[i].wait(m=>m.type==='room'&&m.room.players.length===i+1);}
 host.send({type:'start'});const first=await host.wait(m=>m.type==='state');assert.equal(first.state.players.length,4);assert.equal(first.state.phase,'roll');
 const current=clients.find(c=>c.id===first.state.players[first.state.turn].id);
 current.send({type:'action',revision:first.state.revision,action:{type:'roll',dice:[999,999],player:'forged'}});
 const rolled=await current.wait(m=>m.type==='state'&&m.state.revision===1);assert.ok(rolled.state.dice.every(d=>d>=1&&d<=6));
 current.send({type:'action',revision:rolled.state.revision,action:{type:'time_limit'}});const forbidden=await current.wait(m=>m.type==='error');assert.match(forbidden.message,/inválida/);
 const outsider=clients.find(c=>c!==current);outsider.send({type:'action',revision:rolled.state.revision,action:{type:'buy'}});assert.match((await outsider.wait(m=>m.type==='error')).message,/permitida/);
 assert.equal((await fetch(base+'/api/proof/'+room.code)).status,409);
 assert.equal((await fetch(base+'/api/escrow/join',{method:'POST'})).status,404);
 const result={pass:true,room:room.code,checks:['4 authenticated guests','private room join','authoritative random dice','forged actor ignored','server-only action rejected','out of turn action rejected','seed hidden before finish','economic endpoint unavailable']};await writeFile('build/integration-results.json',JSON.stringify(result,null,2));console.log(result);
}finally{clients.forEach(c=>c.ws.close());}
