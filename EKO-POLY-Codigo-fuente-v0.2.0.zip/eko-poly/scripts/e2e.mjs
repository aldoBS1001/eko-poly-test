import {createRequire} from 'node:module';import {mkdir,writeFile} from 'node:fs/promises';import assert from 'node:assert/strict';
import {createGame} from '../packages/engine/index.mjs';
const require=createRequire(import.meta.url);let chromium,devices;try{({chromium,devices}=require('playwright'));}catch{({chromium,devices}=require('C:/Users/PC/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));}
await mkdir('build/screenshots',{recursive:true});
// En Windows se prueba con Edge; en otros sistemas con el Chromium de Playwright (E2E_CHANNEL lo sobrescribe).
const channel=process.env.E2E_CHANNEL??(process.platform==='win32'?'msedge':undefined);
const browser=await chromium.launch({headless:true,...(channel?{channel}:{})}),results=[];
try{for(const [name,options] of [['Windows',{viewport:{width:1440,height:1000}}],['iPhone',devices['iPhone 12']],['Android',devices['Pixel 7']]]){
 const context=await browser.newContext(options),page=await context.newPage(),errors=[];
 page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:4178');
 await page.getByRole('button',{name:'Jugar ahora'}).waitFor();await page.screenshot({path:`build/screenshots/${name}-inicio.png`,fullPage:true});
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'horizontal overflow');
 await page.getByRole('button',{name:'Jugar ahora'}).click();await page.locator('#name').fill('Ana');await page.locator('#bots').selectOption('1');await page.getByRole('button',{name:'Que comience el viaje'}).click();
 await page.getByRole('button',{name:'Mis propiedades'}).waitFor();await page.screenshot({path:`build/screenshots/${name}-partida.png`,fullPage:true});
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'game horizontal overflow');
 await page.getByRole('button',{name:'Guardar y salir'}).click();await page.getByRole('button',{name:/Tu próximo amanecer/}).click();await page.getByRole('button',{name:'Mis propiedades'}).waitFor();
 await page.getByRole('button',{name:'Mis propiedades'}).click();await page.getByRole('dialog').waitFor();await page.getByRole('button',{name:'Cerrar',exact:true}).click();
 const sample=createGame({players:[{id:'you',name:'Ana',bot:false},{id:'bot',name:'Balam',bot:true,level:2}],mode:'classic'});sample.players[0].position=1;sample.phase='buy';
 await page.addInitScript(s=>localStorage.setItem('eko-poly-save',JSON.stringify({state:s,human:'you',saved:Date.now()})),sample);await page.reload();await page.getByRole('button',{name:/Tu próximo amanecer/}).click();
 await page.getByRole('button',{name:/Comprar propiedad/}).click();
 await page.getByRole('button',{name:'Mis propiedades'}).click();await page.getByRole('dialog').getByRole('button',{name:/Sendero del Cacao/}).click();await page.getByRole('button',{name:'Hipotecar',exact:true}).click();
 assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('eko-poly-save')).state.assets[1].mortgaged),true);
 assert.deepEqual(errors,[]);results.push({device:name,checks:['landing','no overflow','practice start','save/resume','property purchase','mortgage','no JS errors'],pass:true});await context.close();
}
}finally{await browser.close();}
await writeFile('build/e2e-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));

