from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import math
root=Path(__file__).resolve().parent.parent
im=Image.new('RGB',(1024,1024),'#123f2e'); d=ImageDraw.Draw(im)
d.ellipse((365,245,659,539),outline='#d9e99c',width=18)
for i in range(12):
 a=i*math.pi/6
 d.line((512+math.cos(a)*182,392+math.sin(a)*182,512+math.cos(a)*230,392+math.sin(a)*230),fill='#d9e99c',width=17)
title=ImageFont.truetype('C:/Windows/Fonts/georgia.ttf',150)
sub=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',65)
d.text((512,680),'EKO',font=title,fill='#fff8dd',anchor='mm')
d.text((512,800),'P O L Y',font=sub,fill='#d9e99c',anchor='mm')
(root/'resources').mkdir(exist_ok=True)
im.save(root/'resources/icon-1024.png')
im.save(root/'resources/eko-poly.ico',sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
 folder=root/f'android/app/src/main/res/mipmap-{density}'; folder.mkdir(exist_ok=True)
 for name in ['ic_launcher.png','ic_launcher_round.png','ic_launcher_foreground.png']:
  im.resize((size,size),Image.Resampling.LANCZOS).save(folder/name)
for name in ['ic_launcher.xml','ic_launcher_round.xml']:
 p=root/f'android/app/src/main/res/mipmap-anydpi-v26/{name}'
 p.write_text('<?xml version="1.0" encoding="utf-8"?><adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/ic_launcher_background"/><foreground android:drawable="@mipmap/ic_launcher_foreground"/></adaptive-icon>',encoding='utf-8')
(root/'android/app/src/main/res/values/ic_launcher_background.xml').write_text('<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#123F2E</color></resources>',encoding='utf-8')
im.save(root/'ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png')
for size in [192,512]:im.resize((size,size),Image.Resampling.LANCZOS).save(root/f'resources/icon-{size}.png')
for path in list((root/'android/app/src/main/res').glob('drawable*/splash.png'))+list((root/'ios/App/App/Assets.xcassets/Splash.imageset').glob('*.png')):
 with Image.open(path) as old: dimensions=old.size
 splash=Image.new('RGB',dimensions,'#123f2e')
 side=int(min(dimensions)*.35)
 splash.paste(im.resize((side,side),Image.Resampling.LANCZOS),((dimensions[0]-side)//2,(dimensions[1]-side)//2))
 splash.save(path)
print('Original EKO POLY icons generated')
