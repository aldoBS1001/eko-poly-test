import {build} from 'esbuild';
import {mkdir,copyFile,readFile,writeFile} from 'node:fs/promises';
await mkdir('dist',{recursive:true});await mkdir('build',{recursive:true});
await build({entryPoints:['apps/web/app.mjs'],outfile:'dist/app.js',bundle:true,minify:true,format:'esm',target:'es2020',loader:{'.png':'dataurl','.jpg':'dataurl'}});
// CSS con las fuentes Barlow Condensed incrustadas para que el tablero se vea igual sin conexión.
await build({entryPoints:['apps/web/app.css'],outfile:'dist/app.css',bundle:true,minify:true,target:['safari15','chrome100','edge100'],loader:{'.woff2':'dataurl'}});
await copyFile('apps/web/index.html','dist/index.html');
const svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="110" fill="#123f2e"/><circle cx="256" cy="210" r="74" fill="none" stroke="#d9e99c" stroke-width="12"/><g stroke="#d9e99c" stroke-width="12">'+Array.from({length:12},(_,i)=>`<path transform="rotate(${i*30} 256 210)" d="M256 110V82"/>`).join('')+'</g><text x="256" y="370" text-anchor="middle" fill="#fff8dd" font-family="Georgia" font-size="90">EKO</text><text x="256" y="420" text-anchor="middle" fill="#d9e99c" font-family="Arial" font-size="32" letter-spacing="12">POLY</text></svg>';
await writeFile('dist/icon.svg',svg);
for(const size of [192,512])await copyFile(`resources/icon-${size}.png`,`dist/icon-${size}.png`);
await writeFile('dist/manifest.webmanifest',JSON.stringify({name:'EKO POLY',short_name:'EKO POLY',id:'/',start_url:'/',scope:'/',display:'standalone',background_color:'#123F2E',theme_color:'#123F2E',lang:'es-MX',icons:[{src:'icon-192.png',sizes:'192x192',type:'image/png',purpose:'any'},{src:'icon-512.png',sizes:'512x512',type:'image/png',purpose:'any'}]}));
await writeFile('dist/sw.js',`const CACHE='eko-poly-3d-v1';self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['./','./app.js','./app.css','./icon.svg','./icon-192.png','./icon-512.png','./manifest.webmanifest']))));self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('eko-poly-')&&k!==CACHE).map(k=>caches.delete(k))))));self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==location.origin||new URL(e.request.url).pathname.startsWith('/api/'))return;e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));});`);
let html=await readFile('dist/index.html','utf8');const js=await readFile('dist/app.js','utf8'),css=await readFile('dist/app.css','utf8');
html=html.replace('<link rel="stylesheet" href="app.css">',`<style>${css}</style>`).replace('<script type="module" src="app.js"></script>',`<script type="module">${js.replace(/<\/script/g,'<\\/script')}</script>`).replace('<link rel="manifest" href="manifest.webmanifest">','').replace('<link rel="icon" href="icon.svg" type="image/svg+xml">','');
await writeFile('build/EKO-POLY.html',html);
console.log('Built dist/ and build/EKO-POLY.html');
