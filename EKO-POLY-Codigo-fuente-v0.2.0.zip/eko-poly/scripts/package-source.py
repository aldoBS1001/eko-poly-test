from pathlib import Path
import zipfile,hashlib,json
root=Path(__file__).resolve().parent.parent
skip={'.git','node_modules','tools','build','data','.gradle','Pods','DerivedData','.idea','__pycache__'}
blocked={'.env','local.properties','key.p8'}
target=root/'build/EKO-POLY-Codigo-fuente.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  rel=f.relative_to(root)
  if any(p in skip for p in rel.parts) or f.name in blocked or f.suffix in {'.jks','.keystore','.p8','.p12','.sqlite','.mobileprovision'}:continue
  if f.is_file():z.write(f,'eko-poly/'+rel.as_posix())
hashes={}
for f in (root/'build').iterdir():
 if f.suffix in {'.exe','.apk','.aab','.html','.zip'}:
  hashes[f.name]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(root/'build/SHA256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print(json.dumps(hashes,indent=2))
