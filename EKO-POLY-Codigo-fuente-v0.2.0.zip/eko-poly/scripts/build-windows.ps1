$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { throw 'Se requiere .NET Framework 4 para generar el ejecutable.' }
$html = Join-Path $projectRoot 'build\EKO-POLY.html'
$source = Join-Path $projectRoot 'installers\windows\Launcher.cs'
$output = Join-Path $projectRoot 'build\EKO-POLY.exe'
$icon = Join-Path $projectRoot 'resources\eko-poly.ico'
& $compiler /nologo /target:winexe /platform:anycpu /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll "/win32icon:$icon" "/resource:$html,game.html" "/out:$output" $source
if ($LASTEXITCODE -ne 0) { throw 'Falló la compilación de Windows.' }
Get-FileHash -LiteralPath $output -Algorithm SHA256
