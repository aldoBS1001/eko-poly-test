# EKO POLY

Juego original de propiedades de Business Shop / EKO K’iin. **Versión 0.2.0 de desarrollo, no entrega comercial final.** Estado detallado en [PROGRESS.md](PROGRESS.md).

## Novedades 0.2.0: tablero clásico en 3D

- Tablero cuadrado de 40 casillas con esquinas grandes, franjas de color, texto orientado por lado, puertos, servicios, cartas y cuotas con iconos propios.
- Vista 3D inclinada sobre una mesa (con vista plana opcional), fichas de pie que saltan casilla por casilla, casas y hoteles en volumen, dados 3D que ruedan y cámara que sigue tu ficha.
- Títulos de propiedad, cartas de Oráculo K’iin y Tequio que se voltean, monedas al comprar, escarcha al congelar la wallet, confeti al ganar.
- Sonido sintetizado (dados, pasos, monedas, cartas, subasta) y marimba de fondo; EKO K’iin narra la partida con voz y globo de diálogo.
- Ajustes: efectos, música, voz, tablero 3D y cámara. Todo funciona sin conexión.
- Reglas más cercanas al clásico: 16 cartas por mazo, renta con salto en la tercera casa y orden inicial por tirada.

## Jugar

- Windows: ejecutar `build/EKO-POLY.exe`. Incluye práctica local; abre Edge en modo aplicación o el navegador predeterminado. Mantener la ventana del lanzador abierta.
- Android: `build/EKO-POLY-Android-pruebas.apk`. Firma de depuración, destinado a pruebas fuera de tienda.
- HTML: abrir `build/EKO-POLY.html` para práctica sin conexión.
- iPhone: el proyecto `ios/` requiere compilación y firma en Xcode; no se incluye un IPA instalable. Hay workflows separados para simulador y exportación de IPA firmado, sin publicar. Falta conectar GitHub y verificar la configuración Apple del repositorio.

## Desarrollo

Node 24 y pnpm 11.19.0:

```sh
pnpm install --frozen-lockfile
pnpm test
pnpm build
pnpm start
```

Abrir `http://127.0.0.1:4178`. La práctica es local; las salas privadas usan el servidor y WebSocket. Para varios dispositivos se necesita alojar el servidor bajo HTTPS, con `PUBLIC_ORIGIN` configurado y proxy WebSocket. El servidor enlaza a loopback por defecto.

```sh
pnpm exec cap sync android
pnpm exec cap sync ios
node scripts/simulate.mjs 10000 100
```

Compilación Android: JDK 21, SDK 35, `android/gradlew -p android assembleDebug`. El AAB de release no tiene firma de distribución. Windows: `powershell -File scripts/build-windows.ps1` tras compilar la web. Las dependencias y archivos generados se excluyen del repositorio.

## Alcance comprobable

Motor compartido sin reloj ni E/S, práctica contra IA, guardado, compra/renta/construcción, subastas, hipotecas, negociación y deuda. Servidor de salas de 2 a 6, decisiones autoritativas, instantáneas SQLite, bitácora encadenada y dados con compromiso/revelación.

No hay depósitos, transacciones reales ni contratos desplegados. Los módulos económicos, KYC, torneos completos, ranking y demás pendientes de aceptación se enumeran en PROGRESS.md. No presentar la compilación como aprobación de Apple/Google ni como verificación en teléfonos físicos.
