# Decisiones técnicas

- EKO POLY vive en una carpeta independiente `eko-poly/`. EKO RUMMY se usa solo como referencia; no se modifican sus fuentes ni datos.
- Referencia descargada desde GitHub y fijada en `9b4ac9063c4d4c1a0164a68fd634e3a56e319785`.
- El motor nuevo usa módulos JavaScript puros, compartidos entre navegador y servidor. La autenticación y los adaptadores reutilizados conservan TypeScript nativo.
- Capacitor 7 genera los proyectos Android e iOS con `com.businessshop.ekopoly`. Android utiliza un proyecto Gradle convencional. Se sustituye PWABuilder por Capacitor para incluir práctica offline sin dominio publicado.
- Windows usa un ejecutable .NET Framework que incluye el juego, sirve únicamente en loopback y abre Edge en modo aplicación (o el navegador predeterminado). No necesita Node instalado. Este empaquetado ofrece práctica local; las salas requieren la versión del servidor.
- No se publican tiendas ni se envían transacciones reales. El candado reutilizado y todas las rutas económicas permanecen cerrados.
- Las salas privadas iniciales son de tiempo límite. Los temporizadores, dados y acciones se resuelven en el servidor.
- Se conserva una instantánea por acción, junto a eventos encadenados por SHA-256 en SQLite; excede la frecuencia mínima de instantáneas del documento.
- No se declara entrega comercial terminada hasta completar los criterios del PDF. Se mantienen separados los resultados comprobados y los pendientes en PROGRESS.md.
- 0.2.0: el 3D se hace con CSS (perspectiva y `preserve-3d`) sobre el tablero SVG en lugar de WebGL: conserva texto vectorial, clics por casilla, accesibilidad y funcionamiento sin conexión, sin dependencias nuevas en la web.
- El plano 3D se dibuja a 2× (WebKit) o 3× (Chromium con densidad ≥ 2.5) y se reduce dentro de la transformación; sin esto el texto inclinado se pixela en pantallas de alta densidad.
- La voz usa Web Speech cuando existe (iPhone, Windows, navegadores) y el plugin nativo `@capacitor-community/text-to-speech` 6.1.0 en la app Android, llamado mediante el puente nativo de Capacitor, sin incluir `@capacitor/core` en el paquete web. Si no hay voz, EKO K’iin muestra el globo igual.
- Curva de rentas de forma clásica y 16 cartas por mazo para acercar la partida al ritmo de los juegos clásicos del género sin copiar tablas, nombres ni textos de Monopoly®.
