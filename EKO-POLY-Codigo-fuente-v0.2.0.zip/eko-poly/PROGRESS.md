# Estado de EKO POLY

Entrega en desarrollo. No cumple todavía la definición de terminado del prompt maestro.

## Implementado
- Referencia exacta de EKO RUMMY descargada sin modificarla.
- Extracción de autenticación, lectura TRON, candado y simulador de custodia.
- Motor serializable, tablero original de 40 casillas, Cacao, cartas, subastas, grupos, construcción, hipotecas, negociación y quiebra.
- Práctica contra IA de 4 parámetros, guardado local, tablero SVG táctil y adaptable.
- Servidor autoritativo de salas privadas con reconexión, decisiones por temporizador, persistencia SQLite y prueba de dados al terminar.
- Proyectos nativos Android/iOS generados y empaquetado Windows definido.

## Verificado en esta sesión
- 24 pruebas unitarias en verde; cobertura del motor 97.27% de líneas y 94.27% de ramas.
- Pruebas de navegador en tres perfiles de pantalla y sala de cuatro clientes, con rechazos de acciones inválidas.
- 10,000 simulaciones de invariantes; 9,999 terminaron por reloj sintético. No equivalen a balance ni duración real comprobada.
- EXE compilado y ejecutado en prueba oculta; APK compilado y firma de depuración v1/v2 verificada; AAB generado sin firma de distribución.
- Auditoría de dependencias de producción sin avisos tras actualizar ws y Ajv.
- Proyectos iOS y workflows de simulador/IPA firmado preparados, sin ejecutar.

## Pendientes para la entrega completa
- Repositorio remoto `aldoBS1001/eko-poly`: falta acceso de escritura autenticado.
- Firmado comercial y prueba en dispositivos físicos. El propietario confirmó Apple Developer y GitHub Actions; falta conectar GitHub y verificar secrets Apple para ejecutar el workflow firmado. No hay IPA ni publicación en tiendas.
- Regla de subasta de edificios escasos, selección de levantar hipotecas recibidas, contraoferta con temporizador y orden inicial mediante tiradas con desempate.
- IA de negociación más completa; balance medido de 100,000 partidas por modo y duración objetivo. Las primeras pruebas detectan partidas que pueden prolongarse.
- Cuentas registradas, matchmaking, Elo, torneos multimesa, chat, administración, PostgreSQL y recuperación probada bajo caída.
- Contratos de custodia, indexador, firma de wallet, KYC, pruebas Nile con TxIDs, auditoría y controles económicos completos.
- Cobertura requerida, 10,000 partidas aleatorias, pruebas físicas de accesibilidad/rendimiento y carga en Oracle.
- Inglés completo de cartas/reglas/historial; tutorial guiado dentro de la partida.

## Probar
Node 24. Instalar con pnpm, ejecutar `pnpm test`, `pnpm build`, `pnpm start` y abrir `http://127.0.0.1:4178`. El HTML de `build/` incluye la práctica sin instalación. Ver `docs/REPORTE_PRUEBAS.md` para resultados reales al cierre de la sesión.

## Actualización visual Business Shop
- Siete imágenes originales extraídas del PDF del usuario: logotipos, presentadora, mascota y productos. Integradas en portada, cabecera, galería y centro del tablero.
- Recursos incrustados para uso sin conexión; EXE, HTML, APK de pruebas y AAB sin firma recompilados. Recursos iOS sincronizados, sin IPA.
- Revisión visual y pruebas de interfaz en tamaños Windows, iPhone y Android correctas. APK/AAB y proyecto iOS contienen exactamente el JavaScript actualizado.

## Actualización 0.2.0: tablero clásico en 3D, sonido y voz
- Tablero circular sustituido por el tablero cuadrado de 40 casillas del género (`apps/web/board.mjs`): esquinas, franjas de color, texto rotado por lado, placa del dueño con la renta vigente, sello de hipoteca, iconos propios para puertos, servicios, cartas y cuotas.
- Escena 3D con CSS: tablero inclinado con perspectiva, fichas y edificios de pie, dados 3D, cámara que sigue la ficha del jugador. El tablero 3D se dibuja a 2–3 veces su tamaño para que el texto sea nítido en iPhone y Android. Vista plana disponible.
- Animaciones de jugada: dados, avance casilla por casilla, cartas que se voltean, monedas, escarcha, banderola de dobles, confeti y podio final. Respeta "reducir movimiento".
- Audio sintetizado (`apps/web/audio.mjs`), narración con voz del dispositivo y globo de EKO K’iin (`apps/web/voice.mjs`), vibración breve en Android, ajustes persistentes.
- Selección de ficha, orden inicial por tirada, 16 cartas por mazo y curva de rentas de forma clásica (ver docs/REPORTE_BALANCE.md).
- Verificado en esta sesión: 24 pruebas unitarias en verde, `scripts/e2e.mjs` en perfiles Windows, iPhone 12 y Pixel 7 (Chromium), `scripts/integration.mjs` con sala de 4 clientes, sala en línea de 2 navegadores con animaciones y capturas de pantalla de tablero 3D, vista plana, cartas, subasta, construcción, congelamiento y podio.
- No verificado: voz y rendimiento 3D en iPhone y Android físicos, Safari/WebKit real, EXE y APK recompilados con esta versión. Recompilar con `pnpm build`, `pnpm exec cap sync` y los scripts de Windows/Android.
