package com.businessshop.ekopoly;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
