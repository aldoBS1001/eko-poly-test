# Balance pendiente

La campaña de invariantes ejecutó 10,000 partidas en modo Tiempo límite, con 2 a 6 IA y un máximo sintético de 100 acciones por partida. Registró 999,975 acciones, 9,999 finales por reloj adelantado y un final natural. El primer asiento figura entre los ganadores en 3,310 casos, pero esta muestra mezcla tamaños de mesa y empates y no demuestra ventaja de posición.

Estos datos prueban conservación de Cacao y edificios durante esas transiciones. No representan minutos reales ni sirven para validar las metas de duración o retorno. Las pruebas de partidas largas también detectaron que la distribución de grupos puede prolongar las partidas.

## Curva de rentas de forma clásica (versión 0.2.0)

Se reemplazó la renta casi lineal (hotel ≈ 2.6 veces el precio) por una curva como la de los juegos clásicos del género: renta base de 6 a 12% del precio y salto fuerte con la tercera casa (≈ 3 veces el precio) hasta hotel ≈ 4.5–4.8 veces el precio. Precios y costos de construcción no cambian. Se pasó de 8 a 16 cartas por mazo.

Medición comparable: 250 partidas por modo, 2 a 6 IA de nivel Ceiba, máximo 4,000 acciones, misma semilla.

| Modo | Final natural antes | Final natural ahora | Rondas (mediana) antes | Rondas (mediana) ahora |
|---|---|---|---|---|
| Clásico | 36.4% | 45.6% | 109 | 59 |
| Corto | 41.2% | 44.0% | 74 | 48 |

Con 5 y 6 jugadores la mayoría de partidas sigue sin terminar sola porque la IA no propone intercambios y rara vez completa grupos. No es una certificación de balance.

Pendientes: 100,000 partidas por modo con IA de negociación mejorada, separar resultados por cantidad de jugadores, intervalo de confianza de la ventaja inicial, duración de 25–40 minutos y retorno por grupo con tres casas dentro de ±25%.
