# Despliegue

La implementación se verificó localmente en Windows. No está publicada en Oracle, Render ni poly.ekokiin.com. No se modificó el despliegue de EKO RUMMY.

En un servidor con Node 24: instalar dependencias con lockfile, ejecutar tests y build, definir un secreto de sesión fuera del repositorio y lanzar `apps/server/server.mjs`. Proteger el puerto con un proxy HTTPS que admita WebSocket y definir PUBLIC_ORIGIN al origen público exacto.

SQLite es el único adaptador operativo. No iniciar varias réplicas compartiendo la base sin implementar coordinación y PostgreSQL. Las pruebas de 200 mesas, latencia p95 y Oracle siguen pendientes.
