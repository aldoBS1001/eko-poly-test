# Reutilización

Origen: `aldoBS1001/eko-rummy`, commit `9b4ac9063c4d4c1a0164a68fd634e3a56e319785`.

| Origen | Destino | Estado |
|---|---|---|
| apps/server/src/auth.ts | packages/eko-core/auth.ts | Copia exacta; scrypt, tokens HMAC, RateLimiter usados por el servidor |
| apps/server/src/web3/tron.ts | packages/eko-core/web3/tron.ts | Copia exacta; validación y formato probados, sin transacciones |
| apps/server/src/betting/gate.ts | packages/eko-core/betting/gate.ts | Copia exacta; candado probado; integración económica no habilitada |
| apps/server/src/betting/escrowSim.ts | packages/eko-core/betting/escrowSim.ts | Copia exacta de referencia; no equivale a contrato |
| apps/server/src/config.ts | packages/eko-core/config.ts | Copia exacta para conservar tipos; servidor nuevo configura sus propios puertos |
| capacitor.config.json | capacitor.config.json | Adaptado al nombre e identificador nuevos |
| Motor, interfaz, salas, RNG, empaquetado Windows | Rutas respectivas | Nuevos |

Pendientes de extracción/adaptación: KYC, chat, almacenamiento PostgreSQL, torneos, tienda y controles de elegibilidad. No se afirma haber reutilizado esos módulos todavía. El SHA y las rutas hacen comprobable el origen.
