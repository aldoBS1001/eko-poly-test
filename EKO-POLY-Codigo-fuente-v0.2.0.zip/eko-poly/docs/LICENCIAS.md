# Recursos y procedencia

| Recurso | Procedencia / uso |
|---|---|
| Tablero cuadrado SVG de 40 casillas, iconos de casillas, fichas, casas, hoteles, dados, mazos, cartas, nombres de solares, CSS e icono solar EKO POLY | Generados como código original para este proyecto |
| Marcas EKO K’iin, EKO POLY y Business Shop | Facilitadas en el encargo; confirmar derechos de publicación con la empresa |
| Módulos eko-core | Reutilizados del repositorio del usuario; origen exacto en REUSE_MAP |
| Tipografía del tablero: Barlow Condensed 500–800 | SIL Open Font License 1.1 (The Barlow Project Authors). Archivos woff2 en `apps/web/fonts/` con su licencia `OFL-BarlowCondensed.txt`; se incrustan en el CSS compilado |
| Tipografía de interfaz | Familias del sistema |
| Imágenes PNG/ICO | Geometría solar original, generadas por scripts/branding.py; fuentes del sistema rasterizadas en este equipo |
| Efectos de sonido y marimba de fondo | Sintetizados en el dispositivo con Web Audio (`apps/web/audio.mjs`); no hay archivos de audio |
| Voz de EKO K’iin | Voz del sistema del dispositivo (Web Speech). En la app Android se usa `@capacitor-community/text-to-speech` 6.1.0, licencia MIT. No se redistribuyen voces |
| Capacitor | MIT; revisar avisos de dependencias al distribuir |
| ws, esbuild, Ajv | Licencias de sus paquetes; conservar avisos al empaquetar |

No se importó arte de terceros ni arte aprobado de Ara Digital; no se proporcionó una licencia de ese personaje. No hay música redistribuida.

El juego sigue la estructura genérica de los juegos de propiedades (tablero cuadrado de 40 casillas, grupos de color, casas, hoteles, títulos y dos mazos). No usa nombres, logotipos, ilustraciones, fichas ni textos de cartas de Monopoly®, marca de Hasbro; mantener esa separación al agregar arte o textos nuevos.
