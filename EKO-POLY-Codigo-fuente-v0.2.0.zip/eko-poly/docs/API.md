# API actual

HTTP y WebSocket comparten puerto 4178 por defecto. Cualquier despliegue público requiere HTTPS y PUBLIC_ORIGIN.

| Ruta | Comportamiento |
|---|---|
| GET /api/health | Estado, versión, salas y módulo económico deshabilitado |
| POST /api/guest | JSON con `name`; devuelve `id` y token HMAC |
| GET /api/proof/:code | Solo tras finalizar: semilla, compromiso, clientSeeds, tiradas y verificación |

WebSocket: primer mensaje `{type:"auth",token}`; luego `create` con `clientSeed` de 32 bytes hex, `join` con `code` y semilla, `start` por anfitrión o `action` con `revision` y la intención en `action`. El servidor sobrescribe jugador y dados. Los clientes no pueden enviar `timeout` ni `time_limit`.

Respuestas: `auth`, `room`, `state` o `error`. El estado es serializable; las revisiones evitan acciones sobre una mesa obsoleta. Las semillas privadas nunca se incluyen en snapshots del cliente. Reconectar exige la misma sesión y código de sala.

No existen endpoints de depósitos, custodia, KYC, firma de wallet, administración o cuentas permanentes en esta versión.
