# Operación local

No hay panel administrativo todavía. Ejecutar `pnpm start` inicia servidor y SQLite bajo `data/`. Configurar `PORT`, `HOST`, `PUBLIC_ORIGIN` y `SESSION_SECRET` en el entorno. No imprimir ni compartir el secreto.

Consultar `/api/health` para comprobar disponibilidad. Respaldar SQLite con el servidor detenido para conservar salas y semillas. No copiar `data/` a repositorios o paquetes de distribución. Eliminar datos implica perder sesiones y pruebas de partidas: no hacerlo durante mesas activas.

Pendientes: panel, permisos de administrador, métricas, alertas, backups consistentes en línea, políticas de retención y borrado individual.
