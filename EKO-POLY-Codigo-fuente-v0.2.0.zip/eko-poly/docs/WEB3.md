# Estado Web3

Se reutilizó, sin cambios, el lector TRON de RUMMY (commit indicado en REUSE_MAP). Validación Base58Check y formato de enteros a 18 decimales tienen pruebas locales. El servidor de juego no habilita movimientos económicos.

Token de referencia: `TMNKYEbXGJGFPaZXs8tBER6gMiRvjKtUiU`. Los metadatos heredados documentan una revisión de RUMMY; no se realizó una nueva verificación on-chain durante esta sesión.

Pendientes: prueba de propiedad con firma, adaptadores de wallets, reto/nonce/expiración, KYC y elegibilidad, contratos TVM, indexador de bloques solidificados, conciliación, liquidación con KMS, energía y retiros. No hay direcciones de contratos EKO POLY ni TxIDs de Nile. No presentar el simulador como custodia real.

Fuera del código: verificar el fuente del token en TronScan, crear tesorería multifirma, custodiar OPERADOR, obtener auditoría independiente y las aprobaciones de operación. Mainnet y fondos reales requieren aprobación explícita.
