# Adopción futura en EKO RUMMY

No se ejecutó ninguna migración. La copia de referencia permanece sin modificaciones.

Antes de adoptar eko-core, crear una rama de RUMMY y comparar cada archivo contra el commit de origen documentado. Mantener compatibilidad de sesiones, configuración y firmas; ejecutar primero sus pruebas y luego las de POLY. No sustituir el motor de fichas por el motor de propiedades.

No adoptar el almacenamiento o salas de POLY como reemplazo directo: sus modelos de estado y protocolo son nuevos y todavía no cubren los torneos, KYC ni operación de RUMMY. Publicar una versión compartida solo después de estabilizar interfaces y completar pruebas de regresión en ambos productos.
