# Contratos

EkoTableEscrow y EkoTournamentVault no están implementados ni desplegados. `packages/eko-core/betting/escrowSim.ts` es una copia del simulador de referencia, no Solidity ni un servicio que pueda recibir fondos.

El trabajo pendiente debe conservar los estados abierta/bloqueada/liquidada/reembolsada, retiros pull, límite de comisión 1,000 bps, timelock de 48 horas, reembolso de emergencia y pausa que nunca bloquee retiros. Deben demostrarse el invariante de balance, protección de reentrada, cobertura y análisis estático antes de Nile y auditoría externa antes de Mainnet.
