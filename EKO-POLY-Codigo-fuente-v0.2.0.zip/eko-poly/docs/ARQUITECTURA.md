# Arquitectura actual

`packages/engine/index.mjs` reduce acciones sobre copias del estado. No usa reloj, red ni RNG. `legalActions` informa las decisiones válidas; `assertState` comprueba conservación del Cacao (incluido banco con saldo negativo) y del inventario.

`apps/web/app.mjs` comparte el motor en práctica offline, genera dados con Web Crypto, guarda localmente y presenta tablero SVG, decisiones y patrimonio. Las salas privadas envían intenciones al servidor.

`apps/server/server.mjs` usa HTTP de Node y ws, sesiones HMAC y RateLimiter reutilizados. Genera dados, valida turnos y versiones, y aplica la transición antes de difundirla. SQLite conserva cada instantánea y evento en una transacción. El rollback restaura estado/nonce si falla la escritura. No se ha certificado recuperación frente a todos los tipos de caída.

`packages/fair` genera HMAC-SHA256 con rechazo de bytes sesgados; las semillas del cliente se incluyen en el mensaje con codificación JSON para separar campos. El compromiso se publica al crear la sala y la semilla solo se revela tras el final.

Producción distribuida, PostgreSQL, métricas completas, torneos y procesamiento de contratos son pendientes. No hay escalado horizontal ni benchmark en Oracle.
