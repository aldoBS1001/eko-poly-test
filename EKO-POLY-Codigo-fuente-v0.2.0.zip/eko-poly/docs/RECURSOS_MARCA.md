# Imágenes de Business Shop y EKO K’iin

Fuente: Presentación General BS EKO.pdf, proporcionada por el usuario.
Los recursos se extrajeron del PDF conservando sus gráficos y transparencia disponible.

- business-shop.png: página 1, X11 (logotipo).
- eko-kiin.png: página 5, X69 (logotipo).
- presentadora.png: página 1, X8.
- mascota.png: página 21, X327.
- pila-semilla.png: página 15, X273.
- reciclaje.png: página 17, X294.
- macetas.png: página 18, X308.

Los recursos se incorporan como data URLs mediante esbuild para funcionar también en el HTML autónomo, EXE y paquetes nativos sin descargas externas. Se muestran en cabecera, portada, centro del tablero y galería de marca. Las ilustraciones son decorativas; no cambian las reglas de juego ni las fichas de cada jugador.

Actualización: el emblema dorado y plateado suministrado como Foto 1.jpg sustituye el logotipo Business Shop visible. Archivo original conservado en business-shop-emblema.jpg; encuadre circular mediante CSS, sin modificar la imagen.

Se añadieron las dos fotografías enviadas con www.ekokiin.com.mx: eko-presentacion.jpg y eko-token.jpg. Se conservan completas en una sección de marca, con enlace HTTPS externo explícito y texto de Cacao virtual. No se habilitaron compras de tokens ni conexión de wallet.

Actualización 0.2.0: la mascota de EKO K’iin (mascota.png) aparece de pie en el centro del tablero, rebota y habla con globos de diálogo y la voz del dispositivo; también celebra en el podio final. El tablero, fichas, iconos y cartas son dibujos SVG originales; la tipografía del tablero es Barlow Condensed (OFL 1.1, ver LICENCIAS.md).
