# Plataformas y distribución

Identificador: `com.businessshop.ekopoly`. Nombre: EKO POLY. Versión de desarrollo: 0.1.0.

## Android

Proyecto Capacitor/Gradle estándar. `assembleDebug` crea un APK instalable con firma de depuración. `bundleRelease` crea un AAB sin firma de publicación; necesita el certificado del propietario y verificación antes de Google Play. No se publica automáticamente. El APK incluye práctica sin conexión.

## iPhone

Proyecto Xcode en `ios/App`. En macOS: instalar dependencias, `pnpm build`, `pnpm exec cap sync ios`, abrir `App.xcworkspace`, seleccionar el equipo Apple Developer y ejecutar en el dispositivo. Registrar el Bundle ID. Para distribución se necesitan firma, perfil de aprovisionamiento y archivo exportado por Xcode.

El propietario confirmó que tiene Apple Developer y GitHub Actions. Se incluyen dos workflows manuales: `ios.yml` compila simulador; `ios-signed.yml` archiva y exporta un IPA firmado para App Store Connect, con destino **export**, sin subirlo a Apple. El segundo requiere los secrets `ASC_KEY_ID`, `ASC_ISSUER_ID`, `ASC_KEY_P8`, `APPLE_TEAM_ID` en el repositorio y una llave Apple con permisos de firma/aprovisionamiento suficientes. Nunca poner sus valores en archivos ni mensajes. Una llave que no permita administrar certificados no basta para la firma automática; en ese caso se necesita configurar el certificado/perfil del equipo.

Ninguno de los workflows se ejecutó. Falta conexión autenticada a GitHub y verificar permisos de firma. El IPA exportado para App Store no se instala directamente: posteriormente requiere distribución autorizada por TestFlight/App Store. No hay IPA generado ni subida a tiendas.

## Windows

El EXE incluye el HTML y usa el .NET Framework de Windows. Sirve contenido en `127.0.0.1:4180` y abre el navegador en modo aplicación. No es un instalador MSI y no está firmado con certificado comercial. Se prueba el servidor local y el contenido embebido; no se afirma cobertura de todas las versiones de Windows.

## Tiendas

Esta versión no incluye funciones económicas ni cosméticos de pago. No tiene rutas para activar Web3/KYC/Stripe. No hay publicación automática. Siguen pendientes los formularios de privacidad de las tiendas, pruebas físicas, revisión del propietario y firma de distribución.
