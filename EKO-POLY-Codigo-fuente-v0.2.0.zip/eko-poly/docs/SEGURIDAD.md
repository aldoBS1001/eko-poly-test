# Seguridad comprobada y pendiente

Se usa identidad HMAC de RUMMY, limitación de peticiones, validación del origen de WebSocket, límite de tamaño y revisión de la partida. Los dados y el actor recibidos del cliente no se consideran autoritativos. Se probaron rechazos de acciones fuera de turno, falsificación de actor y acciones reservadas al servidor.

La semilla se guarda únicamente en la base del servidor y se revela al finalizar. Las escrituras de sala y eventos se hacen en transacción. Los eventos incluyen hash previo. El secreto de sesión se genera en `data/` cuando no hay configuración externa y se excluye de Git.

Limitaciones: no hay auditoría OWASP ASVS 2, revisión de contratos, despliegue TLS comprobado, protección distribuida, anticolusión, cuotas por cuenta registrada ni pruebas de recuperación forzada. La entrega no se certifica para producción. Los APK son de depuración y el EXE no lleva firma comercial.
