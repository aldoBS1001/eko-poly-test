# Reporte de pruebas

Fecha local: 27 de octubre de 2026. Entorno: Windows, Node 24.19.0. Versión: 0.1.0.

## Resultados observados

| Verificación | Resultado |
|---|---|
| Pruebas unitarias (configuración, motor, RNG y módulos reutilizados) | 24/24 en verde |
| Cobertura del motor index.mjs | 97.27% líneas; 94.27% ramas |
| Cobertura global de archivos instrumentados | 88.40% líneas; no equivale a cobertura del producto completo |
| Motor contra IA en unitarias | 100 simulaciones de hasta 2,000 acciones; invariantes comprobados, no se exige final natural |
| Campaña adicional | 10,000 partidas de tiempo límite, 999,975 acciones; cero fallos de invariantes; 9,999 finales por reloj sintético y 1 natural |
| Dados | Verificación de 1,000 tiradas, detección de manipulación y chi-cuadrada sobre 60,000 dados |
| Navegador | Tres perfiles: Windows, iPhone 12, Pixel 7, todos sobre Chromium/Edge; sin desbordamiento horizontal ni errores JS; crear, guardar, reanudar, comprar e hipotecar |
| Sala privada | 4 invitados autenticados, creación/unión, dados autoritativos, rechazo de acciones reservadas y fuera de turno, semilla oculta |
| Windows | Compilación EXE y prueba real del servidor local/HTML embebido en modo oculto |
| Android | Gradle assembleDebug y bundleRelease correctos; APK com.businessshop.ekopoly, 0.1.0, minSdk 23, targetSdk 35; firmas v1/v2 verificadas por apksigner |
| Dependencias de producción | Auditoría posterior a actualizar ws 8.22.0 y Ajv 8.20.0: 0 avisos |
| EKO RUMMY | Copia de referencia limpia según git status; no se modificó el proyecto original |

## Evidencia reproducible

`build/unit-test-results.txt`, `build/e2e-results.json`, `build/integration-results.json`, `build/simulation-results.json`, `build/windows-test.json`, `build/android-signature.txt`, `build/android-package.txt`, `build/dependency-audit.json` y capturas en `build/screenshots/`.

Comandos: `pnpm test`, `node --test --test-isolation=none --experimental-test-coverage tests/*.test.mjs`, `node scripts/e2e.mjs` (requiere Edge y Playwright), `node scripts/integration.mjs` (servidor en 4178), `node scripts/simulate.mjs 10000 100`.

## No demostrado

No se probó en Android/iPhone físicos, Safari/WebKit real, ni App Store. No hay compilación iOS ejecutada. Los perfiles móviles de Chromium no son emuladores nativos. No se ejecutaron torneos de 16, balance de 100,000 partidas por modo, carga en Oracle, recuperación forzada, Nile, fuzz de Solidity, Slither o auditoría externa. El APK es de depuración; el AAB carece de firma de distribución. No declarar cumplida la definición de terminado del PDF.
