# Vista de iPhone mediante Safari

URL temporal verificada: https://psi-colour-transaction-union.trycloudflare.com/

Se sirve únicamente dist mediante scripts/mobile-preview.mjs en 127.0.0.1:4179, con lista explícita de archivos públicos. El túnel cloudflared corre oculto e independiente de EKO RUMMY. No reiniciar su túnel.

Esta vista ofrece práctica local con IA. No incluye salas en línea. La disponibilidad inicial depende de la PC y del túnel. Tras cargar, el service worker guarda el juego para práctica sin conexión; el navegador puede eliminar su almacenamiento. Se verificó HTTPS, service worker y comienzo de partida offline en Chromium con tamaño de iPhone; no acredita instalación física en iOS.

En Safari: Compartir, Agregar a pantalla de inicio, Abrir como app web si aparece, Agregar. Nombre EKO POLY. El propietario debe realizar la confirmación en el dispositivo.
