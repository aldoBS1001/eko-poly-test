# Reglas de esta versión

De dos a seis participantes recorren un tablero cuadrado de cuarenta casillas: cuatro esquinas (Amanecer K’iin, Wallet congelada, La Ceiba y ¡Congela tu wallet!), 22 solares en 8 grupos de color, 4 puertos, 2 servicios, 2 cuotas y 6 casillas de cartas. El Cacao representa recursos del juego y no se canjea. En práctica puedes elegir de uno a cinco rivales automáticos y tu ficha (Sol, Pirámide, Tortuga, Cacao, Ceiba o Pila EKO).

Cada jugador inicia con 1,500 Cacao. En práctica el orden inicial se decide tirando dos dados: el tiro más alto empieza y los empates vuelven a tirar. En las salas en línea el orden lo baraja el servidor. En Corto y Tiempo límite cada jugador recibe dos solares aleatorios y paga su precio. Cada paso por Amanecer K’iin paga 200.

En tu turno lanza dos dados (botón o tocando los dados del tablero) y resuelve el lugar. Puedes comprar un solar libre; si lo rechazas, todos pueden pujar. La propiedad queda libre si nadie ofrece. El servidor cierra subastas al agotarse el tiempo. Los dobles permiten repetir; tres dobles seguidos congelan la wallet sin cobrar salida.

Los visitantes pagan renta a su dueño. Un solar hipotecado no genera renta. Un grupo completo duplica la renta de solares sin edificios; puertos y servicios usan las tablas de configuración. La renta crece como en los juegos clásicos del género: baja sin edificios y con un salto fuerte a partir de la tercera casa (ver `scripts/generate-board.mjs`).

Para construir necesitas todo el grupo sin hipotecas. Reparte las casas de forma pareja. El modo Clásico requiere cuatro casas antes del hotel; los modos Corto y Tiempo límite requieren tres. El banco cuenta con 32 casas y 12 hoteles. Vender devuelve la mitad del costo. No puedes hipotecar mientras existan edificios en el grupo. La hipoteca entrega la mitad del precio; levantarla cobra además 10%.

Hay dos mazos de 16 cartas. Oráculo K’iin mueve por el tablero (a Amanecer, a puertos y solares, tres pasos atrás), da o cobra Cacao, congela la wallet o entrega una salida libre. Tequio reparte y pide aportaciones a la comunidad, cobra mantenimiento por edificio y también tiene su salida libre. La salida libre se conserva hasta usarla y luego vuelve a su mazo.

Las ofertas intercambian Cacao y propiedades sin edificios. El motor admite también tarjetas. La interfaz de esta versión ofrece Cacao y propiedades; contraofertas y tarjetas en pantalla siguen pendientes. Recibir una hipoteca cobra inmediatamente 10% y la conserva hipotecada.

Para descongelar la wallet puedes pagar 50, usar una salida libre o intentar dobles. Si fallas el tercer turno pagas y avanzas.

Cuando debes más efectivo del que tienes, puedes vender edificios e hipotecar. Solo se declara quiebra si el patrimonio liquidable no basta. El acreedor recibe activos; si es el banco, se subastan los solares. Clásico termina con un sobreviviente; Corto, con la segunda quiebra o un sobreviviente; Tiempo límite clasifica por patrimonio, luego efectivo y número de propiedades.

La elección de levantar inmediatamente las hipotecas recibidas y la subasta de edificios escasos no están terminadas. No considerar este reglamento evidencia de cumplimiento completo del PDF.
