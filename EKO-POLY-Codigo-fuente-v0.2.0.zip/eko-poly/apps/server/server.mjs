import http from 'node:http';import {readFileSync,existsSync,mkdirSync,writeFileSync} from 'node:fs';import {join,resolve,extname} from 'node:path';
import {randomBytes,randomUUID,createHash} from 'node:crypto';import {DatabaseSync} from 'node:sqlite';import {WebSocketServer,WebSocket} from 'ws';
import {fileURLToPath} from 'node:url';
import {createGame,apply,board,cards,rules,legalActions} from '../../packages/engine/index.mjs';import {chooseAction} from '../../packages/engine/ai.mjs';
import {newSeed,commitment,roll,shuffle,verify} from '../../packages/fair/index.mjs';
import {signToken,verifyToken,RateLimiter} from '../../packages/eko-core/auth.ts';
import {validateConfig} from '../../config/validate.mjs';
validateConfig();
const ROOT=fileURLToPath(new URL('../../',import.meta.url)),dist=join(ROOT,'dist'),data=process.env.DATA_DIR||join(ROOT,'data');mkdirSync(data,{recursive:true});
const secretPath=join(data,'session-secret');if(!process.env.SESSION_SECRET&&!existsSync(secretPath))writeFileSync(secretPath,randomBytes(48).toString('hex'),{mode:0o600});const secret=process.env.SESSION_SECRET||readFileSync(secretPath,'utf8');
const db=new DatabaseSync(join(data,'poly.sqlite'));db.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS rooms(code TEXT PRIMARY KEY, body TEXT NOT NULL); CREATE TABLE IF NOT EXISTS events(code TEXT, revision INTEGER, previous TEXT, hash TEXT, body TEXT, PRIMARY KEY(code,revision));');
const rooms=new Map(db.prepare('SELECT * FROM rooms').all().map(r=>[r.code,JSON.parse(r.body)]));const sockets=new Set(),limiter=new RateLimiter(40,4);
const configHash=createHash('sha256').update(JSON.stringify({board,rules,cards})).digest('hex');
function persist(r,event=null){db.exec('BEGIN');try{db.prepare('INSERT INTO rooms VALUES(?,?) ON CONFLICT(code) DO UPDATE SET body=excluded.body').run(r.code,JSON.stringify(r));if(event){const previous=db.prepare('SELECT hash FROM events WHERE code=? ORDER BY revision DESC LIMIT 1').get(r.code)?.hash||'genesis',body=JSON.stringify(event),hash=createHash('sha256').update(`${previous}:${r.code}:${r.state.revision}:${body}`).digest('hex');db.prepare('INSERT INTO events VALUES(?,?,?,?,?)').run(r.code,r.state.revision,previous,hash,body);}db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}}
const publicRoom=r=>({code:r.code,host:r.host,players:r.players,commitment:r.commitment,configHash});
function packet(r){return r.state?{type:'state',state:r.state,room:publicRoom(r),deadline:r.deadline}:{type:'room',room:publicRoom(r)};}
const send=(s,m)=>{if(s.readyState===WebSocket.OPEN)s.send(JSON.stringify(m));};
function broadcast(r){for(const s of sockets)if(s.room===r.code)send(s,packet(r));}
const reply=(res,status,body)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body));};
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; media-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
 const url=new URL(req.url,'http://localhost');
 if(!limiter.take(req.socket.remoteAddress)){reply(res,429,{error:'Demasiadas solicitudes.'});return;}
 if(url.pathname==='/api/health'){reply(res,200,{ok:true,version:'0.1.0',rooms:rooms.size,economicEnabled:false});return;}
 if(url.pathname==='/api/guest'&&req.method==='POST'){
  if(req.headers.origin&&req.headers.origin!==process.env.PUBLIC_ORIGIN&&req.headers.origin!==`http://${req.headers.host}`){reply(res,403,{error:'Origen inválido.'});return;}
  try{let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>4096)throw Error('Solicitud demasiado grande.');}const b=JSON.parse(raw),id=randomUUID(),name=typeof b.name==='string'?b.name.trim().slice(0,20):'Explorador';if(!name)throw Error('Nombre requerido.');reply(res,200,{id,token:signToken({sub:id,name,role:'guest'},secret)});}catch(e){reply(res,400,{error:e.message});}return;
 }
 if(url.pathname.startsWith('/api/proof/')){const r=rooms.get(url.pathname.split('/').at(-1));if(!r||r.state?.phase!=='over'){reply(res,409,{error:'La semilla se revela al terminar.'});return;}const proof={seed:r.seed,commitment:r.commitment,matchId:r.code,clientSeeds:r.players.map(p=>p.clientSeed),rolls:r.rolls};reply(res,200,{...proof,valid:verify(proof)});return;}
 if(url.pathname.startsWith('/api/')){reply(res,404,{error:'Ruta no disponible. El módulo económico permanece deshabilitado.'});return;}
 if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);res.end();return;}
 try{const p=decodeURIComponent(url.pathname),path=resolve(dist,'.'+(p==='/'?'/index.html':p));if(!path.startsWith(dist+'\\')&&!path.startsWith(dist+'/'))throw Error('Invalid path');const bytes=readFileSync(path),types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};res.writeHead(200,{'Content-Type':types[extname(path)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(req.method==='HEAD'?undefined:bytes);}catch{res.writeHead(404);res.end('No encontrado');}
});
const wss=new WebSocketServer({noServer:true,maxPayload:16384});
server.on('upgrade',(req,socket,head)=>{const allowed=process.env.PUBLIC_ORIGIN||`http://${req.headers.host}`;if(req.headers.origin!==allowed||!limiter.take(req.socket.remoteAddress)){socket.destroy();return;}wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));});
wss.on('connection',(socket,req)=>{
 sockets.add(socket);socket.ip=req.socket.remoteAddress;
 const authTimeout=setTimeout(()=>{if(!socket.user)socket.close();},5000);socket.on('close',()=>{clearTimeout(authTimeout);sockets.delete(socket);});
 socket.on('message',raw=>{try{
  if(!limiter.take(socket.user?.sub||socket.ip))throw Error('Demasiadas acciones.');const m=JSON.parse(raw);
  if(m.type==='auth'){const user=verifyToken(m.token,secret);if(!user){send(socket,{type:'error',code:'AUTH',message:'Sesión inválida.'});return;}socket.user=user;clearTimeout(authTimeout);send(socket,{type:'auth',id:user.sub});return;}
  if(!socket.user)throw Error('Inicia una sesión.');const user=socket.user;
  if(m.type==='create'){
   if([...rooms.values()].filter(r=>r.host===user.sub&&r.state?.phase!=='over').length>=3)throw Error('Ya tienes tres salas activas.');
   if(rooms.size>=500)throw Error('Servidor lleno.');
   if(!/^[a-f0-9]{64}$/i.test(m.clientSeed))throw Error('Semilla del cliente inválida.');
   let code;do{code=randomBytes(3).toString('hex').toUpperCase();}while(rooms.has(code));
   const seed=newSeed(),r={code,host:user.sub,seed,commitment:commitment(seed),players:[{id:user.sub,name:user.name,clientSeed:m.clientSeed}],state:null,rolls:[],deadline:0};rooms.set(code,r);socket.room=code;persist(r);broadcast(r);return;
  }
  if(m.type==='join'){
   const r=rooms.get(m.code);if(!r)throw Error('Sala no encontrada.');
   if(!r.players.some(p=>p.id===user.sub)){if(r.state||r.players.length>=6)throw Error('La sala ya comenzó o está llena.');if(!/^[a-f0-9]{64}$/i.test(m.clientSeed))throw Error('Semilla inválida.');r.players.push({id:user.sub,name:user.name,clientSeed:m.clientSeed});}
   socket.room=r.code;persist(r);broadcast(r);return;
  }
  const r=rooms.get(socket.room);if(!r)throw Error('Entra en una sala.');
  if(m.type==='start'){
   if(r.host!==user.sub||r.state||r.players.length<2)throw Error('No se puede iniciar.');
   const seeds=r.players.map(p=>p.clientSeed),opts={seed:r.seed,code:r.code};
   r.state=createGame({players:r.players.map(({id,name})=>({id,name,bot:false})),mode:'timed',matchId:r.code,configHash,deadline:Date.now()+rules.timeLimitMinutes*60000,order:shuffle(r.players.map(p=>p.id),r.seed,r.code,seeds,'order'),propertyOrder:shuffle(board.filter(t=>t.type==='property').map(t=>t.id),r.seed,r.code,seeds,'properties'),decks:{oracle:shuffle(cards.oracle,r.seed,r.code,seeds,'oracle'),community:shuffle(cards.community,r.seed,r.code,seeds,'community')}});r.deadline=Date.now()+rules.decisionSeconds*1000;persist(r,{type:'start',configHash,commitment:r.commitment,state:r.state});broadcast(r);return;
  }
  if(m.type==='action'){
   if(!r.state||m.revision!==r.state.revision){send(socket,packet(r));throw Error('La mesa cambió. Vuelve a intentar.');}
   const a=m.action;if(!a||typeof a!=='object'||['timeout','time_limit'].includes(a.type))throw Error('Acción inválida.');
   run(r,{...a,player:user.sub});return;
  }
  throw Error('Mensaje desconocido.');
 }catch(e){send(socket,{type:'error',message:e.message});}});
});
function run(r,action){
 const a={...action};let thrown=null;
 if(a.type==='roll'){thrown=roll(r.seed,r.code,r.players.map(p=>p.clientSeed),r.rolls.length);a.dice=thrown;}
 const result=apply(r.state,a),oldState=r.state,oldDeadline=r.deadline;
 r.state=result.state;if(thrown)r.rolls.push(thrown);
 // Out-of-turn offers cannot reset the active player's decision timer.
 if(!['trade_offer','trade_reply'].includes(a.type))r.deadline=Date.now()+(r.state.phase==='auction'?rules.auctionSeconds:rules.decisionSeconds)*1000;
 try{persist(r,{action:a,events:result.events});}catch(e){r.state=oldState;r.deadline=oldDeadline;if(thrown)r.rolls.pop();throw e;}
 broadcast(r);
}
const tick=setInterval(()=>{for(const r of rooms.values()){
 if(!r.state||r.state.phase==='over')continue;
 try{
  if(r.state.mode==='timed'&&Date.now()>=r.state.deadline){run(r,{type:'time_limit'});continue;}
  if(Date.now()<r.deadline)continue;
  if(['auction','buy','tax','end'].includes(r.state.phase)){run(r,{type:'timeout'});continue;}
  const id=r.state.phase==='debt'?r.state.debt.player:r.state.players[r.state.turn].id;
  const action=chooseAction(r.state,id,[1,1],0);if(action)run(r,action);
 }catch(e){console.error(JSON.stringify({level:'error',room:r.code,message:e.message}));r.deadline=Date.now()+rules.decisionSeconds*1000;}
}},500);
const port=Number(process.env.PORT||4178),host=process.env.HOST||'127.0.0.1';server.listen(port,host,()=>console.log(`EKO POLY http://${host}:${server.address().port}`));
function close(){clearInterval(tick);for(const s of sockets)s.close();wss.close();server.close(()=>{db.close();process.exit(0);});setTimeout(()=>process.exit(0),2000).unref();}process.on('SIGINT',close);process.on('SIGTERM',close);
