// Sonido sintetizado en el dispositivo: efectos de juego y una marimba de fondo.
// No usa archivos de audio, así funciona sin conexión en web, Windows, iPhone y Android.
let ctx=null,master=null,sfxBus=null,musicBus=null,noiseBuf=null,musicTimer=null,nextNote=0,step=0;
const state={sfx:true,music:false};

function ac(){
 if(ctx)return ctx;
 const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return null;
 try{ctx=new AC();}catch{return null;}
 master=ctx.createGain();master.gain.value=.9;master.connect(ctx.destination);
 const comp=ctx.createDynamicsCompressor();comp.threshold.value=-14;comp.ratio.value=4;comp.connect(master);
 sfxBus=ctx.createGain();sfxBus.gain.value=.6;sfxBus.connect(comp);
 musicBus=ctx.createGain();musicBus.gain.value=.0;musicBus.connect(comp);
 noiseBuf=ctx.createBuffer(1,ctx.sampleRate,ctx.sampleRate);const d=noiseBuf.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
 return ctx;
}
// Desbloquea el audio dentro de un gesto del usuario (requisito de iOS y Chrome).
let wantMusic=false;
export function unlock(){const c=ac();if(!c)return;if(c.state==='suspended')c.resume().then(()=>{if(state.music&&wantMusic)startMusic();}).catch(()=>{});else if(state.music&&wantMusic)startMusic();}
export function setSfx(on){state.sfx=on;}
export function setMusic(on){state.music=on;if(on&&wantMusic)startMusic();else stopMusic();}

function tone(freq,{type='sine',dur=.18,vol=.25,when=0,attack=.004,slide=null,bus=sfxBus}={}){
 const c=ac();if(!c)return;const t=c.currentTime+when;
 const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(freq,t);if(slide)o.frequency.exponentialRampToValueAtTime(slide,t+dur);
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol,t+attack);g.gain.exponentialRampToValueAtTime(.0008,t+dur);
 o.connect(g);g.connect(bus);o.start(t);o.stop(t+dur+.05);
}
function noise({dur=.08,vol=.2,when=0,type='bandpass',freq=3000,q=4,sweep=null}={}){
 const c=ac();if(!c)return;const t=c.currentTime+when;
 const src=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain();src.buffer=noiseBuf;f.type=type;f.frequency.setValueAtTime(freq,t);if(sweep)f.frequency.exponentialRampToValueAtTime(sweep,t+dur);f.Q.value=q;
 g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0008,t+dur);
 src.connect(f);f.connect(g);g.connect(sfxBus);src.start(t,Math.random()*.5);src.stop(t+dur+.05);
}
const on=fn=>(...a)=>{if(!state.sfx||!ac())return;try{fn(...a);}catch{}};
export const sfx={
 click:on(()=>tone(1400,{type:'triangle',dur:.04,vol:.08})),
 dice:on(()=>{let t=0;for(let i=0;i<11;i++){t+=.035+Math.random()*.05;noise({when:t,dur:.03+Math.random()*.03,vol:.32*(1-i/14),freq:2600+Math.random()*2200,q:7});}
  [.62,.72,.8].forEach((w,i)=>{tone(1900-i*260,{type:'triangle',when:w,dur:.05,vol:.13});noise({when:w,dur:.04,vol:.18,freq:3800,q:5});});}),
 step:on(i=>{const f=620+(i%8)*38;tone(f,{type:'sine',dur:.09,vol:.2});tone(f*2.01,{type:'sine',dur:.05,vol:.05});noise({dur:.025,vol:.06,freq:5200,q:2});}),
 land:on(()=>{tone(180,{type:'sine',dur:.16,vol:.3,slide:110});noise({dur:.05,vol:.08,freq:900,q:1});}),
 coin:on(()=>{tone(1568,{type:'triangle',dur:.22,vol:.16});tone(2093,{type:'triangle',dur:.34,vol:.16,when:.08});tone(3136,{type:'sine',dur:.3,vol:.05,when:.08});}),
 cash:on(()=>{noise({dur:.09,vol:.22,type:'highpass',freq:3500,q:.7});tone(2637,{type:'triangle',dur:.5,vol:.15,when:.06});tone(3520,{type:'sine',dur:.5,vol:.08,when:.06});tone(1319,{type:'triangle',dur:.25,vol:.1,when:.06});}),
 pay:on(()=>{tone(523,{type:'triangle',dur:.14,vol:.18});tone(392,{type:'triangle',dur:.22,vol:.18,when:.12});tone(330,{type:'triangle',dur:.32,vol:.14,when:.26});}),
 card:on(()=>{noise({dur:.26,vol:.18,freq:500,sweep:4200,q:1.4});tone(1500,{type:'triangle',dur:.05,vol:.08,when:.24});}),
 build:on(()=>{[0,.13].forEach(w=>{tone(210,{type:'sine',dur:.12,vol:.38,slide:120,when:w});noise({when:w,dur:.05,vol:.15,freq:1200,q:1.5});});tone(1760,{type:'triangle',dur:.3,vol:.1,when:.3});}),
 freeze:on(()=>{for(let i=0;i<9;i++)tone(2200+Math.random()*2400,{type:'sine',when:i*.05,dur:.35,vol:.06});noise({dur:.7,vol:.12,type:'highpass',freq:7000,sweep:1500,q:.6});tone(330,{type:'triangle',dur:.6,vol:.12,slide:165,when:.1});}),
 gavel:on(()=>{tone(150,{type:'sine',dur:.22,vol:.45,slide:70});noise({dur:.06,vol:.25,freq:1600,q:1});}),
 bid:on(()=>tone(1250,{type:'square',dur:.035,vol:.05})),
 doubles:on(()=>[523,659,784,1047].forEach((f,i)=>tone(f,{type:'triangle',dur:.2,vol:.14,when:i*.07}))),
 turn:on(()=>{tone(784,{type:'sine',dur:.25,vol:.16});tone(1175,{type:'sine',dur:.35,vol:.14,when:.12});}),
 win:on(()=>{[523,659,784,1047,784,1047].forEach((f,i)=>tone(f,{type:'triangle',dur:.3,vol:.17,when:i*.12}));[523,659,784].forEach(f=>tone(f,{type:'triangle',dur:1.2,vol:.1,when:.75}));}),
 lose:on(()=>{tone(392,{type:'sawtooth',dur:.35,vol:.06,slide:370});tone(370,{type:'sawtooth',dur:.35,vol:.06,slide:349,when:.35});tone(349,{type:'sawtooth',dur:.9,vol:.06,slide:262,when:.7});}),
 whoosh:on(()=>noise({dur:.3,vol:.12,freq:900,sweep:3000,q:1}))
};

// Marimba de fondo en 6/8, progresión I–IV–V–I con arpegios suaves.
const NOTE=n=>440*2**((n-69)/12);
const CHORDS=[[67,71,74],[72,76,79],[74,78,81],[67,71,74],[64,67,71],[72,76,79],[74,78,81],[67,71,74]];
const PATTERNS=[[0,1,2,3,2,1],[0,2,1,3,1,2],[0,1,2,1,3,2]];
function marimba(freq,when,vol){
 const c=ctx,t=when;const o1=c.createOscillator(),o2=c.createOscillator(),g=c.createGain(),g2=c.createGain();
 o1.type='sine';o2.type='sine';o1.frequency.value=freq;o2.frequency.value=freq*3.98;
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol,t+.006);g.gain.exponentialRampToValueAtTime(.0005,t+.55);
 g2.gain.setValueAtTime(vol*.25,t);g2.gain.exponentialRampToValueAtTime(.0004,t+.08);
 o1.connect(g);o2.connect(g2);g.connect(musicBus);g2.connect(musicBus);o1.start(t);o2.start(t);o1.stop(t+.6);o2.stop(t+.12);
}
function schedule(){
 const c=ctx;if(!c)return;const eighth=.2;
 while(nextNote<c.currentTime+.25){
  const bar=Math.floor(step/6)%CHORDS.length,beat=step%6,chord=CHORDS[bar],pat=PATTERNS[Math.floor(step/48)%PATTERNS.length];
  const idx=pat[beat],note=idx===3?chord[0]+12:chord[idx];
  marimba(NOTE(note),nextNote,beat===0?.24:.16);
  if(beat===0||beat===3)marimba(NOTE(chord[0]-12),nextNote,.2);
  if(beat===0&&bar%2===1)marimba(NOTE(chord[2]+12),nextNote+eighth*.5,.08);
  nextNote+=eighth;step++;
 }
}
function startMusic(){
 const c=ac();if(!c||musicTimer||c.state!=='running')return;
 nextNote=c.currentTime+.08;musicBus.gain.cancelScheduledValues(c.currentTime);musicBus.gain.setValueAtTime(musicBus.gain.value,c.currentTime);musicBus.gain.linearRampToValueAtTime(.32,c.currentTime+1.5);
 musicTimer=setInterval(schedule,90);schedule();
}
function stopMusic(){
 if(!ctx||!musicTimer)return;clearInterval(musicTimer);musicTimer=null;
 musicBus.gain.cancelScheduledValues(ctx.currentTime);musicBus.gain.setValueAtTime(musicBus.gain.value,ctx.currentTime);musicBus.gain.linearRampToValueAtTime(0,ctx.currentTime+.4);
}
export function pauseMusic(){wantMusic=false;stopMusic();}
export function resumeMusic(){wantMusic=true;if(state.music)startMusic();}
