// Tablero cuadrado de 40 casillas para EKO POLY.
// Estructura clásica del género (4 esquinas, 9 casillas por lado, franjas de color, títulos y mazos)
// con arte propio de EKO K’iin: iconos, fichas, colores y centro del tablero son originales.
import {board,rules,rent} from '../../packages/engine/index.mjs';

// Unidades del tablero: lado 1000, esquina C x C, casilla W x C, franja de color BAND.
export const S=1000,C=131,W=82,BAND=30,RIM=16,VIEW=S+RIM*2;
const INK='#1d2a22',PAPER='#fffef8';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const n1=v=>Math.round(v*10)/10;

// Fichas: seis emblemas propios sobre una base de color de jugador.
export const TOKENS=[
 {id:'sol',es:'Sol',en:'Sun',color:'#f2b705'},
 {id:'piramide',es:'Pirámide',en:'Pyramid',color:'#d83a2e'},
 {id:'tortuga',es:'Tortuga',en:'Turtle',color:'#2e6fd8'},
 {id:'cacao',es:'Cacao',en:'Cacao',color:'#f07c1e'},
 {id:'ceiba',es:'Ceiba',en:'Ceiba',color:'#2e9e4f'},
 {id:'pila',es:'Pila EKO',en:'EKO battery',color:'#8e44ad'}
];
const lum=hex=>{const n=parseInt(hex.slice(1),16),c=[n>>16,n>>8&255,n&255].map(v=>{v/=255;return v<=.03928?v/12.92:((v+.055)/1.055)**2.4;});return .2126*c[0]+.7152*c[1]+.0722*c[2];};
export const inkOn=hex=>lum(hex)>.42?'#22180a':'#ffffff';
export const tokenOf=(s,p)=>TOKENS[(Number.isInteger(p?.token)?p.token:Math.max(0,s?.players?.indexOf(p)??0))%TOKENS.length];

// ---------- Iconos (sprite compartido) ----------
const polar=(cx,cy,r,a)=>[n1(cx+Math.cos(a)*r),n1(cy+Math.sin(a)*r)];
function starPath(cx,cy,long,short,valley){let d='';for(let i=0;i<16;i++){const a=Math.PI*i/8-Math.PI/2,r=i%2?valley:(i%4===0?long:short);const [x,y]=polar(cx,cy,r,a);d+=(i?'L':'M')+x+' '+y;}return d+'Z';}
function sunRays(cx,cy,r1,r2,count,from=0,to=Math.PI*2){let d='';for(let i=0;i<count;i++){const a=from+(to-from)*i/(count-(to-from<6.2?1:0));const [x1,y1]=polar(cx,cy,r1,a),[x2,y2]=polar(cx,cy,r2,a);d+=`M${x1} ${y1}L${x2} ${y2}`;}return d;}
function solEmblem(){let d='M12 6.8a5.2 5.2 0 1 0 0 10.4a5.2 5.2 0 1 0 0-10.4Z';for(let i=0;i<8;i++){const a=Math.PI*i/4-Math.PI/2,[tx,ty]=polar(12,12,11.2,a),[ax,ay]=polar(12,12,7.2,a-.3),[bx,by]=polar(12,12,7.2,a+.3);d+=`M${ax} ${ay}L${tx} ${ty}L${bx} ${by}Z`;}return d;}
function centerRays(){let d='';const cx=500,cy=500,R=720;for(let i=0;i<40;i+=2){const a1=Math.PI*i/20,a2=Math.PI*(i+1)/20,[x1,y1]=polar(cx,cy,R,a1),[x2,y2]=polar(cx,cy,R,a2);d+=`M${cx} ${cy}L${x1} ${y1}L${x2} ${y2}Z`;}return d;}

export const SPRITE=`<svg class="sprite" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg"><defs>
<linearGradient id="g-rim" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f3d37a"/><stop offset=".45" stop-color="#b8892c"/><stop offset=".7" stop-color="#e6c064"/><stop offset="1" stop-color="#8f6619"/></linearGradient>
<linearGradient id="g-logo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff1b8"/><stop offset=".55" stop-color="#f2c548"/><stop offset="1" stop-color="#c98a12"/></linearGradient>
<radialGradient id="g-glow" cx=".5" cy=".42" r=".55"><stop offset="0" stop-color="#2c7a52" stop-opacity=".55"/><stop offset="1" stop-color="#123f2e" stop-opacity="0"/></radialGradient>
<clipPath id="clip-center" clipPathUnits="userSpaceOnUse"><rect x="${C}" y="${C}" width="${S-2*C}" height="${S-2*C}"/></clipPath>
<pattern id="p-hatch" width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="9" height="9" fill="#f4efe6" fill-opacity=".72"/><rect width="2.6" height="9" fill="#9b2f2f" fill-opacity=".22"/></pattern>
<pattern id="p-ice" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(-35)"><rect width="14" height="14" fill="#d9eefb"/><rect width="14" height="2" fill="#bfe1f6"/></pattern>
</defs>
<symbol id="tk-sol" viewBox="0 0 24 24"><path d="${solEmblem()}"/></symbol>
<symbol id="tk-piramide" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M2 21.2h20V18H2zM4 18h16v-3.2H4zM6 14.8h12v-3.2H6zM8 11.6h8V8.4H8zM9.6 8.4h4.8V4.4H9.6zM11 21.2h2V8.4h-2z"/></symbol>
<symbol id="tk-tortuga" viewBox="0 0 24 24"><ellipse cx="6.1" cy="8.7" rx="2.7" ry="1.7" transform="rotate(-35 6.1 8.7)"/><ellipse cx="17.9" cy="8.7" rx="2.7" ry="1.7" transform="rotate(35 17.9 8.7)"/><ellipse cx="6.1" cy="18" rx="2.7" ry="1.7" transform="rotate(35 6.1 18)"/><ellipse cx="17.9" cy="18" rx="2.7" ry="1.7" transform="rotate(-35 17.9 18)"/><circle cx="12" cy="4" r="2.5"/><path d="M11 20.5h2l-1 3z"/><ellipse cx="12" cy="13.3" rx="6.6" ry="7.6"/><path d="M12 10.3l2.6 1.5v3l-2.6 1.5-2.6-1.5v-3z" fill="var(--tok,#333)"/></symbol>
<symbol id="tk-cacao" viewBox="0 0 24 24"><path d="M12 1.6c4.7 2.9 6.8 6.9 6.8 11.4s-2.1 7.9-6.8 9.4c-4.7-1.5-6.8-4.9-6.8-9.4S7.3 4.5 12 1.6z"/><path d="M9.3 5.6c-1.1 4.2-1.1 9.1 0 13.2M14.7 5.6c1.1 4.2 1.1 9.1 0 13.2M12 3.6v17" fill="none" stroke="var(--tok,#333)" stroke-width="1.15"/></symbol>
<symbol id="tk-ceiba" viewBox="0 0 24 24"><path d="M3.8 11.4C1.6 11.4 1 8.2 3.1 7.6c0-2.9 3.4-4.3 5.5-2.5 1.2-2.1 5.1-2.2 6.3.2 2.5-1.2 5.5.4 4.9 3.1 2.5.4 2.5 3.7 0 4.1-1 1.9-3.5 2.1-4.9.8-1.6 1.2-4.5 1-5.5-.4-1.9.8-4.7-.2-5.6-1.5z"/><path d="M10.7 12.2h2.6l.7 8.6H10z"/><path d="M6.8 21.6c1.9-.5 3.2-1.5 3.9-3.2M17.2 21.6c-1.9-.5-3.2-1.5-3.9-3.2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></symbol>
<symbol id="tk-pila" viewBox="0 0 24 24"><path d="M10 2.6h4v2.6h-4z"/><rect x="5.8" y="5.2" width="12.4" height="17" rx="2"/><path d="M13.2 7.8l-4.4 6.6h3.1l-1 5 4.3-6.9h-3.1z" fill="var(--tok,#333)"/></symbol>
<symbol id="ic-coin" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.6" fill="#e9b949" stroke="#7a5512" stroke-width="1.6"/><circle cx="12" cy="12" r="7.8" fill="none" stroke="#c9952a" stroke-width="1"/><path d="M12 5.6c-3.4 2.1-3.4 10.7 0 12.8 3.4-2.1 3.4-10.7 0-12.8z" fill="#6b3a1f"/><path d="M12 7v10" stroke="#e9b949" stroke-width="1.1"/></symbol>
<symbol id="ic-anchor" viewBox="0 0 64 64"><g fill="none" stroke="#24435c" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="32" cy="10.5" r="5.5"/><path d="M32 16v40M20 26h24M9 36c1.6 11.5 11 19 23 20 12-1 21.4-8.5 23-20M9 36l-2.6 7.4M9 36l7.6 2.4M55 36l2.6 7.4M55 36l-7.6 2.4"/></g></symbol>
<symbol id="ic-battery" viewBox="0 0 64 64"><rect x="27" y="4" width="10" height="7" rx="2" fill="${INK}"/><rect x="18" y="10" width="28" height="48" rx="7" fill="#8cc63f" stroke="${INK}" stroke-width="3.4"/><path d="M18 22h28" stroke="#5f9a22" stroke-width="3"/><path d="M35 23L24 39h9l-3 14 12-19h-9l3-11z" fill="#fff" stroke="${INK}" stroke-width="2.4" stroke-linejoin="round"/></symbol>
<symbol id="ic-drop" viewBox="0 0 64 64"><path d="M32 5C24 19 13 29.5 13 41a19 19 0 0 0 38 0C51 29.5 40 19 32 5z" fill="#2f86d6" stroke="${INK}" stroke-width="3.4" stroke-linejoin="round"/><path d="M22.5 42c1.6 6.6 6 9.8 11.5 10" fill="none" stroke="#fff" stroke-width="3.6" stroke-linecap="round"/></symbol>
<symbol id="ic-oracle" viewBox="0 0 64 64"><path d="${starPath(32,32,31,22,10.5)}" fill="#f2a900" stroke="${INK}" stroke-width="2.4" stroke-linejoin="round"/><circle cx="32" cy="32" r="10" fill="#fff8e1" stroke="${INK}" stroke-width="2.4"/><path d="M24.5 32c2.4-3.6 4.9-5.2 7.5-5.2s5.1 1.6 7.5 5.2c-2.4 3.6-4.9 5.2-7.5 5.2s-5.1-1.6-7.5-5.2z" fill="#fff" stroke="${INK}" stroke-width="1.8"/><circle cx="32" cy="32" r="2.7" fill="${INK}"/></symbol>
<symbol id="ic-tequio" viewBox="0 0 64 64"><g stroke="${INK}" stroke-width="2.6" stroke-linejoin="round"><circle cx="14" cy="22" r="6" fill="#8fd9c9"/><path d="M3 49c0-8.4 4.9-13.4 11-13.4S25 40.6 25 49z" fill="#8fd9c9"/><circle cx="50" cy="22" r="6" fill="#8fd9c9"/><path d="M39 49c0-8.4 4.9-13.4 11-13.4S61 40.6 61 49z" fill="#8fd9c9"/><circle cx="32" cy="17.5" r="7.6" fill="#16a085"/><path d="M17.5 55c0-10.6 6.3-17.6 14.5-17.6S46.5 44.4 46.5 55z" fill="#16a085"/><path d="M22 45.5c3.4 2.4 6.7 3.5 10 3.5s6.6-1.1 10-3.5" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/></g></symbol>
<symbol id="ic-network" viewBox="0 0 64 64"><g stroke="${INK}" stroke-width="3.2"><path d="M32 14L13 47M32 14l19 33M13 47h38" fill="none"/><circle cx="32" cy="14" r="8.5" fill="#f2b705"/><circle cx="13" cy="47" r="8.5" fill="#19a7b4"/><circle cx="51" cy="47" r="8.5" fill="#e4462c"/></g></symbol>
<symbol id="ic-leaf" viewBox="0 0 64 64"><path d="M11 53C9 28 25 10 55 9c2 27-15 45-44 44z" fill="#5aa832" stroke="${INK}" stroke-width="3.2" stroke-linejoin="round"/><path d="M13 51C23 39 33 29 46 19M27 37l-1-10M35 29l9 1" fill="none" stroke="${INK}" stroke-width="2.6" stroke-linecap="round"/></symbol>
<symbol id="ic-sunrise" viewBox="0 0 64 64"><path d="${sunRays(32,41,22,30,7,Math.PI*1.08,Math.PI*1.92)}" stroke="${INK}" stroke-width="3" stroke-linecap="round"/><path d="M12.5 41a19.5 19.5 0 0 1 39 0z" fill="#f2a900" stroke="${INK}" stroke-width="2.6" stroke-linejoin="round"/><path d="M4 41h56M15 49h34M23 56h18" stroke="${INK}" stroke-width="3" stroke-linecap="round"/></symbol>
<symbol id="ic-ceiba" viewBox="0 0 64 64"><path d="M28.5 33h7l2 23h-11z" fill="#8b5a2b" stroke="${INK}" stroke-width="2.6" stroke-linejoin="round"/><path d="M16 58c5-1.4 8.6-4 10.6-8.6M48 58c-5-1.4-8.6-4-10.6-8.6M7 59h50" fill="none" stroke="${INK}" stroke-width="2.6" stroke-linecap="round"/><path d="M10 31C4 31 2.6 22.4 8.2 20.8c0-7.8 9-11.6 14.8-6.8 3.2-5.6 13.6-6 16.8.6 6.6-3.2 14.6 1 13 8.2 6.6 1 6.6 9.8 0 11-2.6 5-9.4 5.6-13 2.2-4.4 3.2-12 2.6-14.8-1.2-5.2 2.2-12.6-.6-15-4.8z" fill="#2e9e4f" stroke="${INK}" stroke-width="2.6" stroke-linejoin="round"/></symbol>
<symbol id="ic-snow" viewBox="0 0 64 64"><g fill="none" stroke="#1b6fa8" stroke-width="4.2" stroke-linecap="round">${[0,60,120].map(a=>`<g transform="rotate(${a} 32 32)"><path d="M32 5v54M32 14l-7.5-7.5M32 14l7.5-7.5M32 50l-7.5 7.5M32 50l7.5 7.5"/></g>`).join('')}</g><circle cx="32" cy="32" r="5" fill="#fff" stroke="#1b6fa8" stroke-width="3"/></symbol>
<symbol id="ic-wallet" viewBox="0 0 64 64"><path d="M10 20l30-10 4 10" fill="#c98a12" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/><rect x="7" y="20" width="50" height="34" rx="6" fill="#8b5a2b" stroke="${INK}" stroke-width="3.2"/><rect x="38" y="30" width="19" height="14" rx="4" fill="#e9b949" stroke="${INK}" stroke-width="3"/><circle cx="45" cy="37" r="2.6" fill="${INK}"/></symbol>
</svg>`;

// ---------- Geometría ----------
// Esquinas: 0 abajo-derecha, 10 abajo-izquierda, 20 arriba-izquierda, 30 arriba-derecha. Recorrido en sentido horario.
export function geom(id){
 const k=Math.floor(id/10),j=id%10;
 if(j===0){const [x,y]=[[S-C,S-C],[0,S-C],[0,0],[S-C,0]][k];return {corner:true,rot:k*90,w:C,h:C,cx:x+C/2,cy:y+C/2};}
 const along=(j-.5)*W;
 const [cx,cy]=[[S-C-along,S-C/2],[C/2,S-C-along],[C+along,C/2],[S-C/2,C+along]][k];
 return {corner:false,rot:k*90,w:W,h:C,cx,cy};
}
export function toBoard(id,lx,ly){const g=geom(id),dx=lx-g.w/2,dy=ly-g.h/2,r=g.rot*Math.PI/180,c=Math.round(Math.cos(r)),s=Math.round(Math.sin(r));return [n1(g.cx+dx*c-dy*s),n1(g.cy+dx*s+dy*c)];}
const frame=g=>`translate(${n1(g.cx)} ${n1(g.cy)}) rotate(${g.rot}) translate(${-g.w/2} ${-g.h/2})`;
export const pct=v=>`${((v+RIM)/VIEW*100).toFixed(3)}%`;

// Reparte un nombre en 1 a 3 renglones equilibrados, en mayúsculas como un tablero impreso.
export function wrap(name,max=11,maxLines=3){
 const words=String(name).toUpperCase().split(/\s+/).filter(Boolean),n=words.length;let best=null;
 const consider=lines=>{const longest=Math.max(...lines.map(l=>l.length)),over=Math.max(0,longest-max),score=over*100+lines.length*4+longest;if(!best||score<best.score)best={lines,score};};
 consider([words.join(' ')]);
 for(let i=1;i<n;i++){consider([words.slice(0,i).join(' '),words.slice(i).join(' ')]);if(maxLines>2)for(let k=i+1;k<n;k++)consider([words.slice(0,i).join(' '),words.slice(i,k).join(' '),words.slice(k).join(' ')]);}
 return best.lines;
}
// Texto con ancho máximo: un ajuste posterior en el navegador lo comprime si no cabe.
function label(x,y,str,{size=14,weight=700,max=W-8,fill=INK,anchor='middle',ls=0,cls=''}={}){
 return `<text x="${n1(x)}" y="${n1(y)}" font-size="${size}" font-weight="${weight}" fill="${fill}" text-anchor="${anchor}"${ls?` letter-spacing="${ls}"`:''} data-fit="${max}"${cls?` class="${cls}"`:''}>${esc(str)}</text>`;
}
const coinPrice=(x,y,value,size=15)=>{const s=String(value),w=size*.86+3+s.length*size*.5,left=x-w/2;return `<use href="#ic-coin" x="${n1(left)}" y="${n1(y-size*.8)}" width="${n1(size*.86)}" height="${n1(size*.86)}"/>`+label(left+size*.86+3,y,s,{size,weight:600,anchor:'start',max:60});};

// ---------- Edificios (se dibujan de pie, como piezas, sobre la franja de color) ----------
export function buildingSpots(id,level){
 if(!level)return [];
 if(level===5)return [{hotel:true,at:toBoard(id,W/2,BAND*.62)}];
 const gap=18,start=W/2-(level-1)*gap/2;
 return Array.from({length:level},(_,i)=>({hotel:false,at:toBoard(id,start+i*gap,BAND*.62)}));
}
export const HOUSE_ART='<svg viewBox="0 0 32 30" aria-hidden="true"><g stroke="#0f2d1a" stroke-width="1.3" stroke-linejoin="round"><path d="M21 29V15l7.5-4.5V25z" fill="#1d7a36"/><path d="M3 29V15l9-8.4L21 15v14z" fill="#2fa84f"/><path d="M12 6.6L21 15l7.5-4.5-9.2-8z" fill="#53cf74"/><path d="M9.6 29v-7.4h4.8V29" fill="#0f2d1a" fill-opacity=".55"/></g></svg>';
export const HOTEL_ART=`<svg viewBox="0 0 46 34" aria-hidden="true"><g stroke="#3b0a10" stroke-width="1.4" stroke-linejoin="round"><path d="M32 33V11l11-5.6v21.4z" fill="#9e1527"/><path d="M3 33V11h29v22z" fill="#d7263d"/><path d="M3 11h29l11-5.6H14z" fill="#f04b5e"/></g><g fill="#ffe7a8">${[7,14.5,22].map(x=>`<rect x="${x}" y="15" width="4" height="4"/><rect x="${x}" y="22" width="4" height="4"/>`).join('')}</g><path d="M15 33v-5h5v5" fill="#3b0a10" fill-opacity=".7"/></svg>`;

// ---------- Casillas ----------
function foot(t,a,ctx){
 const owner=a?.owner&&ctx.state?.players.find(p=>p.id===a.owner);
 if(!owner)return t.price?coinPrice(W/2,C-11,t.price):'';
 const tok=tokenOf(ctx.state,owner),ink=inkOn(tok.color);
 let value;
 if(a.mortgaged)value='—';
 else if(t.type==='service'){const count=board.filter(x=>x.type==='service'&&ctx.state.assets[x.id]?.owner===owner.id).length;value='×'+rules.serviceMultipliers[count-1];}
 else value=String(rent(ctx.state,t.id));
 return `<g class="owner-plate"><rect x="5" y="${C-28}" width="${W-10}" height="22" rx="6" fill="${tok.color}" stroke="${INK}" stroke-width="1.2"/><use href="#tk-${tok.id}" x="9" y="${C-25}" width="16" height="16" fill="${ink}" style="--tok:${tok.color};color:${ink}"/>${label(W-10,C-12,value,{size:14.5,weight:700,fill:ink,anchor:'end',max:46})}</g>`;
}
function nameBlock(t,top,{size=14.5,line=15.5,max=11}={}){
 const lines=t.type==='port'?['PUERTO',...wrap(t.name.replace(/^Puerto de\s+/i,''),max,2)]:wrap(t.name,max,3);
 return {svg:lines.map((l,i)=>label(W/2,top+i*line,l,{size,weight:700})).join(''),bottom:top+(lines.length-1)*line+4};
}
function sideTile(t,ctx){
 const a=ctx.state?.assets?.[t.id],g=geom(t.id);let body='';
 if(t.type==='property'){
  const nb=nameBlock(t,BAND+19);
  body=`<rect width="${W}" height="${BAND}" fill="${t.color}"/><path d="M0 ${BAND}H${W}" stroke="${INK}" stroke-width="1.6"/>${nb.svg}${foot(t,a,ctx)}`;
 }else{
  const icon={port:'ic-anchor',service:t.id===12?'ic-battery':'ic-drop',oracle:'ic-oracle',community:'ic-tequio',tax:'ic-network',tax2:'ic-leaf'}[t.type];
  const nb=nameBlock(t,22);
  const footText=t.type==='tax'?`${rules.tax.fixed} / ${Math.round(rules.tax.percent*100)}%`:t.type==='tax2'?String(rules.tax.secondary):'';
  const bottom=t.price||footText?C-30:C-8,size=Math.min(62,bottom-nb.bottom-6),iy=nb.bottom+(bottom-nb.bottom-size)/2+2;
  body=`${nb.svg}<use href="#${icon}" x="${n1((W-size)/2)}" y="${n1(iy)}" width="${n1(size)}" height="${n1(size)}"/>${t.price?foot(t,a,ctx):footText?label(W/2,C-11,(ctx.txt?ctx.txt('PAGA ','PAY '):'PAGA ')+footText,{size:13,weight:700}):''}`;
 }
 if(a?.mortgaged)body+=`<rect width="${W}" height="${C}" fill="url(#p-hatch)"/><g transform="translate(${W/2} ${C/2-6}) rotate(-62)"><rect x="-50" y="-11" width="100" height="21" rx="3" fill="#fffef8" fill-opacity=".85" stroke="#b3261e" stroke-width="2.2"/>${label(0,5,ctx.txt?ctx.txt('HIPOTECADA','MORTGAGED'):'HIPOTECADA',{size:12.5,weight:800,fill:'#b3261e',max:92,ls:.6})}</g>`;
 const here=ctx.highlight===t.id?`<rect x="2.5" y="2.5" width="${W-5}" height="${C-5}" fill="none" stroke="#f2b705" stroke-width="5" class="here"/>`:'';
 return `<g class="tile" data-property="${t.id}" tabindex="${ctx.demo?-1:0}" role="button" aria-label="${esc(ariaFor(t,a,ctx))}" transform="${frame(g)}"><rect class="tile-bg" width="${W}" height="${C}" fill="${PAPER}" stroke="${INK}" stroke-width="1.6"/>${body}${here}</g>`;
}
function ariaFor(t,a,ctx){
 const owner=a?.owner&&ctx.state?.players.find(p=>p.id===a.owner);
 const tr=ctx.txt||((es)=>es);
 return [t.name,t.price?`${t.price} Cacao`:'',owner?tr('de ','owned by ')+owner.name:'',a?.mortgaged?tr('hipotecada','mortgaged'):'',a?.level===5?'hotel':a?.level?`${a.level} ${tr('casas','houses')}`:''].filter(Boolean).join(', ');
}
// Esquinas en marco canónico: interior arriba-izquierda, exterior abajo-derecha.
function cornerTile(t,ctx){
 const g=geom(t.id),tr=ctx.txt||((es)=>es),mid=C/2;
 const diag=(inner)=>`<g transform="translate(${mid} ${mid}) rotate(-45)">${inner}</g>`;
 let art='';
 if(t.type==='start')art=diag(`<use href="#ic-sunrise" x="-24" y="-60" width="48" height="48"/>${label(0,4,'AMANECER',{size:25,weight:800,max:150,ls:.5})}${label(0,29,'K’IIN',{size:25,weight:800,max:120,fill:'#b97800',ls:1})}${label(0,47,tr(`COBRA ${rules.salary} AL PASAR`,`COLLECT ${rules.salary} AS YOU PASS`),{size:10.5,weight:700,max:92})}`);
 if(t.type==='jail'){
  const k=86;
  art=`<rect width="${k}" height="${k}" fill="url(#p-ice)" stroke="${INK}" stroke-width="2.2"/><g transform="translate(${k/2} ${k/2}) rotate(-45)"><use href="#ic-snow" x="-17" y="-17" width="34" height="34" opacity=".9"/>${label(0,-24,'WALLET',{size:12,weight:800,max:64,fill:'#124e78'})}${label(0,32,'CONGELADA',{size:11.5,weight:800,max:72,fill:'#124e78'})}</g>`+
   `<g transform="translate(${k+(C-k)/2} ${C/2}) rotate(-90)">${label(0,5,tr('SOLO DE VISITA','JUST VISITING'),{size:13.5,weight:700,max:C-14,ls:.6})}</g>`;
 }
 if(t.type==='rest')art=diag(`${label(0,-34,'LA CEIBA',{size:22,weight:800,max:150,ls:.5})}<use href="#ic-ceiba" x="-28" y="-26" width="56" height="56"/>${label(0,48,tr('DESCANSO','REST STOP'),{size:12,weight:700,max:90,ls:1})}`);
 if(t.type==='gojail')art=diag(`${label(0,-38,'¡CONGELA',{size:19,weight:800,max:130})}${label(0,-18,'TU WALLET!',{size:19,weight:800,max:130})}<circle cx="0" cy="18" r="23" fill="#e3f3fd" stroke="#1b6fa8" stroke-width="2.4"/><use href="#ic-snow" x="-17" y="1" width="34" height="34"/>${label(0,58,tr('VE DIRECTO, SIN COBRAR','GO DIRECTLY, NO SALARY'),{size:9.5,weight:700,max:80})}`);
 const here=ctx.highlight===t.id?`<rect x="3" y="3" width="${C-6}" height="${C-6}" fill="none" stroke="#f2b705" stroke-width="6" class="here"/>`:'';
 return `<g class="tile corner" data-property="${t.id}" tabindex="${ctx.demo?-1:0}" role="button" aria-label="${esc(t.name)}" transform="${frame(g)}"><rect class="tile-bg" width="${C}" height="${C}" fill="${PAPER}" stroke="${INK}" stroke-width="1.6"/>${art}${here}</g>`;
}

// ---------- Centro del tablero ----------
function deckCard(x,y,rot,kind,title){
 const fill=kind==='oracle'?'#f2a900':'#16a085',edge=kind==='oracle'?'#8a5d00':'#0b5a4b',w=158,h=104;
 const layers=[6,3,0].map(o=>`<rect x="${-w/2+o}" y="${-h/2+o}" width="${w}" height="${h}" rx="9" fill="${o?edge:fill}" stroke="${INK}" stroke-width="2"/>`).join('');
 return `<g class="deck deck-${kind}" transform="translate(${x} ${y}) rotate(${rot})">${layers}<rect x="${-w/2+7}" y="${-h/2+7}" width="${w-14}" height="${h-14}" rx="6" fill="none" stroke="#fffef8" stroke-opacity=".8" stroke-width="2" stroke-dasharray="1 5" stroke-linecap="round"/><use href="#ic-${kind}" x="-24" y="-44" width="48" height="48"/>${label(0,30,title,{size:17,weight:800,max:w-24,fill:kind==='oracle'?INK:'#fffef8',ls:1})}</g>`;
}
function center(ctx){
 const tr=ctx.txt||((es)=>es),cs=S-2*C;
 const status=ctx.status?label(500,792,ctx.status,{size:22,weight:600,max:560,fill:'#d7e6c4',ls:.4}):'';
 return `<g class="board-center"><rect x="${C}" y="${C}" width="${cs}" height="${cs}" fill="#123f2e"/><g clip-path="url(#clip-center)"><path d="${centerRays()}" fill="#174b37" fill-opacity=".55"/><circle cx="500" cy="470" r="330" fill="url(#g-glow)"/></g><rect x="${C+12}" y="${C+12}" width="${cs-24}" height="${cs-24}" fill="none" stroke="#c9a34a" stroke-opacity=".55" stroke-width="1.6"/>`+
  `<ellipse cx="500" cy="352" rx="70" ry="16" fill="#0a2619" fill-opacity=".55"/>`+
  `<g font-size="124" font-weight="800" text-anchor="middle" letter-spacing="2">${[7,6,5,4,3,2,1].map(o=>`<text x="${500+o*.6}" y="${468+o}" fill="#0a2619">EKO POLY</text>`).join('')}<text x="500" y="468" fill="url(#g-logo)" stroke="#6b4a0e" stroke-width="1.4" data-fit="600">EKO POLY</text></g>`+
  label(500,510,tr('EL SOL ES DE TODOS','THE SUN BELONGS TO EVERYONE'),{size:21,weight:600,max:520,fill:'#cfe0b5',ls:7})+
  deckCard(318,652,-8,'oracle','ORÁCULO K’IIN')+deckCard(682,652,8,'tequio','TEQUIO')+status+`</g>`;
}

// ---------- Fichas ----------
const SLOTS={1:[[0,0]],2:[[-19,0],[19,0]],3:[[-19,-15],[19,-15],[0,17]],4:[[-19,-17],[19,-17],[-19,17],[19,17]],5:[[-19,-30],[19,-30],[0,0],[-19,30],[19,30]],6:[[-19,-30],[19,-30],[-19,0],[19,0],[-19,30],[19,30]]};
export function tokenSpot(id,index,count,jailed=false){
 const g=geom(id);
 if(id===10){
  if(jailed){const p=SLOTS[Math.min(count,4)][index%4]||[0,0];return toBoard(10,43+p[0]*.75,43+p[1]*.75);}
  const strip=[[22,108],[64,108],[108,108],[108,64],[108,22],[42,108]][index%6];return toBoard(10,strip[0],strip[1]);
 }
 const p=(SLOTS[Math.min(count,6)]||SLOTS[1])[index%6]||[0,0];
 return g.corner?toBoard(id,C/2+p[0]*1.25,C/2+p[1]*.95):toBoard(id,W/2+p[0],74+p[1]*.8);
}
// ---------- Tablero completo ----------
export function boardSvg(s,ctx={}){
 const tiles=board.map(t=>t.id%10===0?cornerTile(t,{...ctx,state:s}):sideTile(t,{...ctx,state:s})).join('');
 return `<svg class="board-svg" viewBox="${-RIM} ${-RIM} ${VIEW} ${VIEW}" role="group" aria-label="${esc(ctx.label||'Tablero')}" font-family="'Barlow Condensed','Arial Narrow',Arial,sans-serif"><rect x="${-RIM}" y="${-RIM}" width="${VIEW}" height="${VIEW}" rx="12" fill="url(#g-rim)"/><rect x="-5" y="-5" width="${S+10}" height="${S+10}" fill="${INK}"/><rect width="${S}" height="${S}" fill="${PAPER}"/>${center(ctx)}${tiles}</svg>`;
}

// Estado de muestra para la portada: algunas propiedades con dueño y edificios.
export function demoState(){
 const players=[{id:'a',name:'Ixchel',token:0,position:0},{id:'b',name:'Balam',token:2,position:16},{id:'c',name:'Itzel',token:4,position:24}].map(p=>({...p,cash:1500,jail:0,bankrupt:false,cards:[]}));
 const assets={};board.filter(t=>t.price).forEach(t=>assets[t.id]={owner:null,level:0,mortgaged:false});
 [[11,'b',2],[13,'b',2],[14,'b',3],[37,'c',5],[39,'c',4],[5,'a',0],[21,'a',0],[28,'b',0]].forEach(([id,owner,level])=>assets[id]={owner,level,mortgaged:false});
 assets[26]={owner:'c',level:0,mortgaged:true};
 return {players,assets,dice:[5,6],round:1,turn:0,phase:'roll',mode:'classic'};
}

// ---------- Título de propiedad ----------
export function deedHtml(t,s,{txt=(es)=>es,fmt=String,mode='classic',compact=false}={}){
 const a=s?.assets?.[t.id],cc=v=>`<span class="cc"><svg aria-hidden="true"><use href="#ic-coin"/></svg>${fmt(v)}</span>`;
 const band=t.color||'#24435c',ink=inkOn(band);
 let rows='',foot='';
 if(t.type==='property'){
  const max=mode==='classic'?rules.maxHouses:rules.shortHouses;
  rows=[[txt('Renta','Rent'),t.rents[0]],[txt('Con el grupo completo','With the full group'),t.rents[0]*2],...Array.from({length:max},(_,i)=>[i===0?txt('Con 1 casa','With 1 house'):txt(`Con ${i+1} casas`,`With ${i+1} houses`),t.rents[i+1]]),[txt('Con hotel','With hotel'),t.rents[5]]]
   .map(([k,v],i)=>`<div class="${a&&a.owner&&((i===0&&a.level===0)||(i>1&&(i-1===a.level||(a.level===5&&i===max+2))))?'is-now':''}"><dt>${k}</dt><dd>${cc(v)}</dd></div>`).join('');
  foot=`<p>${txt('Valor hipotecario','Mortgage value')} ${cc(t.mortgage)}</p><p>${txt('Casas','Houses')} ${cc(t.build)} ${txt('c/u','each')} · Hotel ${cc(t.build)} + ${max} ${txt('casas','houses')}</p>`;
 }else if(t.type==='port'){
  rows=rules.portRent.map((v,i)=>`<div><dt>${i===0?txt('Renta','Rent'):txt(`Si tienes ${i+1} puertos`,`If ${i+1} ports are owned`)}</dt><dd>${cc(v)}</dd></div>`).join('');
  foot=`<p>${txt('Valor hipotecario','Mortgage value')} ${cc(t.mortgage)}</p>`;
 }else if(t.type==='service'){
  rows=`<div class="wide"><dt>${txt(`Con un servicio, la renta es ${rules.serviceMultipliers[0]} veces lo que marquen los dados.`,`With one service, rent is ${rules.serviceMultipliers[0]} times the dice.`)}</dt></div><div class="wide"><dt>${txt(`Con ambos, ${rules.serviceMultipliers[1]} veces.`,`With both, ${rules.serviceMultipliers[1]} times.`)}</dt></div>`;
  foot=`<p>${txt('Valor hipotecario','Mortgage value')} ${cc(t.mortgage)}</p>`;
 }
 const icon=t.type==='port'?'ic-anchor':t.type==='service'?(t.id===12?'ic-battery':'ic-drop'):'';
 const owner=a?.owner&&s.players.find(p=>p.id===a.owner);
 return `<article class="deed${compact?' is-compact':''}${a?.mortgaged?' is-mortgaged':''}" style="--band:${band};--band-ink:${ink}"><header class="deed-head">${icon?`<svg class="deed-icon" aria-hidden="true"><use href="#${icon}"/></svg>`:''}<small>${t.type==='property'?txt('Título de propiedad','Title deed')+(t.group?` · ${esc(t.group)}`:''):t.type==='port'?txt('Puerto','Port'):txt('Servicio','Service')}</small><h3>${esc(t.name)}</h3></header><dl class="deed-rents">${rows}</dl><footer class="deed-foot">${foot}${owner?`<p class="deed-owner"><span style="--c:${tokenOf(s,owner).color}"></span>${txt('Dueño','Owner')}: <b>${esc(owner.name)}</b>${a.mortgaged?` · ${txt('hipotecada','mortgaged')}`:''}</p>`:t.price?`<p class="deed-owner">${txt('Precio','Price')} ${cc(t.price)}</p>`:''}</footer>${a?.mortgaged?`<span class="deed-stamp">${txt('Hipotecada','Mortgaged')}</span>`:''}</article>`;
}
