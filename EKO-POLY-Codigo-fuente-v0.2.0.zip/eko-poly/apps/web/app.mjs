import ekoPresentation from './assets/eko-presentacion.jpg';
import ekoToken from './assets/eko-token.jpg';
import bsLogo from './assets/business-shop-emblema.jpg';
import ekoLogo from './assets/eko-kiin.png';
import presenter from './assets/presentadora.png';
import mascot from './assets/mascota.png';
import seedBattery from './assets/pila-semilla.png';
import recycling from './assets/reciclaje.png';
import planters from './assets/macetas.png';
import {board,rules,cards,createGame,apply,legalActions,worth,rent} from '../../packages/engine/index.mjs';
import {chooseAction} from '../../packages/engine/ai.mjs';
import {SPRITE,TOKENS,tokenOf,inkOn,boardSvg,tokenSpot,buildingSpots,HOUSE_ART,HOTEL_ART,pct,RIM,VIEW,deedHtml,demoState} from './board.mjs';
import {sfx,unlock,setSfx,setMusic,pauseMusic,resumeMusic} from './audio.mjs';
import * as voice from './voice.mjs';

const $=s=>document.querySelector(s),escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Almacenamiento local tolerante: en modo privado o vistas previas puede fallar sin romper el juego.
const store={get(k,d=null){try{const v=localStorage.getItem(k);return v===null?d:v;}catch{return d;}},set(k,v){try{localStorage.setItem(k,v);return true;}catch{return false;}},del(k){try{localStorage.removeItem(k);}catch{}},keys(){try{return Object.keys(localStorage);}catch{return [];}}};
const reduced=()=>{try{return matchMedia('(prefers-reduced-motion: reduce)').matches;}catch{return false;}};
const LEVELS=[['Semilla','Seed'],['Raíz','Root'],['Ceiba','Ceiba'],['Sol','Sun']];
const BOTS=['Ixchel','Balam','Itzel','Yax','Kin'];

let camT='',state=null,view=null,screen='home',human='you',socket=null,room=null,online=false,aiTimer,localTimer,deadline=0,fxRun=null,revealDone=null,bubble=null,freshBuild=new Set(),diceShown=null;
let language=store.get('eko-poly-language')||'es';
const settings={muted:store.get('eko-poly-sound')==='off',fx:store.get('eko-poly-fx')!=='off',music:store.get('eko-poly-music')!=='off',voice:store.get('eko-poly-voice')!=='off',view3d:store.get('eko-poly-3d')!=='off',camera:store.get('eko-poly-camera')!=='off'};
const en=()=>language==='en',txt=(es,english)=>en()?english:es;
const fmt=n=>new Intl.NumberFormat(en()?'en-US':'es-MX').format(n);
const cc=n=>`<span class="cc"><svg aria-hidden="true"><use href="#ic-coin"/></svg>${fmt(n)}</span>`;
const labels={roll:['Lanzar dados','Roll dice'],buy:['Comprar propiedad','Buy property'],decline:['Subastar','Auction it'],end:['Terminar turno','End turn'],pay_jail:['Descongelar · 50','Unfreeze · 50'],release:['Usar salida libre','Use release card'],pay_debt:['Pagar deuda','Pay debt'],bankrupt:['Declarar quiebra','Declare bankruptcy'],mortgage:['Hipotecar','Mortgage'],unmortgage:['Levantar hipoteca','Lift mortgage'],build:['Construir','Build'],sell:['Vender edificio','Sell building'],sell_hotel:['Vender hotel completo','Sell entire hotel']};
const label=t=>(labels[t]||[t,t])[en()?1:0];
function applyAudio(){setSfx(!settings.muted&&settings.fx);setMusic(!settings.muted&&settings.music);voice.setVoiceEnabled(!settings.muted&&settings.voice);voice.setVoiceLang(language);}
applyAudio();

function random(n){const b=new Uint32Array(1),max=Math.floor(4294967296/n)*n;do{crypto.getRandomValues(b);}while(b[0]>=max);return b[0]%n;}
function shuffled(arr){const out=structuredClone(arr);for(let i=out.length-1;i>0;i--){const j=random(i+1);[out[i],out[j]]=[out[j],out[i]];}return out;}
const dice=()=>[random(6)+1,random(6)+1];
function toast(text){const t=$('#toast');t.textContent=text;t.style.display='block';clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.style.display='none',3800);}
// Vibración breve en teléfonos compatibles (Android); en iPhone no hace nada.
const buzz=p=>{if(settings.muted||!settings.fx)return;try{navigator.vibrate?.(p);}catch{}};
const shade=(hex,amt)=>{const n=parseInt(hex.slice(1),16),f=v=>Math.max(0,Math.min(255,Math.round(amt<0?v*(1+amt):v+(255-v)*amt)));return '#'+[n>>16,n>>8&255,n&255].map(v=>f(v).toString(16).padStart(2,'0')).join('');};

// ---------- Fichas ----------
function medal(tok,pedestal=false){
 const ink=inkOn(tok.color),em=`<use href="#tk-${tok.id}" x="11.5" y="${pedestal?10.5:11.5}" width="25" height="25" fill="${ink}" style="--tok:${tok.color};color:${ink}"/>`;
 if(!pedestal)return `<svg class="medal" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="21" fill="${tok.color}" stroke="#fff" stroke-width="3.4"/><circle cx="24" cy="24" r="16" fill="none" stroke="${ink}" stroke-opacity=".25" stroke-width="1.4"/>${em}<path d="M10 17a16 16 0 0 1 14-9" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="2.6" stroke-linecap="round"/></svg>`;
 const dark=shade(tok.color,-.4);
 return `<svg class="medal" viewBox="0 0 48 62" aria-hidden="true"><ellipse cx="24" cy="56" rx="17" ry="5.2" fill="${dark}"/><rect x="7" y="50" width="34" height="6" fill="${dark}"/><ellipse cx="24" cy="50" rx="17" ry="5.2" fill="${tok.color}" stroke="#fff" stroke-opacity=".6"/><rect x="21" y="40" width="6" height="11" fill="#dfe5df" stroke="#7d8a80"/><circle cx="24" cy="23" r="20" fill="${tok.color}" stroke="#fff" stroke-width="3.2"/><circle cx="24" cy="23" r="15.2" fill="none" stroke="${ink}" stroke-opacity=".25" stroke-width="1.3"/>${em}<path d="M10.5 16a15 15 0 0 1 13.5-8.5" fill="none" stroke="#fff" stroke-opacity=".6" stroke-width="2.4" stroke-linecap="round"/></svg>`;
}

// ---------- Dados 3D ----------
const PIPS={1:[[50,50]],2:[[27,27],[73,73]],3:[[27,27],[50,50],[73,73]],4:[[27,27],[73,27],[27,73],[73,73]],5:[[27,27],[73,27],[50,50],[27,73],[73,73]],6:[[27,24],[73,24],[27,50],[73,50],[27,76],[73,76]]};
const BASE={1:[0,0],2:[0,-90],3:[-90,0],4:[90,0],5:[0,90],6:[0,180]};
const diceRot=[{x:0,y:0,z:6},{x:0,y:0,z:-8}];
function settle(i,v,spin){const [bx,by]=BASE[v],r=diceRot[i],turns=spin?2+random(2):0;const up=(cur,b)=>b+360*Math.ceil((cur+(spin?360*turns:0)-b)/360);r.x=spin?up(r.x,bx):bx+360*Math.round((r.x-bx)/360);r.y=spin?up(r.y,by):by+360*Math.round((r.y-by)/360);r.z=spin?random(50)-25:r.z;}
const dieTransform=i=>`rotateZ(${diceRot[i].z}deg) rotateX(${diceRot[i].x}deg) rotateY(${diceRot[i].y}deg)`;
function syncDice(d){if(fxRun||(diceShown&&diceShown[0]===d[0]&&diceShown[1]===d[1]))return;d.forEach((v,i)=>settle(i,v,false));diceShown=[...d];}
const face=n=>`<div class="face f${n}">${PIPS[n].map(([x,y])=>`<i style="left:${x}%;top:${y}%"></i>`).join('')}</div>`;
function diceHtml(d,clickable){syncDice(d);return `<div class="dice3d${clickable?' can-roll':''}"${clickable?` data-ui="roll-dice" role="button" tabindex="0" aria-label="${txt('Lanzar dados','Roll dice')}"`:` aria-label="${txt('Dados','Dice')}: ${d.join(' + ')}"`}>${d.map((_,i)=>`<div class="die-slot"><div class="die-shadow"></div><div class="die-toss"><div class="die3d" data-die="${i}" style="transform:${dieTransform(i)}">${[1,2,3,4,5,6].map(face).join('')}</div></div></div>`).join('')}</div>`;}

// ---------- Tablero 3D ----------
function standees(v,{demo=false,id='main'}={}){
 const talking=id==='main'&&bubble;
 let html=`<div class="sd sd-mascot${talking?' is-talking':''}" style="left:${pct(500)};top:${pct(350)}"><div class="sd-body"><div class="bubble"${talking?'':' hidden'}>${talking?escape(bubble):''}</div><div class="mascot-wrap"><img src="${mascot}" alt="EKO K’iin" draggable="false"></div></div></div>`;
 if(v?.assets)for(const t of board){const a=v.assets[t.id];if(!a?.level)continue;buildingSpots(t.id,a.level).forEach((b,i)=>{const fresh=id==='main'&&freshBuild.has(t.id)&&(b.hotel||i===a.level-1);html+=`<div class="sd sd-bldg ${b.hotel?'is-hotel':'is-house'}${fresh?' is-new':''}" style="left:${pct(b.at[0])};top:${pct(b.at[1])}"><div class="sd-body">${b.hotel?HOTEL_ART:HOUSE_ART}</div></div>`;});}
 if(v?.players){
  const groups=new Map();v.players.filter(p=>!p.bankrupt).forEach(p=>{const key=p.position===10?(p.jail?'j':'v'):String(p.position);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(p);});
  const active=v.players[v.turn]?.id;
  for(const [key,list] of groups){const tile=key==='j'||key==='v'?10:Number(key);list.forEach((p,i)=>{const [x,y]=tokenSpot(tile,i,list.length,key==='j'),tok=tokenOf(v,p);html+=`<div class="sd sd-piece${p.id===active&&!demo?' is-active':''}${key==='j'?' is-jailed':''}" data-piece="${escape(p.id)}" style="left:${pct(x)};top:${pct(y)};--c:${tok.color}"><div class="sd-shadow"></div><div class="sd-body"><div class="sd-hop">${medal(tok,true)}</div></div></div>`;});}
 }
 return html;
}
function boardBlock(v,{id='main',demo=false,flat=false}={}){
 const cur=v?.players?.[v.turn];
 const status=demo?'':`${txt('Ronda','Round')} ${v.round}  ·  ${cur?(cur.id===human?txt('Tu turno','Your turn'):txt('Turno de ','Turn: ')+cur.name):''}`;
 const canRoll=!demo&&id==='main'&&!fxRun&&!view&&state&&legalActions(state,human).some(a=>a.type==='roll');
 const svg=boardSvg(v,{demo,txt,status,highlight:demo?null:cur?.position,label:txt('Tablero de 40 casillas','40-space board')});
 return `<div class="board3d ${demo?'is-demo is-3d':settings.view3d&&!flat?'is-3d':'is-flat'}" data-board="${id}"><div class="camera"${id==='main'&&camT?` style="transform:${camT}"`:''}><div class="stage"><div class="plane">${svg}<div class="standees">${standees(v,{demo,id})}</div><div class="hud" style="left:${pct(500)};top:${pct(652)}">${diceHtml(v?.dice||[5,6],canRoll)}</div></div></div></div><div class="overlay"></div></div>`;
}
// El tablero 3D se dibuja a 2–3 veces su tamaño y se reduce dentro de la transformación:
// así el texto queda nítido en pantallas de alta densidad (iPhone, Android).
const SS=(()=>{try{const ua=navigator.userAgent,webkit=/iPhone|iPad|iPod/.test(ua)||(/Macintosh/.test(ua)&&!/Chrome\/|Chromium|Edg\/|Firefox/.test(ua));return webkit?2:((window.devicePixelRatio||1)>=2.5?3:2);}catch{return 2;}})();
// Calcula la inclinación y la perspectiva según el ancho real del tablero.
function metrics(w){
 const tiltDeg=w<560?31:37,t=tiltDeg*Math.PI/180,p=w*2.1,a=.95,mt=w*.05,mb=w*.03,oyRel=-a*w;
 const Z=-w*Math.sin(t),Y=-w*Math.cos(t),s=p/(p-Z),yTop=oyRel+(Y-oyRel)*s,H=Math.round(-yTop+mt+mb),bottom=H-mb;
 return {tiltDeg,t,p,w,H,bottom,planeTop:bottom-w,poY:bottom+oyRel};
}
function layoutStages(){
 document.querySelectorAll('.board3d').forEach(el=>{
  const w=el.clientWidth;if(!w)return;const flat=!el.classList.contains('is-3d'),ss=flat?1:SS;
  for(const [k,v] of [['--bw',w+'px'],['--bw0',w+'px'],['--ss',ss],['--sinv',1/ss]])el.style.setProperty(k,v);
  if(el.classList.contains('is-demo'))return;
  if(flat){el._m=null;for(const [k,v] of [['--stage-h',w+'px'],['--plane-top','0px'],['--persp',w*2.4+'px'],['--po-y',w/2+'px'],['--tilt','0deg']])el.style.setProperty(k,v);return;}
  const m=metrics(w);el._m=m;for(const [k,v] of [['--stage-h',m.H+'px'],['--plane-top',m.planeTop+'px'],['--persp',m.p+'px'],['--po-y',m.poY+'px'],['--tilt',m.tiltDeg+'deg']])el.style.setProperty(k,v);
 });
}
function project(el,bx,by){
 const w=el.clientWidth,u=(bx+RIM)/VIEW*w,v=(by+RIM)/VIEW*w,m=el._m;if(!m)return {x:u,y:v};
 const x=u-w/2,y=v-w,Y=y*Math.cos(m.t),Z=y*Math.sin(m.t),s=m.p/(m.p-Z),PX=w/2+x,PY=m.bottom+Y;
 return {x:w/2+(PX-w/2)*s,y:m.poY+(PY-m.poY)*s};
}
function focusCamera(el,bx,by){
 const cam=el.querySelector('.camera'),stage=el.querySelector('.stage');if(!cam||!stage)return;
 const w=el.clientWidth,h=stage.offsetHeight,z=w<560?1.55:1.4,P=project(el,bx,by);
 const tx=Math.min(0,Math.max(w-z*w,w/2-z*P.x)),ty=Math.min(0,Math.max(h-z*h,h*.55-z*P.y));
 camT=`translate(${tx.toFixed(1)}px,${ty.toFixed(1)}px) scale(${z})`;cam.style.transform=camT;
}
const zoomOut=()=>{if(!camT)return;camT='';requestAnimationFrame(()=>requestAnimationFrame(()=>document.querySelectorAll('[data-board="main"] .camera').forEach(c=>c.style.transform='')));};
const mainBoard=()=>document.querySelector('[data-board="main"]');
// Ajusta los textos del tablero que no caben, después de que cargan las fuentes.
function fitText(root=document){root.querySelectorAll('text[data-fit]').forEach(el=>{const max=+el.dataset.fit;el.removeAttribute('textLength');el.removeAttribute('lengthAdjust');let w=0;try{w=el.getComputedTextLength();}catch{}if(w>max){el.setAttribute('textLength',max);el.setAttribute('lengthAdjust','spacingAndGlyphs');}});}

// ---------- Cabecera, portada ----------
const ICON={sound:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',mute:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16.5 9.5l5 5M21.5 9.5l-5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',gear:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7zm8.4 4.7l1.6 1.3-1.8 3.1-2-.6a7.6 7.6 0 0 1-1.9 1.1l-.4 2h-3.6l-.4-2a7.6 7.6 0 0 1-1.9-1.1l-2 .6-1.8-3.1 1.6-1.3a7.4 7.4 0 0 1 0-2.2L2.2 9.6 4 6.5l2 .6A7.6 7.6 0 0 1 7.9 6l.4-2h3.6l.4 2a7.6 7.6 0 0 1 1.9 1.1l2-.6 1.8 3.1-1.6 1.3a7.4 7.4 0 0 1 0 2.2z" fill="currentColor"/></svg>',home:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 11l9-7 9 7v9h-6v-6H9v6H3z" fill="currentColor"/></svg>'};
function header(){return `<header class="topbar"><div class="brand"><img class="brand-logo" src="${ekoLogo}" alt="EKO K’iin"><div>EKO POLY<small>EL SOL ES DE TODOS</small></div></div><nav class="toplinks" aria-label="${txt('Navegación','Navigation')}"><button class="desktop" data-ui="rules">${txt('Cómo jugar','How to play')}</button><button class="icon-btn" data-ui="mute" aria-pressed="${settings.muted}" aria-label="${settings.muted?txt('Activar sonido','Turn sound on'):txt('Silenciar','Mute')}">${settings.muted?ICON.mute:ICON.sound}</button><button class="icon-btn" data-ui="settings" aria-label="${txt('Ajustes','Settings')}">${ICON.gear}</button><button data-ui="language">${en()?'ES':'EN'}</button>${state?`<button class="icon-btn" data-ui="home" aria-label="${txt('Inicio','Home')}">${ICON.home}</button>`:'<span class="chip desktop"><span class="dot"></span>100% CACAO</span>'}</nav></header>`;}
function home(){return `<main class="landing"><section class="hero"><div class="hero-copy"><p class="eyebrow">UN JUEGO ORIGINAL DE EKO K’IIN</p><h1>${txt('Todo comienza<br>con una <em>semilla.</em>','It all begins<br>with a <em>seed.</em>')}</h1><p>${txt('Recorre el tablero, compra tierras, levanta casas y hoteles, y cobra renta a quien llegue. EKO K’iin narra cada jugada.','Go around the board, buy land, raise houses and hotels, and collect rent from every visitor. EKO K’iin narrates every move.')}</p><div class="brand-partners"><span class="bs-emblem"><img src="${bsLogo}" alt="Business Shop"></span><span>×</span><img src="${ekoLogo}" alt="EKO K’iin"></div><div class="hero-actions"><button class="primary" data-ui="setup">${txt('Jugar ahora','Play now')}</button><button data-ui="rules">${txt('Descubrir el juego','Discover the game')}</button></div><div class="hero-meta"><span>◉ ${txt('2–6 jugadores','2–6 players')}</span><span>⌁ ${txt('Sin conexión','Offline play')}</span><span>✦ ${txt('Sin costo','Free to play')}</span></div></div><div class="hero-art">${boardBlock(demoState(),{id:'hero',demo:true})}</div></section><div class="section-title"><h2>${txt('Encuentra tu mesa','Find your table')}</h2><span class="chip">${txt('JUEGA A TU MANERA','PLAY YOUR WAY')}</span></div><section class="mode-grid"><button class="mode-card" data-ui="setup"><span class="symbol">✦</span><span class="eyebrow">${txt('EXPLORA','EXPLORE')}</span><h3>${txt('Una partida para ti','A game for you')}</h3><p>${txt('Practica contra la IA, a tu ritmo y sin conexión.','Practice against AI, at your pace and offline.')}</p><span class="link">${txt('Crear partida','Create game')}</span></button><button class="mode-card" data-ui="online"><span class="symbol">❋</span><span class="eyebrow">${txt('CONECTA','CONNECT')}</span><h3>${txt('La mesa de tus amigos','Your friends’ table')}</h3><p>${txt('Crea una sala privada o únete con un código.','Create a private room or join with a code.')}</p><span class="link">${txt('Jugar en línea','Play online')}</span></button><button class="mode-card" data-ui="resume"><span class="symbol">☼</span><span class="eyebrow">${txt('CONTINÚA','CONTINUE')}</span><h3>${txt('Tu próximo amanecer','Your next sunrise')}</h3><p>${txt('Regresa a tu partida guardada. Cada jugada cuenta.','Return to your saved game. Every move matters.')}</p><span class="link">${txt('Reanudar partida','Resume game')}</span></button></section>${brandWorld()}${ekoShowcase()}<footer class="footer"><span class="bs-emblem footer-emblem"><img src="${bsLogo}" alt="Business Shop"></span><span>${txt('Cacao es una moneda virtual, sin valor monetario.','Cacao is a virtual currency with no monetary value.')}</span><button data-ui="privacy">${txt('Privacidad','Privacy')}</button></footer></main>`;}

// ---------- Mesa de juego ----------
function seatStatus(v,p){if(p.bankrupt)return txt('Fuera de la partida','Eliminated');if(p.jail)return txt('Wallet congelada','Wallet frozen');if(p.bot)return `IA · ${LEVELS[p.level]?.[en()?1:0]||''}`;return p.id===human?txt('Tú','You'):txt('En la mesa','At the table');}
function seats(v){return `<section class="seats" aria-label="${txt('Jugadores','Players')}">${v.players.map((p,i)=>{const tok=tokenOf(v,p),deeds=board.filter(t=>v.assets[t.id]?.owner===p.id);return `<div class="seat${v.turn===i&&v.phase!=='over'?' is-turn':''}${p.bankrupt?' is-out':''}" data-seat="${escape(p.id)}" style="--c:${tok.color}"><span class="seat-token">${medal(tok)}</span><div class="seat-info"><b>${escape(p.name)}</b><span class="seat-cash">${cc(p.cash)}</span><small>${seatStatus(v,p)}</small></div><div class="seat-deeds" aria-label="${deeds.length} ${txt('títulos','deeds')}">${deeds.map(t=>`<i style="--d:${t.color||'#24435c'}"${v.assets[t.id].mortgaged?' class="is-mortgaged"':''} title="${escape(t.name)}"></i>`).join('')}${p.cards.length?`<i class="release" title="${txt('Salida libre','Release card')}"></i>`:''}</div></div>`;}).join('')}</section>`;}
function propertyButtons(v=state){return board.filter(t=>v.assets[t.id]?.owner===human).map(t=>{const a=v.assets[t.id];return `<button class="mini-deed" style="--d:${t.color||'#24435c'}" data-property="${t.id}"><span class="md-band"></span><span class="md-name">${escape(t.name)}</span><span class="md-meta">${a.mortgaged?txt('Hipotecada','Mortgaged'):a.level===5?'Hotel':a.level?`${a.level} ${a.level===1?txt('casa','house'):txt('casas','houses')}`:t.type==='property'?txt('Sin casas','No houses'):''}</span></button>`;}).join('')||`<p class="muted">${txt('Tu primera propiedad te espera.','Your first property awaits.')}</p>`;}
function estate(v){return `<section class="panel estate"><h3>${txt('Tus títulos','Your deeds')}</h3><div class="property-list">${propertyButtons(v)}</div><p class="bank">${txt('Banco','Bank')}: ${v.houses} ${txt('casas','houses')} · ${v.hotels} ${txt('hoteles','hotels')}<br>${txt('Patrimonio','Net worth')}: ${cc(worth(v,human))}</p></section>`;}
function actions(){
 if(fxRun||view)return `<p class="turn-wait"><span class="dots"><i></i><i></i><i></i></span>${txt('En movimiento…','Moving…')}</p>`;
 const acts=legalActions(state,human),p=state.players.find(p=>p.id===human),isTurn=state.players[state.turn].id===human;
 if(state.phase==='auction'){
  const a=state.auction,bid=acts.find(a=>a.type==='bid'),t=board[a.property];
  return `<div class="auction"><p class="auction-label">${txt('Subasta en vivo','Live auction')} <span class="timer" data-timer></span></p>${deedHtml(t,state,{txt,fmt,mode:state.mode,compact:true})}<div class="bid-now"><span>${a.bidder?escape(state.players.find(p=>p.id===a.bidder).name):txt('Sin pujas todavía','No bids yet')}</span><strong>${cc(a.bid)}</strong></div>${bid?`<div class="bid-buttons">${[1,10,50].map(n=>`<button class="btn" data-action="bid" data-amount="${a.bid+n}" ${a.bid+n>p.cash?'disabled':''}>+${n}</button>`).join('')}</div>`:''}${acts.some(a=>a.type==='pass')?`<button class="btn wide" data-action="pass">${txt('No pujar','Pass')}</button>`:''}</div>`;
 }
 if(state.phase==='debt'){
  const d=state.debt;if(d.player!==human)return `<p class="turn-wait">${txt('El jugador está liquidando sus activos.','The player is liquidating their assets.')}</p>`;
  return `<div class="notice">${txt('Necesitas reunir','You need')} <b>${cc(d.amount)}</b>. ${txt('Vende edificios o hipoteca una propiedad.','Sell buildings or mortgage a property.')}</div><div class="action-buttons">${acts.map(a=>`<button class="btn${a.type==='pay_debt'?' btn-gold':''}" data-action="${a.type}" ${a.property!==undefined?`data-id="${a.property}"`:''}>${label(a.type)}${a.property!==undefined?' · '+escape(board[a.property].name):''}</button>`).join('')}</div>`;
 }
 const main=acts.filter(a=>['roll','buy','decline','end','pay_jail','release','tax'].includes(a.type));
 return `<div class="action-buttons">${main.map(a=>`<button class="btn${['roll','buy','end'].includes(a.type)?' btn-gold':''}" data-action="${a.type}" ${a.choice?`data-choice="${a.choice}"`:''}>${a.type==='buy'?`${label('buy')} · ${fmt(board[p.position].price)}`:a.type==='tax'?(a.choice==='fixed'?`${txt('Pagar','Pay')} ${fmt(rules.tax.fixed)}`:`${txt('Pagar','Pay')} 10% · ${fmt(Math.floor(worth(state,human,false)*rules.tax.percent))}`):a.type==='end'&&state.doubles&&!p.jail?txt('Volver a tirar · dobles','Roll again · doubles'):a.type==='roll'&&p.jail?txt('Intentar dobles','Try for doubles'):label(a.type)}</button>`).join('')}${!isTurn?`<p class="turn-wait">${txt('Espera tu turno. Toca cualquier casilla para ver su título.','Wait for your turn. Tap any space to see its deed.')}</p>`:''}</div>`;
}
function whereCard(v){
 const cur=v.players[v.turn],t=board[cur.position];
 if(t.price)return deedHtml(t,v,{txt,fmt,mode:v.mode,compact:true});
 const info={start:txt(`Cada vuelta por aquí cobra ${rules.salary} Cacao.`,`Collect ${rules.salary} Cacao every lap.`),jail:cur.jail?txt('Wallet congelada: paga 50, usa una salida libre o saca dobles.','Wallet frozen: pay 50, use a release card or roll doubles.'):txt('Solo de visita.','Just visiting.'),gojail:txt('Directo a Wallet congelada.','Straight to Wallet frozen.'),rest:txt('Respira. Aquí no se cobra ni se paga.','Take a breath. Nothing to pay here.'),tax:txt('Paga 200 o el 10% de tu patrimonio.','Pay 200 or 10% of your net worth.'),tax2:txt('Aporta 90 Cacao.','Contribute 90 Cacao.'),oracle:txt('Toma una carta del Oráculo K’iin.','Draw an Oráculo K’iin card.'),community:txt('Toma una carta de Tequio.','Draw a Tequio card.')}[t.type]||'';
 return `<div class="where"><b>${escape(t.name)}</b><span>${info}</span></div>`;
}
function turnPanel(v){
 const cur=v.players[v.turn],tok=tokenOf(v,cur),mine=cur.id===human;
 return `<section class="panel turn-panel${mine&&!fxRun&&!view?' is-mine':''}" style="--c:${tok.color}"><div class="turn-head"><span class="seat-token">${medal(tok)}</span><div><small>${mine?txt('Es tu turno','It’s your turn'):txt('Turno de','Turn of')}</small><strong>${escape(cur.name)}</strong></div><span class="round-chip">${txt('Ronda','Round')} ${v.round}</span></div>${actions()}${v.phase==='auction'&&!view?'':whereCard(v)}</section>`;
}
const logPanel=v=>`<section class="log" aria-label="${txt('Historial de la partida','Game history')}" aria-live="polite">${v.log.slice(-6).reverse().map(e=>`<div>${escape(e.text)}</div>`).join('')}</section>`;
function play(){
 const v=view||state;
 if(state.phase==='over'&&!view)return finished();
 const mode=v.mode==='classic'?txt('Clásico','Classic'):v.mode==='short'?txt('Corto','Short'):txt('Tiempo límite','Timed');
 return `<main class="table"><aside class="seats-col">${seats(v)}${estate(v)}</aside><section class="board-col"><div class="board-bar"><span>${online?'● '+escape(room.code):txt('Práctica sin conexión','Offline practice')}</span><span>${mode}${v.mode==='timed'&&v.deadline?` · <span data-clock></span>`:''}</span></div>${boardBlock(v)}<div class="board-tools"><button class="tool" data-ui="zoom" aria-label="${txt('Ampliar tablero','Enlarge board')}">⊕</button><button class="tool" data-ui="toggle-3d" aria-pressed="${settings.view3d}">${settings.view3d?txt('Vista plana','Flat view'):txt('Vista 3D','3D view')}</button><button class="tool" data-ui="properties">${txt('Mis propiedades','My properties')}</button><button class="tool" data-ui="trade">${txt('Negociar','Trade')}</button><button class="tool" data-ui="rules">${txt('Reglas','Rules')}</button><button class="tool" data-ui="save">${txt('Guardar y salir','Save & exit')}</button></div></section><aside class="turn-col">${turnPanel(v)}${logPanel(v)}</aside></main>`;
}
function finished(){const ranking=state.ranking||[];const top=state.players.find(p=>p.id===state.winners[0]);return `<main class="podium"><canvas class="confetti" aria-hidden="true"></canvas><div class="podium-card"><div class="podium-hero"><img src="${mascot}" alt="" class="podium-mascot">${top?`<span class="podium-token">${medal(tokenOf(state,top),true)}</span>`:''}</div><p class="eyebrow">${txt('UN NUEVO AMANECER','A NEW SUNRISE')}</p><h1>${state.winners.map(id=>escape(state.players.find(p=>p.id===id).name)).join(' & ')}<br><span>${txt('hizo florecer su mundo.','made their world bloom.')}</span></h1><ol class="standings">${ranking.map(r=>{const p=state.players.find(p=>p.id===r.id);return `<li><span class="seat-token">${medal(tokenOf(state,p))}</span><span>${escape(p.name)}</span><b>${cc(r.worth)}</b></li>`;}).join('')}</ol><div class="podium-actions"><button class="btn btn-gold" data-ui="new">${txt('Otra partida','Play again')}</button><button class="btn" data-ui="export">${txt('Descargar bitácora','Download game log')}</button>${online?`<button class="btn" data-ui="verify">${txt('Verificar dados','Verify dice')}</button>`:''}</div><p class="notice">${txt('Cacao no se puede canjear por dinero ni tokens.','Cacao cannot be exchanged for money or tokens.')}</p></div></main>`;}
function waiting(){return `<main class="panel lobby-panel"><p class="eyebrow">${txt('LA MESA ESTÁ PUESTA','YOUR TABLE IS READY')}</p><h2>${txt('Invita a tu comunidad','Invite your community')}</h2><p>${txt('Comparte este código con tus amigos.','Share this code with your friends.')}</p><div class="room-code">${escape(room.code)}</div><div class="room-seats">${room.players.map((p,i)=>`<div><span class="seat-token">${medal(TOKENS[i%TOKENS.length])}</span><small>${escape(p.name)}</small></div>`).join('')}</div><p>${room.players.length} / 6 ${txt('jugadores','players')}</p>${room.host===human?`<button class="btn btn-gold" data-ui="start-online" ${room.players.length<2?'disabled':''}>${txt('Empezar partida','Start game')}</button>`:`<p>${txt('Esperando al anfitrión…','Waiting for the host…')}</p>`}<p class="notice gap">${txt('La sala guarda su progreso en el servidor.','Your room progress is saved on the server.')}</p><button class="btn" data-ui="home">${txt('Volver al inicio','Back home')}</button></main>`;}

function render(){
 const d=$('#modal');if(!d.open)d.innerHTML='';
 const inGame=screen==='play'&&!!state;document.body.classList.toggle('in-game',inGame);document.documentElement.classList.toggle('in-game',inGame);
 $('#app').innerHTML=header()+(inGame?play():screen==='waiting'&&room?waiting():home());
 layoutStages();fitText();updateTimer();
 if(inGame)resumeMusic();else pauseMusic();
 if(inGame&&state.phase==='over'&&!view)confetti();
 if(!view)freshBuild=new Set();
}
function modal(html,cls=''){const d=$('#modal');d.className=cls;d.innerHTML=`<button class="close" data-ui="close" aria-label="${txt('Cerrar','Close')}">×</button>${html}`;if(!d.open)d.showModal();layoutStages();fitText(d);}

// ---------- Animación de jugadas ----------
const cardById=id=>{for(const deck of ['oracle','community']){const c=cards[deck].find(c=>c.id===id);if(c)return {...c,deck};}return null;};
function buildPlan(prev,next){
 if(!prev||!next||prev.players.length!==next.players.length||next.log.length<prev.log.length)return [];
 const steps=[],pos=Object.fromEntries(prev.players.map(p=>[p.id,p.position])),back={};let lander=null;
 for(const e of next.log.slice(prev.log.length)){
  if(e.type==='roll')steps.push({kind:'dice',dice:e.dice,player:e.player});
  else if(e.type==='land'){lander=e.player;if(pos[e.player]!==e.position){steps.push({kind:'walk',player:e.player,from:pos[e.player],to:e.position,back:!!back[e.player]});pos[e.player]=e.position;}back[e.player]=false;}
  else if(e.type==='card'){const card=cardById(e.card);if(card){steps.push({kind:'card',card,player:lander});if(card.type==='back')back[lander]=true;}}
 }
 for(const p of next.players)if(!p.bankrupt&&pos[p.id]!==p.position)steps.push({kind:'jump',player:p.id,to:p.position,jail:!!p.jail});
 return steps;
}
function commit(prev,next){
 stopFx();
 const plan=reduced()?buildPlan(prev,next).filter(s=>s.kind==='card'):buildPlan(prev,next);
 freshBuild=new Set(board.filter(t=>(next.assets[t.id]?.level||0)>(prev?.assets?.[t.id]?.level||0)).map(t=>t.id));
 if(!plan.length){view=null;render();after(prev,next);return;}
 view=prev;render();
 const run={cancelled:false,timers:[],finish:()=>{view=null;render();zoomOut();after(prev,next);}};fxRun=run;
 const wait=ms=>new Promise(res=>run.timers.push(setTimeout(res,ms)));
 (async()=>{
  for(const step of plan){if(run.cancelled)return;try{await fx[step.kind](step,run,wait);}catch{}}
  if(run.cancelled)return;fxRun=null;run.finish();
 })();
}
function stopFx(finish=true){if(!fxRun)return;const run=fxRun;fxRun=null;run.cancelled=true;run.timers.forEach(clearTimeout);revealDone?.();revealDone=null;if(finish)run.finish();else{view=null;camT='';}}
function restart(el,cls){el.classList.remove(cls);void el.offsetWidth;el.classList.add(cls);}
function banner(text,kind=''){const el=mainBoard();if(!el)return;const ov=el.querySelector('.overlay');const b=document.createElement('div');b.className='banner '+kind;b.textContent=text;ov.appendChild(b);setTimeout(()=>b.remove(),1500);}
function coinBurst(tileId,count=12){
 const el=mainBoard(),tile=el?.querySelector(`.tile[data-property="${tileId}"]`);if(!el||!tile||reduced())return;
 const ov=el.querySelector('.overlay'),r=tile.getBoundingClientRect(),o=ov.getBoundingClientRect(),x=r.left+r.width/2-o.left,y=r.top+r.height/2-o.top;
 for(let i=0;i<count;i++){const c=document.createElement('span');c.className='coin-fly';c.innerHTML='<svg aria-hidden="true"><use href="#ic-coin"/></svg>';c.style.left=x+'px';c.style.top=y+'px';c.style.setProperty('--dx',(random(160)-80)+'px');c.style.setProperty('--dy',(-60-random(90))+'px');c.style.animationDelay=(i*25)+'ms';ov.appendChild(c);setTimeout(()=>c.remove(),1400);}
}
function frost(){const el=mainBoard();if(!el)return;restart(el,'is-frost');setTimeout(()=>el.classList.remove('is-frost'),1400);}
const fx={
 async dice(step,run,wait){
  const el=mainBoard(),[a,b]=step.dice;sfx.dice();
  if(el&&!reduced()){settle(0,a,true);settle(1,b,true);el.querySelectorAll('.die3d').forEach((d,i)=>d.style.transform=dieTransform(i));const box=el.querySelector('.dice3d');box.classList.remove('can-roll');restart(box,'is-tossing');}
  else{settle(0,a,false);settle(1,b,false);el?.querySelectorAll('.die3d').forEach((d,i)=>d.style.transform=dieTransform(i));}
  diceShown=[a,b];await wait(reduced()?200:step.player===human?760:600);buzz(16);await wait(reduced()?0:step.player===human?340:260);
  if(step.player===human)speak(a===b?txt(`¡${a+b}! ¡Dobles!`,`${a+b}! Doubles!`):`¡${a+b}!`,true);
  if(a===b){sfx.doubles();banner(txt('¡Dobles!','Doubles!'),'is-doubles');await wait(450);}
 },
 async walk(step,run,wait){
  const el=mainBoard(),piece=el?.querySelector(`.sd-piece[data-piece="${CSS.escape(step.player)}"]`);if(!piece)return;
  // Tus movimientos van a ritmo de juego con cámara; los de la IA, un poco más ágiles y sin mover la cámara.
  const mine=step.player===human,n=step.back?(step.from-step.to+40)%40:(step.to-step.from+40)%40,ms=n>12?95:mine?165:125,follow=mine&&settings.camera&&!reduced();
  piece.parentElement.appendChild(piece);piece.classList.add('is-moving');piece.style.transitionDuration=ms+'ms';piece.style.setProperty('--hop-ms',ms+'ms');
  for(let i=1;i<=n;i++){
   if(run.cancelled)return;const id=step.back?(step.from-i+40)%40:(step.from+i)%40,[x,y]=tokenSpot(id,0,1,false);
   piece.style.left=pct(x);piece.style.top=pct(y);restart(piece,'hop');sfx.step(i);if(follow)focusCamera(el,x,y);
   await wait(ms);
  }
  sfx.land();buzz(8);piece.classList.remove('is-moving');await wait(160);
 },
 async jump(step,run,wait){
  const el=mainBoard(),piece=el?.querySelector(`.sd-piece[data-piece="${CSS.escape(step.player)}"]`);if(!piece)return;
  const [x,y]=tokenSpot(step.to,0,1,step.jail);piece.style.transitionDuration='700ms';piece.style.setProperty('--hop-ms','700ms');piece.parentElement.appendChild(piece);
  if(step.jail){sfx.freeze();frost();buzz([40,40,40]);}else sfx.whoosh();
  if(step.player===human&&settings.camera&&!reduced())focusCamera(el,x,y);
  piece.style.left=pct(x);piece.style.top=pct(y);restart(piece,'hop');await wait(820);
 },
 async card(step,run,wait){
  const el=mainBoard();if(!el)return;const c=step.card,mine=step.player===human,who=view?.players.find(p=>p.id===step.player)||state.players.find(p=>p.id===step.player);
  const title=c.deck==='oracle'?'Oráculo K’iin':'Tequio',icon=c.deck==='oracle'?'ic-oracle':'ic-tequio';
  sfx.card();
  const ov=el.querySelector('.overlay'),box=document.createElement('div');box.className=`reveal is-${c.deck}`;
  box.innerHTML=`<div class="reveal-card"><div class="rc-face rc-back"><svg aria-hidden="true"><use href="#${icon}"/></svg><b>${title.toUpperCase()}</b></div><div class="rc-face rc-front"><header><svg aria-hidden="true"><use href="#${icon}"/></svg><span>${title}</span></header><p>${escape(c.text)}</p><footer><small>${escape(who?.name||'')}</small><button class="btn btn-gold" data-ui="card-ok">${txt('Continuar','Continue')}</button></footer></div></div>`;
  ov.appendChild(box);speak((mine?'':`${who?.name||''}: `)+c.text,mine);
  await new Promise(res=>{const t=setTimeout(res,mine?6500:3200);run.timers.push(t);revealDone=()=>{clearTimeout(t);res();};});
  revealDone=null;box.classList.add('is-leaving');await wait(260);box.remove();
 }
};

// ---------- Narración, sonido y efectos después de cada jugada ----------
function speak(text,interrupt=false){voice.say(text,{interrupt});}
voice.onSpeech(text=>{bubble=text;const m=mainBoard()?.querySelector('.sd-mascot');if(!m)return;const b=m.querySelector('.bubble');b.textContent=text;b.hidden=false;m.classList.add('is-talking');restart(b,'pop');},()=>{bubble=null;const m=mainBoard()?.querySelector('.sd-mascot');if(!m)return;m.classList.remove('is-talking');const b=m.querySelector('.bubble');if(b)b.hidden=true;});
function after(prev,next){
 if(!next)return;
 deltas(prev,next);
 const ev=prev&&next.log.length>=prev.log.length?next.log.slice(prev.log.length):[];
 const name=id=>next.players.find(p=>p.id===id)?.name||'',me=next.players.find(p=>p.id===human),lines=[];
 for(const t of board){const a0=prev?.assets?.[t.id],a1=next.assets[t.id];if(!a1||!a0)continue;
  if(!a0.owner&&a1.owner){sfx.cash();coinBurst(t.id);if(a1.owner===human)buzz([12,40,12]);lines.push(a1.owner===human?txt(`¡${t.name} ya es tuya!`,`${t.name} is yours!`):txt(`${name(a1.owner)} compra ${t.name}.`,`${name(a1.owner)} buys ${t.name}.`));}
  if((a1.level||0)>(a0.level||0)){sfx.build();if(a1.owner===human)lines.push(a1.level===5?txt(`¡Hotel en ${t.name}!`,`A hotel on ${t.name}!`):txt(`¡Casa nueva en ${t.name}!`,`New house on ${t.name}!`));}
  if(a1.owner===human&&a0.mortgaged!==a1.mortgaged)(a1.mortgaged?sfx.coin:sfx.pay)();
 }
 for(const e of ev){
  if(e.type==='payment'){if(e.from===human){sfx.pay();buzz(30);lines.unshift(e.to?txt(`Pagas ${e.amount} de renta a ${name(e.to)}.`,`You pay ${e.amount} rent to ${name(e.to)}.`):txt(`Pagas ${e.amount}.`,`You pay ${e.amount}.`));}else if(e.to===human){sfx.coin();coinBurst(next.players.find(p=>p.id===e.from)?.position);lines.unshift(txt(`¡${name(e.from)} te paga ${e.amount} de renta!`,`${name(e.from)} pays you ${e.amount} rent!`));}}
  if(e.type==='salary'&&me&&e.text.startsWith(me.name)){sfx.coin();lines.push(txt(`¡Amanecer K’iin! Cobras ${rules.salary}.`,`Sunrise! You collect ${rules.salary}.`));}
  if(e.type==='jail'){sfx.freeze();lines.push(me&&e.text.startsWith(me.name+':')?txt('¡Brrr! Tu wallet se congeló.','Brrr! Your wallet is frozen.'):txt(`¡${e.text.split(':')[0]} quedó congelado!`,`${e.text.split(':')[0]} is frozen!`));}
  if(e.type==='auction'){sfx.gavel();lines.push(txt(`¡Subasta! ${e.text.replace(/^Subasta:\s*/,'').replace(/\.$/,'')}. ¿Quién da más?`,`Auction! Who bids more?`));}
  if(e.type==='bid')sfx.bid();
  if(e.type==='debt'&&e.text.startsWith(me?.name||'\u0000'))lines.push(txt('Te falta Cacao: vende o hipoteca para pagar.','You are short: sell or mortgage to pay.'));
  if(e.type==='bankrupt'){sfx.lose();lines.push(e.text);}
  if(e.type==='finish'){sfx.win();buzz([30,60,30,60,90]);const w=next.winners.map(name).join(txt(' y ',' and '));lines.length=0;lines.push(next.winners.includes(human)?txt(`¡Ganaste, ${me?.name}! ¡Hiciste florecer tu mundo!`,`You won, ${me?.name}! Your world is in bloom!`):txt(`¡${w} gana la partida!`,`${w} wins the game!`));}
 }
 const myTurnNow=next.phase==='roll'&&next.players[next.turn]?.id===human&&(prev?.turn!==next.turn||prev?.phase!=='roll');
 if(myTurnNow){sfx.turn();if(lines.length<2)lines.push(txt(`¡Tu turno, ${me?.name||''}!`,`Your turn, ${me?.name||''}!`));}
 const mine=prev&&(prev.players[prev.turn]?.id===human);
 lines.slice(0,2).forEach((l,i)=>speak(l,i===0&&mine));
 if(!online)schedule();
}
function deltas(prev,next){
 if(!prev)return;next.players.forEach(p=>{const before=prev.players.find(q=>q.id===p.id);if(!before||before.cash===p.cash)return;const seat=document.querySelector(`.seat[data-seat="${CSS.escape(p.id)}"] .seat-cash`);if(!seat)return;const d=p.cash-before.cash,s=document.createElement('span');s.className='delta '+(d>0?'up':'down');s.textContent=(d>0?'+':'−')+fmt(Math.abs(d));seat.appendChild(s);setTimeout(()=>s.remove(),1900);});
}
function confetti(){
 const cv=document.querySelector('.confetti');if(!cv||reduced())return;const ctx=cv.getContext('2d');if(!ctx)return;
 const W=cv.width=cv.offsetWidth,H=cv.height=cv.offsetHeight,colors=['#f2b705','#e5007e','#19a7b4','#76b82a','#e4462c','#7b3fa0','#fff'];
 const bits=Array.from({length:160},()=>({x:Math.random()*W,y:-20-Math.random()*H*.6,vx:Math.random()*2-1,vy:2+Math.random()*3,r:Math.random()*6.28,vr:Math.random()*.2-.1,s:5+Math.random()*7,c:colors[random(colors.length)]}));
 const start=performance.now();(function frame(t){if(!cv.isConnected)return;ctx.clearRect(0,0,W,H);bits.forEach(b=>{b.x+=b.vx;b.y+=b.vy;b.r+=b.vr;ctx.save();ctx.translate(b.x,b.y);ctx.rotate(b.r);ctx.fillStyle=b.c;ctx.fillRect(-b.s/2,-b.s/4,b.s,b.s/2);ctx.restore();});if(t-start<5200)requestAnimationFrame(frame);else ctx.clearRect(0,0,W,H);})(start);
}

// ---------- Partida local ----------
function setup(){const chosen=Number(store.get('eko-poly-token','0'))||0;modal(`<h2>${txt('Tu mesa, tus reglas','Your table, your rules')}</h2><form id="setup"><label for="name">${txt('Tu nombre','Your name')}</label><input id="name" name="name" maxlength="20" value="${escape(store.get('eko-poly-name','')||'')}" placeholder="${txt('Explorador','Explorer')}" required><fieldset class="token-pick"><legend>${txt('Tu ficha','Your token')}</legend>${TOKENS.map((t,i)=>`<label><input type="radio" name="token" value="${i}" ${i===chosen?'checked':''}><span class="tp-art">${medal(t,true)}</span><small>${en()?t.en:t.es}</small></label>`).join('')}</fieldset><div class="columns"><div><label for="bots">${txt('Rivales IA','AI opponents')}</label><select id="bots" name="bots">${[1,2,3,4,5].map(n=>`<option value="${n}" ${n===3?'selected':''}>${n}</option>`).join('')}</select></div><div><label for="level">${txt('Dificultad','Difficulty')}</label><select name="level" id="level"><option value="0">${txt('Semilla · fácil','Seed · easy')}</option><option value="1">${txt('Raíz · normal','Root · normal')}</option><option value="2" selected>${txt('Ceiba · difícil','Ceiba · hard')}</option><option value="3">${txt('Sol · experto','Sun · expert')}</option></select></div></div><label for="mode">${txt('Duración','Duration')}</label><select id="mode" name="mode"><option value="short">${txt('Corto · hasta la segunda quiebra','Short · until the second bankruptcy')}</option><option value="timed">${txt('Tiempo límite · 30 minutos','Timed · 30 minutes')}</option><option value="classic">${txt('Clásico · último jugador en pie','Classic · last player standing')}</option></select><button class="btn btn-gold wide gap" type="submit">${txt('Que comience el viaje','Let the journey begin')}</button><p class="notice gap">${txt('Quien saca el tiro más alto empieza. Tu progreso se guarda en este dispositivo.','Highest roll goes first. Your progress is saved on this device.')}</p></form>`,'is-setup');}
// Orden inicial por tirada de dados; los empates vuelven a tirar.
function rollOrder(ids){
 const rolls={},rank=list=>{const r=list.map(id=>({id,v:random(6)+random(6)+2}));r.forEach(x=>{rolls[x.id]??=x.v;});const by=new Map();r.forEach(x=>{if(!by.has(x.v))by.set(x.v,[]);by.get(x.v).push(x.id);});return [...by.entries()].sort((a,b)=>b[0]-a[0]).flatMap(([,g])=>g.length>1?rank(g):g);};
 return {order:rank(ids),rolls};
}
function startPractice(form){
 clearTimeout(aiTimer);clearTimeout(localTimer);socket?.close();socket=null;online=false;room=null;human='you';stopFx(false);view=null;
 const name=String(form.get('name')).trim().slice(0,20)||txt('Explorador','Explorer'),mine=Number(form.get('token'))||0;store.set('eko-poly-name',name);store.set('eko-poly-token',String(mine));
 const others=TOKENS.map((_,i)=>i).filter(i=>i!==mine);
 const players=[{id:human,name,bot:false,token:mine},...Array.from({length:Number(form.get('bots'))},(_,i)=>({id:'bot'+i,name:BOTS[i],bot:true,level:Number(form.get('level')),token:others[i]}))];
 const {order,rolls}=rollOrder(players.map(p=>p.id));
 state=createGame({players,mode:form.get('mode'),order,propertyOrder:shuffled(board.filter(t=>t.type==='property').map(t=>t.id)),decks:{oracle:shuffled(cards.oracle),community:shuffled(cards.community)},deadline:form.get('mode')==='timed'?Date.now()+rules.timeLimitMinutes*60000:null});
 screen='play';$('#modal').close();save();render();
 const first=state.players[0];
 toast(txt('Orden por tirada: ','Order by roll: ')+state.players.map(p=>`${p.name} ${rolls[p.id]}`).join(' · '));
 speak(first.id===human?txt(`¡Hola, ${name}! Sacaste ${rolls[first.id]} y empiezas tú. ¡Lanza los dados!`,`Hi ${name}! You rolled ${rolls[first.id]}, you go first. Roll the dice!`):txt(`¡Hola, ${name}! Empieza ${first.name}, que sacó ${rolls[first.id]}.`,`Hi ${name}! ${first.name} goes first with ${rolls[first.id]}.`),true);
 if(first.id===human)sfx.turn();
 schedule();
}
function save(){if(!online&&state&&!store.set('eko-poly-save',JSON.stringify({state,human,saved:Date.now()})))toast(txt('No se pudo guardar: revisa el almacenamiento del dispositivo.','Could not save: check device storage.'));}
function perform(action){
 try{
  if(online){send({type:'action',action,revision:state.revision});return;}
  const prev=state;state=apply(state,{...action,player:action.player||human}).state;save();commit(prev,state);
 }catch(e){toast(e.message);}
}
function schedule(){
 clearTimeout(aiTimer);clearTimeout(localTimer);if(online||screen!=='play'||!state||state.phase==='over'||fxRun)return;
 if(state.mode==='timed'&&Date.now()>=state.deadline){perform({type:'time_limit'});return;}
 if(state.phase==='auction'){deadline=Date.now()+rules.auctionSeconds*1000;localTimer=setTimeout(()=>perform({type:'timeout'}),rules.auctionSeconds*1000);}
 const actor=state.phase==='debt'?state.players.find(p=>p.id===state.debt.player):state.phase==='auction'?state.players.find(p=>p.bot&&legalActions(state,p.id).length):state.players[state.turn];
 if(actor?.bot)aiTimer=setTimeout(()=>{const a=chooseAction(state,actor.id,dice(),actor.level);if(a)perform(a);},state.phase==='auction'?520:760);
}
function updateTimer(){document.querySelectorAll('[data-timer]').forEach(el=>el.textContent=`${Math.max(0,Math.ceil((deadline-Date.now())/1000))} s`);document.querySelectorAll('[data-clock]').forEach(el=>{const s=Math.max(0,Math.ceil(((state?.deadline||0)-Date.now())/1000));el.textContent=`${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;});}
setInterval(()=>{updateTimer();if(!online&&screen==='play'&&state?.mode==='timed'&&state.phase!=='over'&&!fxRun&&Date.now()>=state.deadline)perform({type:'time_limit'});},1000);

// ---------- Títulos y modales ----------
function showProperty(id){
 const v=view||state,t=board[id],a=v?.assets[id];
 if(!a){const info={start:txt(`Cada paso por el Amanecer entrega ${rules.salary} Cacao.`,`Every pass through Sunrise pays ${rules.salary} Cacao.`),jail:txt('Solo de visita, salvo si te enviaron aquí. Puedes pagar 50, usar una tarjeta o intentar dobles.','Just visiting unless you were sent here. Pay 50, use a card or try for doubles.'),gojail:txt('Tu wallet queda congelada y termina tu turno.','Your wallet freezes and your turn ends.'),rest:txt('Respira. Esta casilla no cobra ni entrega Cacao.','Take a breath. This space neither charges nor pays.'),tax:txt('Elige 200 Cacao o el 10% de tu patrimonio.','Choose 200 Cacao or 10% of your net worth.'),tax2:txt('Aporta 90 Cacao.','Contribute 90 Cacao.'),oracle:txt('Toma una carta del Oráculo K’iin.','Draw an Oráculo K’iin card.'),community:txt('Toma una carta de Tequio.','Draw a Tequio card.')}[t.type]||'';modal(`<h2>${escape(t.name)}</h2><p>${info}</p>`);return;}
 const acts=fxRun||view?[]:legalActions(state,human).filter(ac=>ac.property===id);
 modal(`${deedHtml(t,v,{txt,fmt,mode:v.mode})}<div class="action-buttons deed-actions">${acts.map(ac=>`<button class="btn" data-action="${ac.type}" data-id="${id}">${label(ac.type)}</button>`).join('')}</div>`,'is-deed');
}
function trade(){if(!state||state.phase==='auction'||state.phase==='debt'||fxRun)return toast(txt('No se puede negociar durante una subasta o una deuda.','Trading is unavailable during an auction or debt.'));const target=state.players.find(p=>p.id!==human&&!p.bankrupt);if(!target)return;tradeForm(target.id);}
function tradeForm(target){const column=id=>`<label>${txt('Cacao','Cacao')}</label><input type="number" name="${id===human?'give':'receive'}Cash" min="0" max="${state.players.find(p=>p.id===id).cash}" value="0" required>${board.filter(t=>state.assets[t.id]?.owner===id).map(t=>`<label class="check"><input type="checkbox" name="${id===human?'give':'receive'}Property" value="${t.id}"><i style="--d:${t.color||'#24435c'}"></i>${escape(t.name)}</label>`).join('')}`;modal(`<h2>${txt('Hagamos un trato','Make a trade')}</h2><form id="trade"><label for="target">${txt('Negociar con','Trade with')}</label><select id="target" name="target">${state.players.filter(p=>p.id!==human&&!p.bankrupt).map(p=>`<option value="${p.id}" ${p.id===target?'selected':''}>${escape(p.name)}</option>`).join('')}</select><div class="columns"><section><h3 class="gap">${txt('Lo que doy','I give')}</h3>${column(human)}</section><section><h3 class="gap">${txt('Lo que recibo','I receive')}</h3>${column(target)}</section></div><p class="notice gap">${txt('Los grupos deben estar libres de edificios. Las hipotecas recibidas cobran el 10% de interés. La IA solo acepta ofertas que no reduzcan el valor de sus activos.','Groups must have no buildings. Received mortgages charge 10% interest. AI only accepts offers that preserve its asset value.')}</p><button class="btn btn-gold wide" type="submit">${txt('Enviar propuesta','Send offer')}</button></form>`);}
function rulesModal(){modal(`<p class="eyebrow">DE SEMILLA A CEIBA</p><h2>${txt('Tu primer amanecer','Your first sunrise')}</h2><ol class="tutorial-steps"><li>${txt('<b>Lanza y avanza.</b> Toca los dados o el botón. Recorres 40 casillas y cada paso por Amanecer K’iin te entrega 200 Cacao.','<b>Roll and move.</b> Tap the dice or the button. You travel 40 spaces and each pass through Amanecer K’iin pays 200 Cacao.')}</li><li>${txt('<b>Compra tu tierra.</b> Si caes en una propiedad libre, cómprala o deja que todos pujen. Cuando alguien caiga en la tuya, cobras renta.','<b>Buy land.</b> Land on a free property to buy it or put it up for auction. Collect rent when others land on yours.')}</li><li>${txt('<b>Completa el color.</b> Con todo el grupo duplicas la renta y puedes construir casas parejas y luego un hotel. La tercera casa dispara la renta.','<b>Complete the color.</b> Owning the whole group doubles rent and lets you build even houses, then a hotel. The third house makes rent jump.')}</li><li>${txt('<b>Cuida tu Cacao.</b> Negocia, vende edificios a mitad de precio o hipoteca si necesitas pagar.','<b>Look after your Cacao.</b> Trade, sell buildings for half price or mortgage to pay.')}</li><li>${txt('<b>Cartas.</b> Oráculo K’iin te mueve por el tablero; Tequio reparte y pide Cacao a la comunidad.','<b>Cards.</b> Oráculo K’iin moves you around; Tequio gives and asks for Cacao.')}</li></ol><p class="notice">${txt('Los dobles dan otro tiro. Tres dobles seguidos congelan tu wallet: sales pagando 50, con una salida libre o sacando dobles en tus siguientes tres turnos.','Doubles grant another roll. Three doubles in a row freeze your wallet: pay 50, use a release card or roll doubles within three turns.')}</p><button class="btn btn-gold wide" data-ui="close">${txt('Entendido, a jugar','Got it, let’s play')}</button>`);}
function settingsModal(){const row=(key,title,desc,extra='')=>`<label class="switch"><span><b>${title}</b><small>${desc}${extra}</small></span><input type="checkbox" name="${key}" ${settings[key]?'checked':''}><i aria-hidden="true"></i></label>`;modal(`<h2>${txt('Ajustes','Settings')}</h2><form id="settings" class="settings">${row('fx',txt('Efectos de sonido','Sound effects'),txt('Dados, pasos, monedas y cartas.','Dice, steps, coins and cards.'))}${row('music',txt('Marimba de fondo','Background marimba'),txt('Suena durante la partida.','Plays during the game.'))}${row('voice',txt('Voz de EKO K’iin','EKO K’iin voice'),txt('Narra tus jugadas con su voz.','Narrates your moves out loud.'),voice.voiceSupported()?'':txt(' Este dispositivo no tiene voz disponible; verás sus globos.',' This device has no voice available; you will see the speech bubbles.'))}${row('view3d',txt('Tablero 3D','3D board'),txt('Inclina el tablero como sobre una mesa.','Tilts the board like on a table.'))}${row('camera',txt('Cámara que sigue la ficha','Follow camera'),txt('Acerca la vista mientras la ficha avanza.','Zooms in while the token moves.'))}</form><p class="notice gap">${settings.muted?txt('El sonido está silenciado desde la barra superior.','Sound is muted from the top bar.'):txt('Puedes silenciar todo con el botón de bocina.','Mute everything with the speaker button.')}</p>`);}

// ---------- En línea ----------
async function connect(){if(socket?.readyState===1)return;let token=store.get('eko-poly-session');if(!token){const name=store.get('eko-poly-name')||'Explorador';const r=await fetch('/api/guest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})});if(!r.ok)throw Error('No se pudo abrir una sesión.');const data=await r.json();token=data.token;store.set('eko-poly-session',token);human=data.id;}await new Promise((resolve,reject)=>{socket=new WebSocket(location.origin.replace(/^http/,'ws'));const timer=setTimeout(()=>{socket.close();reject(Error('Servidor no disponible.'));},10000);socket.onopen=()=>socket.send(JSON.stringify({type:'auth',token}));socket.onerror=()=>{clearTimeout(timer);reject(Error('Servidor no disponible.'));};socket.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==='auth'){human=m.id;clearTimeout(timer);resolve();}if(m.type==='room'){room=m.room;online=true;screen='waiting';render();}if(m.type==='state'){const prev=screen==='play'&&state?.matchId===m.state.matchId?state:null;room=m.room;state=m.state;deadline=m.deadline;online=true;screen='play';clearTimeout(aiTimer);clearTimeout(localTimer);save();if(prev)commit(prev,state);else{view=null;render();}const offer=state.offers.find(o=>o.to===human);if(offer&&offer.id!==window.lastOffer){window.lastOffer=offer.id;modal(`<h2>Propuesta de intercambio</h2><p>Recibes ${offer.give.cash} Cacao y ${offer.give.properties.map(i=>escape(board[i].name)).join(', ')||'ninguna propiedad'}. Entregas ${offer.receive.cash} Cacao y ${offer.receive.properties.map(i=>escape(board[i].name)).join(', ')||'ninguna propiedad'}.</p><button class="btn btn-gold" data-offer="${offer.id}" data-accept="true">Aceptar</button> <button class="btn" data-offer="${offer.id}" data-accept="false">Rechazar</button>`);}}if(m.type==='error'){toast(m.message);if(m.code==='AUTH'){store.del('eko-poly-session');clearTimeout(timer);reject(Error('Sesión vencida. Vuelve a conectar.'));}}};socket.onclose=()=>{if(online)toast('Conexión perdida. Vuelve a entrar con el código para reanudar.');};});}
function send(message){if(socket?.readyState!==1)throw Error('Sin conexión con el servidor.');socket.send(JSON.stringify(message));}
function onlineModal(){if(location.protocol==='file:'||location.protocol==='capacitor:'){toast('Para jugar en línea abre la versión web en el servidor de EKO POLY.');return;}modal(`<h2>${txt('Una mesa compartida','A shared table')}</h2><form id="online"><label for="online-name">${txt('Tu nombre','Your name')}</label><input id="online-name" name="name" value="${escape(store.get('eko-poly-name','')||'')}" maxlength="20" required><label for="code">${txt('Código de sala (vacío para crear)','Room code (blank to create)')}</label><input id="code" name="code" maxlength="6" pattern="[A-Za-z0-9]{6}|" placeholder="ABC123"><button class="btn btn-gold wide gap">${txt('Entrar a la mesa','Join the table')}</button></form><p class="notice gap">${txt('Requiere conexión al servidor. Las salas privadas son gratuitas.','Requires a server connection. Private rooms are free.')}</p>`);}

// ---------- Eventos ----------
function rollNow(){if(fxRun||view||!state)return;if(!legalActions(state,human).some(a=>a.type==='roll'))return;perform({type:'roll',dice:dice()});}
// El audio se desbloquea al primer toque; la voz, con un toque o tecla (iOS lo exige así).
const wake=()=>{unlock();voice.prime();};document.addEventListener('pointerdown',unlock,{passive:true});document.addEventListener('click',wake,true);document.addEventListener('keydown',wake,true);
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-ui],[data-action],[data-property],[data-offer]');if(!b)return;
 try{
  if(b.dataset.property!==undefined){if(state&&screen==='play'){sfx.click();showProperty(Number(b.dataset.property));}return;}
  if(b.dataset.action){if(fxRun||view)return;const action={type:b.dataset.action};if(b.dataset.id)action.property=Number(b.dataset.id);if(b.dataset.amount)action.amount=Number(b.dataset.amount);if(b.dataset.choice)action.choice=b.dataset.choice;if(action.type==='roll')action.dice=dice();$('#modal').close();perform(action);return;}
  if(b.dataset.offer){$('#modal').close();perform({type:'trade_reply',offer:b.dataset.offer,accept:b.dataset.accept==='true'});return;}
  switch(b.dataset.ui){
   case 'setup':sfx.click();setup();break;
   case 'close':$('#modal').close();break;
   case 'rules':rulesModal();break;
   case 'roll-dice':rollNow();break;
   case 'card-ok':revealDone?.();break;
   case 'home':case 'save':stopFx(false);voice.stop();save();screen='home';clearTimeout(aiTimer);clearTimeout(localTimer);render();break;
   case 'new':state=null;view=null;screen='home';render();setup();break;
   case 'language':language=en()?'es':'en';document.documentElement.lang=en()?'en':'es-MX';store.set('eko-poly-language',language);applyAudio();render();break;
   case 'mute':settings.muted=!settings.muted;store.set('eko-poly-sound',settings.muted?'off':'on');applyAudio();if(settings.muted)voice.stop();render();break;
   case 'settings':settingsModal();break;
   case 'toggle-3d':settings.view3d=!settings.view3d;store.set('eko-poly-3d',settings.view3d?'on':'off');render();break;
   case 'resume':{let saved=null;try{saved=JSON.parse(store.get('eko-poly-save')||'null');}catch{}if(!saved)return toast(txt('Aún no tienes una partida guardada.','No saved game yet.'));socket?.close();online=false;state=saved.state;human=saved.human;view=null;screen='play';render();speak(txt('¡Qué bueno que volviste! Seguimos jugando.','Welcome back! Let’s keep playing.'),true);schedule();break;}
   case 'zoom':modal(`<h2>${txt('Explora el tablero','Explore the board')}</h2><div class="zoom-wrap"><div class="zoom-inner">${boardBlock(view||state,{id:'zoom',flat:true})}</div></div>`,'is-zoom');break;
   case 'properties':if(state)modal(`<h2>${txt('Tu patrimonio','Your estate')}</h2><div class="property-list">${propertyButtons(view||state)}</div>`);break;
   case 'trade':trade();break;
   case 'online':onlineModal();break;
   case 'start-online':send({type:'start',code:room.code});break;
   case 'export':{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(state,null,2)],{type:'application/json'}));a.download='eko-poly-partida.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);break;}
   case 'verify':{const r=await fetch(`/api/proof/${room.code}`);const p=await r.json();modal(`<h2>Verificar partida</h2><p>${p.valid?'Todas las tiradas coinciden con la semilla publicada.':'Prueba no disponible.'}</p><p style="overflow-wrap:anywhere">${escape(p.commitment)}</p><a href="/api/proof/${room.code}" target="_blank" rel="noopener">Abrir semilla y tiradas</a>`);break;}
   case 'privacy':modal(`<h2>Tu privacidad</h2><p>La práctica guarda nombre, preferencias y partida en tu dispositivo. Las salas privadas conservan la sesión, los participantes y las jugadas en el servidor.</p><p>Esta entrega gratuita no solicita claves, billeteras, datos bancarios ni documentos. Cacao es virtual y no canjeable.</p><button class="btn danger" data-ui="erase">Borrar datos locales</button>`);break;
   case 'erase':store.keys().filter(k=>k.startsWith('eko-poly-')).forEach(k=>store.del(k));state=null;view=null;screen='home';$('#modal').close();render();break;
  }
 }catch(err){toast(err.message);}
});
document.addEventListener('change',e=>{
 if(e.target.id==='target')tradeForm(e.target.value);
 if(e.target.form?.id==='settings'){const k=e.target.name;settings[k]=e.target.checked;store.set({fx:'eko-poly-fx',music:'eko-poly-music',voice:'eko-poly-voice',view3d:'eko-poly-3d',camera:'eko-poly-camera'}[k],e.target.checked?'on':'off');applyAudio();if(k==='voice'&&e.target.checked)speak(txt('¡Hola! Yo te cuento la partida.','Hi! I will narrate the game.'),true);if(k==='view3d'&&screen==='play')render();}
});
document.addEventListener('keydown',e=>{
 if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-property],[data-ui="roll-dice"]')){e.preventDefault();e.target.dispatchEvent(new MouseEvent('click',{bubbles:true}));}
});
document.addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.target);try{if(e.target.id==='setup')startPractice(f);if(e.target.id==='online'){store.set('eko-poly-name',f.get('name'));await connect();$('#modal').close();const clientSeed=Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('');send({type:f.get('code')?'join':'create',code:String(f.get('code')).toUpperCase(),clientSeed});}if(e.target.id==='trade'){const to=f.get('target'),give={cash:Number(f.get('giveCash')),properties:f.getAll('giveProperty').map(Number),cards:[]},receive={cash:Number(f.get('receiveCash')),properties:f.getAll('receiveProperty').map(Number),cards:[]};$('#modal').close();perform({type:'trade_offer',to,give,receive});if(!online&&state.players.find(p=>p.id===to).bot){const val=b=>b.cash+b.properties.reduce((n,i)=>n+board[i].price,0);const offer=state.offers.at(-1);if(offer?.to===to){const ok=val(give)>=val(receive);perform({type:'trade_reply',player:to,offer:offer.id,accept:ok});toast(ok?'La IA aceptó tu propuesta.':'La IA rechazó tu propuesta.');speak(ok?txt('¡Trato hecho!','Deal!'):txt('Mmm… no aceptó tu trato.','Hmm… they turned it down.'));}}}}catch(err){toast(err.message);}});
window.addEventListener('beforeunload',save);
window.addEventListener('resize',()=>{clearTimeout(window.__rz);window.__rz=setTimeout(()=>{layoutStages();},120);});
document.addEventListener('visibilitychange',()=>{if(document.hidden){pauseMusic();voice.stop(true);}else if(screen==='play'&&state)resumeMusic();});
if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)&&!location.hostname.endsWith('localhost'))navigator.serviceWorker.register('sw.js').catch(()=>{});
document.body.insertAdjacentHTML('afterbegin',SPRITE);
document.fonts?.ready?.then(()=>fitText());
render();

function brandWorld(){return `<section class="brand-world" aria-label="${txt('El universo de Business Shop','The Business Shop universe')}"><div class="brand-welcome"><img class="brand-presenter" src="${presenter}" alt="${txt('Presentadora de Business Shop con una pila EKO','Business Shop presenter with an EKO battery')}"><div><p class="eyebrow">BUSINESS SHOP · EKO K’IIN</p><h2>${txt('Energía para tu próxima jugada.','Energy for your next move.')}</h2><p>${txt('Una semilla, una comunidad y un mundo por construir. Descubre las imágenes que dan identidad a nuestra mesa.','A seed, a community and a world to build. Discover the images that give our table its identity.')}</p><button data-ui="setup" class="primary">${txt('Crear mi partida','Create my game')}</button></div></div><div class="brand-gallery">${[[seedBattery,txt('Una semilla de energía','A seed of energy'),txt('Pila EKO K’iin','EKO K’iin battery')],[recycling,txt('Cuidemos nuestro mundo','Care for our world'),txt('Contenedores de recolección','Collection containers')],[planters,txt('Cada jugada puede florecer','Every move can bloom'),txt('Macetas EKO K’iin','EKO K’iin planters')]].map(([src,title,alt])=>`<figure><div><img src="${src}" alt="${alt}" loading="lazy"></div><figcaption>${title}</figcaption></figure>`).join('')}</div></section>`;}

function ekoShowcase(){return `<section class="eko-showcase" aria-labelledby="eko-showcase-title"><div class="eko-showcase-heading"><img class="eko-token-art" src="${ekoToken}" alt="${txt('Emblema EKO K’iin Token','EKO K’iin Token emblem')}" loading="lazy"><div><p class="eyebrow">EKO K’IIN · BUSINESS SHOP</p><h2 id="eko-showcase-title">${txt('Energía que da vida','Energy that gives life')}</h2><p>${txt('Conoce el proyecto EKO K’iin y descubre su universo.','Meet the EKO K’iin project and discover its world.')}</p><a class="eko-site-link" href="https://www.ekokiin.com.mx/" target="_blank" rel="noopener noreferrer">${txt('Visitar','Visit')} www.ekokiin.com.mx ↗<span class="screen-reader">${txt(' (abre el sitio externo)',' (opens external website)')}</span></a></div></div><figure class="eko-presentation"><img src="${ekoPresentation}" alt="${txt('Presentación de EKO K’iin: energía que da vida, personaje de la marca, emblema y baterías.','EKO K’iin presentation: energy that gives life, brand character, emblem and batteries.')}" loading="lazy"><figcaption>${txt('Imagen de presentación de la marca. Los botones mostrados forman parte de la imagen.','Brand presentation image. Buttons shown are part of the image.')}</figcaption></figure><p class="eko-game-note">${txt('En EKO POLY juegas con Cacao virtual, sin valor monetario.','In EKO POLY you play with virtual Cacao, with no monetary value.')}</p></section>`;}
