// Voz de EKO K’iin: narra la partida con tono infantil usando la voz del propio dispositivo.
// Web Speech en navegadores (iPhone, Windows, Chrome) y el plugin nativo de texto a voz en la app Android.
let enabled=true,lang='es-MX',chosen=null,queue=[],speaking=false,primed=false,seq=0,listeners={start:null,end:null};
const synth=()=>typeof window!=='undefined'&&'speechSynthesis' in window?window.speechSynthesis:null;
// En la app Android (Capacitor) el WebView no trae síntesis de voz: se usa el plugin nativo TextToSpeech.
const nativeTTS=()=>{
 const cap=typeof window!=='undefined'?window.Capacitor:null;if(!cap)return null;
 if(cap.Plugins?.TextToSpeech)return cap.Plugins.TextToSpeech;
 if(cap.nativePromise&&cap.PluginHeaders?.some(h=>h.name==='TextToSpeech'))return {speak:o=>cap.nativePromise('TextToSpeech','speak',o),stop:()=>cap.nativePromise('TextToSpeech','stop',{})};
 return null;
};

function pickVoice(){
 const s=synth();if(!s)return null;const voices=s.getVoices()||[];if(!voices.length)return null;
 const prefs=lang.startsWith('es')?['es-mx','es-us','es-419','es-es','es']:['en-us','en-gb','en'];
 for(const p of prefs){
  const list=voices.filter(v=>String(v.lang||'').replace('_','-').toLowerCase().startsWith(p));
  if(list.length)return list.find(v=>/natural|neural|online|paulina|dalia|google|m[oó]nica|sabina/i.test(v.name))||list.find(v=>v.localService)||list[0];
 }
 return null;
}
if(synth())try{synth().addEventListener?.('voiceschanged',()=>{chosen=null;});}catch{}

export const voiceSupported=()=>!!(synth()||nativeTTS());
export function setVoiceEnabled(on){enabled=on;if(!on)stop(true);}
export function setVoiceLang(l){const next=l==='en'?'en-US':'es-MX';if(next!==lang){lang=next;chosen=null;}}
export function onSpeech(start,end){listeners={start,end};}
// iOS solo permite hablar después de un gesto: se "ceba" la voz con un enunciado vacío.
export function prime(){const s=synth();if(!s||primed)return;primed=true;try{const u=new SpeechSynthesisUtterance(' ');u.volume=0;s.speak(u);}catch{}}
export function stop(keepBubble=false){queue=[];seq++;speaking=false;try{synth()?.cancel();}catch{}try{nativeTTS()?.stop?.()?.catch?.(()=>{});}catch{}if(!keepBubble)listeners.end?.('');}

function next(){
 if(speaking||!queue.length)return;
 const text=queue.shift(),id=++seq,started=Date.now(),minMs=Math.min(4200,1200+text.length*42);speaking=true;listeners.start?.(text);
 // El globo permanece un mínimo de tiempo aunque el dispositivo no tenga voz o termine antes.
 const done=()=>{if(id!==seq)return;setTimeout(()=>{if(id!==seq)return;speaking=false;listeners.end?.(text);setTimeout(next,160);},Math.max(0,minMs-(Date.now()-started)));};
 const timed=()=>setTimeout(done,minMs);
 if(!enabled)return timed();
 const s=synth(),n=nativeTTS();
 if(!s&&n){n.speak({text,lang,rate:1,pitch:1.55,volume:1,category:'ambient'}).then(done,done);return;}
 if(!s)return timed();
 try{
  const u=new SpeechSynthesisUtterance(text);u.lang=lang;const v=chosen||(chosen=pickVoice());if(v)u.voice=v;
  u.pitch=1.65;u.rate=1.06;u.volume=1;
  let finished=false;const fin=()=>{if(finished)return;finished=true;clearTimeout(guard);done();};
  const guard=setTimeout(fin,2600+text.length*95);u.onend=fin;u.onerror=fin;s.speak(u);
 }catch{timed();}
}
// interrupt: corta lo que se esté diciendo (para la jugada propia más reciente).
export function say(text,{interrupt=false}={}){
 if(!text)return;
 if(interrupt){queue=[];seq++;speaking=false;try{synth()?.cancel();}catch{}}
 queue.push(text);if(queue.length>3)queue.splice(0,queue.length-3);next();
}
