import Ajv from 'ajv';import {readFileSync} from 'node:fs';
import board from './board.json' with {type:'json'};import rules from './rules.json' with {type:'json'};import cards from './cards.json' with {type:'json'};
const ajv=new Ajv({strict:false,allErrors:true});
const boardValidator=ajv.compile(JSON.parse(readFileSync(new URL('board.schema.json',import.meta.url))));
const cardsValidator=ajv.compile(JSON.parse(readFileSync(new URL('cards.schema.json',import.meta.url))));
const rulesValidator=ajv.compile(JSON.parse(readFileSync(new URL('rules.schema.json',import.meta.url))));
export function validateConfig(b=board,r=rules,c=cards){
 for(const [name,validate,value] of [['board',boardValidator,b],['rules',rulesValidator,r],['cards',cardsValidator,c]])if(!validate(value))throw Error(`${name}: ${ajv.errorsText(validate.errors)}`);
 if(b.some((t,i)=>t.id!==i)||b.filter(t=>t.type==='property').length!==22)throw Error('IDs o propiedades inválidas.');
 if(new Set([...c.oracle,...c.community].map(c=>c.id)).size!==c.oracle.length+c.community.length)throw Error('IDs de cartas repetidos.');
 for(const card of [...c.oracle,...c.community]){const needed={move:['target'],cash:['amount'],repairs:['house','hotel'],back:['steps']}[card.type]||[];if(needed.some(k=>!Number.isInteger(card[k])))throw Error('Efecto de carta incompleto.');}
 return true;
}
